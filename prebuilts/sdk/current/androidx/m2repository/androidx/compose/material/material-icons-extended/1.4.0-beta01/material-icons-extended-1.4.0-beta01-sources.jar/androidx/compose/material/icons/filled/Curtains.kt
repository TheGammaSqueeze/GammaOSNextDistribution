/*
 * Copyright 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.material.icons.filled

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.materialIcon
import androidx.compose.material.icons.materialPath
import androidx.compose.ui.graphics.vector.ImageVector

public val Icons.Filled.Curtains: ImageVector
    get() {
        if (_curtains != null) {
            return _curtains!!
        }
        _curtains = materialIcon(name = "Filled.Curtains") {
            materialPath {
                moveTo(20.0f, 19.0f)
                verticalLineTo(3.0f)
                horizontalLineTo(4.0f)
                verticalLineToRelative(16.0f)
                horizontalLineTo(2.0f)
                verticalLineToRelative(2.0f)
                horizontalLineToRelative(20.0f)
                verticalLineToRelative(-2.0f)
                horizontalLineTo(20.0f)
                close()
                moveTo(8.19f, 12.0f)
                curveToRelative(2.04f, -1.35f, 3.5f, -3.94f, 3.76f, -7.0f)
                horizontalLineToRelative(0.09f)
                curveToRelative(0.26f, 3.06f, 1.72f, 5.65f, 3.76f, 7.0f)
                curveToRelative(-2.04f, 1.35f, -3.5f, 3.94f, -3.76f, 7.0f)
                horizontalLineToRelative(-0.09f)
                curveTo(11.69f, 15.94f, 10.23f, 13.35f, 8.19f, 12.0f)
                close()
            }
        }
        return _curtains!!
    }

private var _curtains: ImageVector? = null
