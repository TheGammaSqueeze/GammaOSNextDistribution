/*
 * Copyright 2010-2017 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.jetbrains.kotlin.codegen

import org.jetbrains.kotlin.codegen.inline.NameGenerator
import org.jetbrains.kotlin.codegen.inline.ReifiedTypeParametersUsages
import org.jetbrains.kotlin.descriptors.ClassDescriptor
import org.jetbrains.kotlin.descriptors.TypeParameterDescriptor
import org.jetbrains.kotlin.psi.KtElement
import org.jetbrains.org.objectweb.asm.commons.InstructionAdapter

interface BaseExpressionCodegen {

    val frameMap: FrameMap

    val visitor: InstructionAdapter

    val inlineNameGenerator: NameGenerator

    val lastLineNumber: Int

    fun consumeReifiedOperationMarker(typeParameterDescriptor: TypeParameterDescriptor)

    fun propagateChildReifiedTypeParametersUsages(reifiedTypeParametersUsages: ReifiedTypeParametersUsages)

    fun pushClosureOnStack(
            classDescriptor: ClassDescriptor,
            putThis: Boolean,
            callGenerator: CallGenerator,
            functionReferenceReceiver: StackValue?
    )

    fun markLineNumberAfterInlineIfNeeded()
}
