__kernel void test_convert_double4_char4( __global char4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4(src[tid]);
}

__kernel void test_convert_double4_rte_char4( __global char4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rte(src[tid]);
}

__kernel void test_convert_double4_rtn_char4( __global char4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtn(src[tid]);
}

__kernel void test_convert_double4_rtp_char4( __global char4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtp(src[tid]);
}

__kernel void test_convert_double4_rtz_char4( __global char4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtz(src[tid]);
}

__kernel void test_convert_char4_sat_uchar4( __global uchar4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat(src[tid]);
}

__kernel void test_convert_char4_sat_rte_uchar4( __global uchar4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rte(src[tid]);
}

__kernel void test_convert_char4_sat_rtn_uchar4( __global uchar4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtn(src[tid]);
}

__kernel void test_convert_char4_sat_rtp_uchar4( __global uchar4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtp(src[tid]);
}

__kernel void test_convert_char4_sat_rtz_uchar4( __global uchar4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtz(src[tid]);
}

__kernel void test_convert_char4_uchar4( __global uchar4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4(src[tid]);
}

__kernel void test_convert_char4_rte_uchar4( __global uchar4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rte(src[tid]);
}

__kernel void test_convert_char4_rtn_uchar4( __global uchar4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtn(src[tid]);
}

__kernel void test_convert_char4_rtp_uchar4( __global uchar4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtp(src[tid]);
}

__kernel void test_convert_char4_rtz_uchar4( __global uchar4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtz(src[tid]);
}

__kernel void test_convert_uchar4_sat_uchar4( __global uchar4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat(src[tid]);
}

__kernel void test_convert_uchar4_sat_rte_uchar4( __global uchar4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rte(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtn_uchar4( __global uchar4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtp_uchar4( __global uchar4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtz_uchar4( __global uchar4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar4_uchar4( __global uchar4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4(src[tid]);
}

__kernel void test_convert_uchar4_rte_uchar4( __global uchar4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rte(src[tid]);
}

__kernel void test_convert_uchar4_rtn_uchar4( __global uchar4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtn(src[tid]);
}

__kernel void test_convert_uchar4_rtp_uchar4( __global uchar4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtp(src[tid]);
}

__kernel void test_convert_uchar4_rtz_uchar4( __global uchar4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtz(src[tid]);
}

__kernel void test_convert_int4_sat_uchar4( __global uchar4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat(src[tid]);
}

__kernel void test_convert_int4_sat_rte_uchar4( __global uchar4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rte(src[tid]);
}

__kernel void test_convert_int4_sat_rtn_uchar4( __global uchar4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtn(src[tid]);
}

__kernel void test_convert_int4_sat_rtp_uchar4( __global uchar4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtp(src[tid]);
}

__kernel void test_convert_int4_sat_rtz_uchar4( __global uchar4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtz(src[tid]);
}

__kernel void test_convert_int4_uchar4( __global uchar4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4(src[tid]);
}

__kernel void test_convert_int4_rte_uchar4( __global uchar4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rte(src[tid]);
}

__kernel void test_convert_int4_rtn_uchar4( __global uchar4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtn(src[tid]);
}

__kernel void test_convert_int4_rtp_uchar4( __global uchar4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtp(src[tid]);
}

__kernel void test_convert_int4_rtz_uchar4( __global uchar4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtz(src[tid]);
}

__kernel void test_convert_uint4_sat_uchar4( __global uchar4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat(src[tid]);
}

__kernel void test_convert_uint4_sat_rte_uchar4( __global uchar4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rte(src[tid]);
}

__kernel void test_convert_uint4_sat_rtn_uchar4( __global uchar4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtn(src[tid]);
}

__kernel void test_convert_uint4_sat_rtp_uchar4( __global uchar4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtp(src[tid]);
}

__kernel void test_convert_uint4_sat_rtz_uchar4( __global uchar4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtz(src[tid]);
}

__kernel void test_convert_uint4_uchar4( __global uchar4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4(src[tid]);
}

__kernel void test_convert_uint4_rte_uchar4( __global uchar4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rte(src[tid]);
}

__kernel void test_convert_uint4_rtn_uchar4( __global uchar4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtn(src[tid]);
}

__kernel void test_convert_uint4_rtp_uchar4( __global uchar4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtp(src[tid]);
}

__kernel void test_convert_uint4_rtz_uchar4( __global uchar4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtz(src[tid]);
}

__kernel void test_convert_short4_sat_uchar4( __global uchar4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat(src[tid]);
}

__kernel void test_convert_short4_sat_rte_uchar4( __global uchar4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rte(src[tid]);
}

__kernel void test_convert_short4_sat_rtn_uchar4( __global uchar4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtn(src[tid]);
}

__kernel void test_convert_short4_sat_rtp_uchar4( __global uchar4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtp(src[tid]);
}

__kernel void test_convert_short4_sat_rtz_uchar4( __global uchar4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtz(src[tid]);
}

__kernel void test_convert_short4_uchar4( __global uchar4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4(src[tid]);
}

__kernel void test_convert_short4_rte_uchar4( __global uchar4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rte(src[tid]);
}

__kernel void test_convert_short4_rtn_uchar4( __global uchar4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtn(src[tid]);
}

__kernel void test_convert_short4_rtp_uchar4( __global uchar4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtp(src[tid]);
}

__kernel void test_convert_short4_rtz_uchar4( __global uchar4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtz(src[tid]);
}

__kernel void test_convert_ushort4_sat_uchar4( __global uchar4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat(src[tid]);
}

__kernel void test_convert_ushort4_sat_rte_uchar4( __global uchar4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rte(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtn_uchar4( __global uchar4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtp_uchar4( __global uchar4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtz_uchar4( __global uchar4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort4_uchar4( __global uchar4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4(src[tid]);
}

__kernel void test_convert_ushort4_rte_uchar4( __global uchar4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rte(src[tid]);
}

__kernel void test_convert_ushort4_rtn_uchar4( __global uchar4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtn(src[tid]);
}

__kernel void test_convert_ushort4_rtp_uchar4( __global uchar4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtp(src[tid]);
}

__kernel void test_convert_ushort4_rtz_uchar4( __global uchar4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtz(src[tid]);
}

__kernel void test_convert_long4_sat_uchar4( __global uchar4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat(src[tid]);
}

__kernel void test_convert_long4_sat_rte_uchar4( __global uchar4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rte(src[tid]);
}

__kernel void test_convert_long4_sat_rtn_uchar4( __global uchar4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtn(src[tid]);
}

__kernel void test_convert_long4_sat_rtp_uchar4( __global uchar4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtp(src[tid]);
}

__kernel void test_convert_long4_sat_rtz_uchar4( __global uchar4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtz(src[tid]);
}

__kernel void test_convert_long4_uchar4( __global uchar4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4(src[tid]);
}

__kernel void test_convert_long4_rte_uchar4( __global uchar4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rte(src[tid]);
}

__kernel void test_convert_long4_rtn_uchar4( __global uchar4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtn(src[tid]);
}

__kernel void test_convert_long4_rtp_uchar4( __global uchar4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtp(src[tid]);
}

__kernel void test_convert_long4_rtz_uchar4( __global uchar4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtz(src[tid]);
}

__kernel void test_convert_ulong4_sat_uchar4( __global uchar4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat(src[tid]);
}

__kernel void test_convert_ulong4_sat_rte_uchar4( __global uchar4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rte(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtn_uchar4( __global uchar4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtp_uchar4( __global uchar4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtz_uchar4( __global uchar4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong4_uchar4( __global uchar4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4(src[tid]);
}

__kernel void test_convert_ulong4_rte_uchar4( __global uchar4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rte(src[tid]);
}

__kernel void test_convert_ulong4_rtn_uchar4( __global uchar4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtn(src[tid]);
}

__kernel void test_convert_ulong4_rtp_uchar4( __global uchar4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtp(src[tid]);
}

__kernel void test_convert_ulong4_rtz_uchar4( __global uchar4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtz(src[tid]);
}

__kernel void test_convert_float4_uchar4( __global uchar4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4(src[tid]);
}

__kernel void test_convert_float4_rte_uchar4( __global uchar4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rte(src[tid]);
}

__kernel void test_convert_float4_rtn_uchar4( __global uchar4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtn(src[tid]);
}

__kernel void test_convert_float4_rtp_uchar4( __global uchar4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtp(src[tid]);
}

__kernel void test_convert_float4_rtz_uchar4( __global uchar4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtz(src[tid]);
}

__kernel void test_convert_double4_uchar4( __global uchar4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4(src[tid]);
}

__kernel void test_convert_double4_rte_uchar4( __global uchar4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rte(src[tid]);
}

__kernel void test_convert_double4_rtn_uchar4( __global uchar4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtn(src[tid]);
}

__kernel void test_convert_double4_rtp_uchar4( __global uchar4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtp(src[tid]);
}

__kernel void test_convert_double4_rtz_uchar4( __global uchar4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtz(src[tid]);
}

__kernel void test_convert_char4_sat_int4( __global int4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat(src[tid]);
}

__kernel void test_convert_char4_sat_rte_int4( __global int4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rte(src[tid]);
}

__kernel void test_convert_char4_sat_rtn_int4( __global int4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtn(src[tid]);
}

__kernel void test_convert_char4_sat_rtp_int4( __global int4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtp(src[tid]);
}

__kernel void test_convert_char4_sat_rtz_int4( __global int4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtz(src[tid]);
}

__kernel void test_convert_char4_int4( __global int4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4(src[tid]);
}

__kernel void test_convert_char4_rte_int4( __global int4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rte(src[tid]);
}

__kernel void test_convert_char4_rtn_int4( __global int4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtn(src[tid]);
}

__kernel void test_convert_char4_rtp_int4( __global int4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtp(src[tid]);
}

__kernel void test_convert_char4_rtz_int4( __global int4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtz(src[tid]);
}

__kernel void test_convert_uchar4_sat_int4( __global int4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat(src[tid]);
}

__kernel void test_convert_uchar4_sat_rte_int4( __global int4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rte(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtn_int4( __global int4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtp_int4( __global int4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtz_int4( __global int4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar4_int4( __global int4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4(src[tid]);
}

__kernel void test_convert_uchar4_rte_int4( __global int4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rte(src[tid]);
}

__kernel void test_convert_uchar4_rtn_int4( __global int4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtn(src[tid]);
}

__kernel void test_convert_uchar4_rtp_int4( __global int4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtp(src[tid]);
}

__kernel void test_convert_uchar4_rtz_int4( __global int4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtz(src[tid]);
}

__kernel void test_convert_int4_sat_int4( __global int4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat(src[tid]);
}

__kernel void test_convert_int4_sat_rte_int4( __global int4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rte(src[tid]);
}

__kernel void test_convert_int4_sat_rtn_int4( __global int4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtn(src[tid]);
}

__kernel void test_convert_int4_sat_rtp_int4( __global int4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtp(src[tid]);
}

__kernel void test_convert_int4_sat_rtz_int4( __global int4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtz(src[tid]);
}

__kernel void test_convert_int4_int4( __global int4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4(src[tid]);
}

__kernel void test_convert_int4_rte_int4( __global int4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rte(src[tid]);
}

__kernel void test_convert_int4_rtn_int4( __global int4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtn(src[tid]);
}

__kernel void test_convert_int4_rtp_int4( __global int4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtp(src[tid]);
}

__kernel void test_convert_int4_rtz_int4( __global int4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtz(src[tid]);
}

__kernel void test_convert_uint4_sat_int4( __global int4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat(src[tid]);
}

__kernel void test_convert_uint4_sat_rte_int4( __global int4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rte(src[tid]);
}

__kernel void test_convert_uint4_sat_rtn_int4( __global int4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtn(src[tid]);
}

__kernel void test_convert_uint4_sat_rtp_int4( __global int4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtp(src[tid]);
}

__kernel void test_convert_uint4_sat_rtz_int4( __global int4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtz(src[tid]);
}

__kernel void test_convert_uint4_int4( __global int4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4(src[tid]);
}

__kernel void test_convert_uint4_rte_int4( __global int4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rte(src[tid]);
}

__kernel void test_convert_uint4_rtn_int4( __global int4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtn(src[tid]);
}

__kernel void test_convert_uint4_rtp_int4( __global int4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtp(src[tid]);
}

__kernel void test_convert_uint4_rtz_int4( __global int4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtz(src[tid]);
}

__kernel void test_convert_short4_sat_int4( __global int4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat(src[tid]);
}

__kernel void test_convert_short4_sat_rte_int4( __global int4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rte(src[tid]);
}

__kernel void test_convert_short4_sat_rtn_int4( __global int4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtn(src[tid]);
}

__kernel void test_convert_short4_sat_rtp_int4( __global int4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtp(src[tid]);
}

__kernel void test_convert_short4_sat_rtz_int4( __global int4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtz(src[tid]);
}

__kernel void test_convert_short4_int4( __global int4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4(src[tid]);
}

__kernel void test_convert_short4_rte_int4( __global int4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rte(src[tid]);
}

__kernel void test_convert_short4_rtn_int4( __global int4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtn(src[tid]);
}

__kernel void test_convert_short4_rtp_int4( __global int4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtp(src[tid]);
}

__kernel void test_convert_short4_rtz_int4( __global int4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtz(src[tid]);
}

__kernel void test_convert_ushort4_sat_int4( __global int4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat(src[tid]);
}

__kernel void test_convert_ushort4_sat_rte_int4( __global int4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rte(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtn_int4( __global int4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtp_int4( __global int4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtz_int4( __global int4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort4_int4( __global int4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4(src[tid]);
}

__kernel void test_convert_ushort4_rte_int4( __global int4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rte(src[tid]);
}

__kernel void test_convert_ushort4_rtn_int4( __global int4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtn(src[tid]);
}

__kernel void test_convert_ushort4_rtp_int4( __global int4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtp(src[tid]);
}

__kernel void test_convert_ushort4_rtz_int4( __global int4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtz(src[tid]);
}

__kernel void test_convert_long4_sat_int4( __global int4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat(src[tid]);
}

__kernel void test_convert_long4_sat_rte_int4( __global int4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rte(src[tid]);
}

__kernel void test_convert_long4_sat_rtn_int4( __global int4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtn(src[tid]);
}

__kernel void test_convert_long4_sat_rtp_int4( __global int4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtp(src[tid]);
}

__kernel void test_convert_long4_sat_rtz_int4( __global int4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtz(src[tid]);
}

__kernel void test_convert_long4_int4( __global int4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4(src[tid]);
}

__kernel void test_convert_long4_rte_int4( __global int4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rte(src[tid]);
}

__kernel void test_convert_long4_rtn_int4( __global int4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtn(src[tid]);
}

__kernel void test_convert_long4_rtp_int4( __global int4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtp(src[tid]);
}

__kernel void test_convert_long4_rtz_int4( __global int4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtz(src[tid]);
}

__kernel void test_convert_ulong4_sat_int4( __global int4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat(src[tid]);
}

__kernel void test_convert_ulong4_sat_rte_int4( __global int4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rte(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtn_int4( __global int4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtp_int4( __global int4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtz_int4( __global int4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong4_int4( __global int4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4(src[tid]);
}

__kernel void test_convert_ulong4_rte_int4( __global int4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rte(src[tid]);
}

__kernel void test_convert_ulong4_rtn_int4( __global int4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtn(src[tid]);
}

__kernel void test_convert_ulong4_rtp_int4( __global int4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtp(src[tid]);
}

__kernel void test_convert_ulong4_rtz_int4( __global int4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtz(src[tid]);
}

__kernel void test_convert_float4_int4( __global int4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4(src[tid]);
}

__kernel void test_convert_float4_rte_int4( __global int4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rte(src[tid]);
}

__kernel void test_convert_float4_rtn_int4( __global int4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtn(src[tid]);
}

__kernel void test_convert_float4_rtp_int4( __global int4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtp(src[tid]);
}

__kernel void test_convert_float4_rtz_int4( __global int4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtz(src[tid]);
}

__kernel void test_convert_double4_int4( __global int4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4(src[tid]);
}

__kernel void test_convert_double4_rte_int4( __global int4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rte(src[tid]);
}

__kernel void test_convert_double4_rtn_int4( __global int4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtn(src[tid]);
}

__kernel void test_convert_double4_rtp_int4( __global int4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtp(src[tid]);
}

__kernel void test_convert_double4_rtz_int4( __global int4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtz(src[tid]);
}

__kernel void test_convert_char4_sat_uint4( __global uint4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat(src[tid]);
}

__kernel void test_convert_char4_sat_rte_uint4( __global uint4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rte(src[tid]);
}

__kernel void test_convert_char4_sat_rtn_uint4( __global uint4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtn(src[tid]);
}

__kernel void test_convert_char4_sat_rtp_uint4( __global uint4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtp(src[tid]);
}

__kernel void test_convert_char4_sat_rtz_uint4( __global uint4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtz(src[tid]);
}

__kernel void test_convert_char4_uint4( __global uint4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4(src[tid]);
}

__kernel void test_convert_char4_rte_uint4( __global uint4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rte(src[tid]);
}

__kernel void test_convert_char4_rtn_uint4( __global uint4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtn(src[tid]);
}

__kernel void test_convert_char4_rtp_uint4( __global uint4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtp(src[tid]);
}

__kernel void test_convert_char4_rtz_uint4( __global uint4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtz(src[tid]);
}

__kernel void test_convert_uchar4_sat_uint4( __global uint4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat(src[tid]);
}

__kernel void test_convert_uchar4_sat_rte_uint4( __global uint4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rte(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtn_uint4( __global uint4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtp_uint4( __global uint4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtz_uint4( __global uint4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar4_uint4( __global uint4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4(src[tid]);
}

__kernel void test_convert_uchar4_rte_uint4( __global uint4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rte(src[tid]);
}

__kernel void test_convert_uchar4_rtn_uint4( __global uint4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtn(src[tid]);
}

__kernel void test_convert_uchar4_rtp_uint4( __global uint4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtp(src[tid]);
}

__kernel void test_convert_uchar4_rtz_uint4( __global uint4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtz(src[tid]);
}

__kernel void test_convert_int4_sat_uint4( __global uint4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat(src[tid]);
}

__kernel void test_convert_int4_sat_rte_uint4( __global uint4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rte(src[tid]);
}

__kernel void test_convert_int4_sat_rtn_uint4( __global uint4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtn(src[tid]);
}

__kernel void test_convert_int4_sat_rtp_uint4( __global uint4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtp(src[tid]);
}

__kernel void test_convert_int4_sat_rtz_uint4( __global uint4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtz(src[tid]);
}

__kernel void test_convert_int4_uint4( __global uint4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4(src[tid]);
}

__kernel void test_convert_int4_rte_uint4( __global uint4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rte(src[tid]);
}

__kernel void test_convert_int4_rtn_uint4( __global uint4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtn(src[tid]);
}

__kernel void test_convert_int4_rtp_uint4( __global uint4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtp(src[tid]);
}

__kernel void test_convert_int4_rtz_uint4( __global uint4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtz(src[tid]);
}

__kernel void test_convert_uint4_sat_uint4( __global uint4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat(src[tid]);
}

__kernel void test_convert_uint4_sat_rte_uint4( __global uint4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rte(src[tid]);
}

__kernel void test_convert_uint4_sat_rtn_uint4( __global uint4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtn(src[tid]);
}

__kernel void test_convert_uint4_sat_rtp_uint4( __global uint4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtp(src[tid]);
}

__kernel void test_convert_uint4_sat_rtz_uint4( __global uint4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtz(src[tid]);
}

__kernel void test_convert_uint4_uint4( __global uint4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4(src[tid]);
}

__kernel void test_convert_uint4_rte_uint4( __global uint4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rte(src[tid]);
}

__kernel void test_convert_uint4_rtn_uint4( __global uint4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtn(src[tid]);
}

__kernel void test_convert_uint4_rtp_uint4( __global uint4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtp(src[tid]);
}

__kernel void test_convert_uint4_rtz_uint4( __global uint4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtz(src[tid]);
}

__kernel void test_convert_short4_sat_uint4( __global uint4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat(src[tid]);
}

__kernel void test_convert_short4_sat_rte_uint4( __global uint4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rte(src[tid]);
}

__kernel void test_convert_short4_sat_rtn_uint4( __global uint4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtn(src[tid]);
}

__kernel void test_convert_short4_sat_rtp_uint4( __global uint4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtp(src[tid]);
}

__kernel void test_convert_short4_sat_rtz_uint4( __global uint4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtz(src[tid]);
}

__kernel void test_convert_short4_uint4( __global uint4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4(src[tid]);
}

__kernel void test_convert_short4_rte_uint4( __global uint4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rte(src[tid]);
}

__kernel void test_convert_short4_rtn_uint4( __global uint4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtn(src[tid]);
}

__kernel void test_convert_short4_rtp_uint4( __global uint4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtp(src[tid]);
}

__kernel void test_convert_short4_rtz_uint4( __global uint4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtz(src[tid]);
}

__kernel void test_convert_ushort4_sat_uint4( __global uint4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat(src[tid]);
}

__kernel void test_convert_ushort4_sat_rte_uint4( __global uint4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rte(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtn_uint4( __global uint4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtp_uint4( __global uint4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtz_uint4( __global uint4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort4_uint4( __global uint4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4(src[tid]);
}

__kernel void test_convert_ushort4_rte_uint4( __global uint4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rte(src[tid]);
}

__kernel void test_convert_ushort4_rtn_uint4( __global uint4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtn(src[tid]);
}

__kernel void test_convert_ushort4_rtp_uint4( __global uint4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtp(src[tid]);
}

__kernel void test_convert_ushort4_rtz_uint4( __global uint4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtz(src[tid]);
}

__kernel void test_convert_long4_sat_uint4( __global uint4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat(src[tid]);
}

__kernel void test_convert_long4_sat_rte_uint4( __global uint4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rte(src[tid]);
}

__kernel void test_convert_long4_sat_rtn_uint4( __global uint4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtn(src[tid]);
}

__kernel void test_convert_long4_sat_rtp_uint4( __global uint4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtp(src[tid]);
}

__kernel void test_convert_long4_sat_rtz_uint4( __global uint4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtz(src[tid]);
}

__kernel void test_convert_long4_uint4( __global uint4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4(src[tid]);
}

__kernel void test_convert_long4_rte_uint4( __global uint4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rte(src[tid]);
}

__kernel void test_convert_long4_rtn_uint4( __global uint4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtn(src[tid]);
}

__kernel void test_convert_long4_rtp_uint4( __global uint4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtp(src[tid]);
}

__kernel void test_convert_long4_rtz_uint4( __global uint4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtz(src[tid]);
}

__kernel void test_convert_ulong4_sat_uint4( __global uint4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat(src[tid]);
}

__kernel void test_convert_ulong4_sat_rte_uint4( __global uint4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rte(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtn_uint4( __global uint4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtp_uint4( __global uint4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtz_uint4( __global uint4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong4_uint4( __global uint4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4(src[tid]);
}

__kernel void test_convert_ulong4_rte_uint4( __global uint4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rte(src[tid]);
}

__kernel void test_convert_ulong4_rtn_uint4( __global uint4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtn(src[tid]);
}

__kernel void test_convert_ulong4_rtp_uint4( __global uint4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtp(src[tid]);
}

__kernel void test_convert_ulong4_rtz_uint4( __global uint4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtz(src[tid]);
}

__kernel void test_convert_float4_uint4( __global uint4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4(src[tid]);
}

__kernel void test_convert_float4_rte_uint4( __global uint4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rte(src[tid]);
}

__kernel void test_convert_float4_rtn_uint4( __global uint4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtn(src[tid]);
}

__kernel void test_convert_float4_rtp_uint4( __global uint4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtp(src[tid]);
}

__kernel void test_convert_float4_rtz_uint4( __global uint4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtz(src[tid]);
}

__kernel void test_convert_double4_uint4( __global uint4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4(src[tid]);
}

__kernel void test_convert_double4_rte_uint4( __global uint4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rte(src[tid]);
}

__kernel void test_convert_double4_rtn_uint4( __global uint4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtn(src[tid]);
}

__kernel void test_convert_double4_rtp_uint4( __global uint4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtp(src[tid]);
}

__kernel void test_convert_double4_rtz_uint4( __global uint4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtz(src[tid]);
}

__kernel void test_convert_char4_sat_short4( __global short4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat(src[tid]);
}

__kernel void test_convert_char4_sat_rte_short4( __global short4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rte(src[tid]);
}

__kernel void test_convert_char4_sat_rtn_short4( __global short4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtn(src[tid]);
}

__kernel void test_convert_char4_sat_rtp_short4( __global short4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtp(src[tid]);
}

__kernel void test_convert_char4_sat_rtz_short4( __global short4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtz(src[tid]);
}

__kernel void test_convert_char4_short4( __global short4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4(src[tid]);
}

__kernel void test_convert_char4_rte_short4( __global short4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rte(src[tid]);
}

__kernel void test_convert_char4_rtn_short4( __global short4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtn(src[tid]);
}

__kernel void test_convert_char4_rtp_short4( __global short4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtp(src[tid]);
}

__kernel void test_convert_char4_rtz_short4( __global short4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtz(src[tid]);
}

__kernel void test_convert_uchar4_sat_short4( __global short4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat(src[tid]);
}

__kernel void test_convert_uchar4_sat_rte_short4( __global short4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rte(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtn_short4( __global short4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtp_short4( __global short4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtz_short4( __global short4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar4_short4( __global short4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4(src[tid]);
}

__kernel void test_convert_uchar4_rte_short4( __global short4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rte(src[tid]);
}

__kernel void test_convert_uchar4_rtn_short4( __global short4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtn(src[tid]);
}

__kernel void test_convert_uchar4_rtp_short4( __global short4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtp(src[tid]);
}

__kernel void test_convert_uchar4_rtz_short4( __global short4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtz(src[tid]);
}

__kernel void test_convert_int4_sat_short4( __global short4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat(src[tid]);
}

__kernel void test_convert_int4_sat_rte_short4( __global short4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rte(src[tid]);
}

__kernel void test_convert_int4_sat_rtn_short4( __global short4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtn(src[tid]);
}

__kernel void test_convert_int4_sat_rtp_short4( __global short4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtp(src[tid]);
}

__kernel void test_convert_int4_sat_rtz_short4( __global short4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtz(src[tid]);
}

__kernel void test_convert_int4_short4( __global short4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4(src[tid]);
}

__kernel void test_convert_int4_rte_short4( __global short4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rte(src[tid]);
}

__kernel void test_convert_int4_rtn_short4( __global short4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtn(src[tid]);
}

__kernel void test_convert_int4_rtp_short4( __global short4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtp(src[tid]);
}

__kernel void test_convert_int4_rtz_short4( __global short4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtz(src[tid]);
}

__kernel void test_convert_uint4_sat_short4( __global short4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat(src[tid]);
}

__kernel void test_convert_uint4_sat_rte_short4( __global short4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rte(src[tid]);
}

__kernel void test_convert_uint4_sat_rtn_short4( __global short4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtn(src[tid]);
}

__kernel void test_convert_uint4_sat_rtp_short4( __global short4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtp(src[tid]);
}

__kernel void test_convert_uint4_sat_rtz_short4( __global short4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtz(src[tid]);
}

__kernel void test_convert_uint4_short4( __global short4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4(src[tid]);
}

__kernel void test_convert_uint4_rte_short4( __global short4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rte(src[tid]);
}

__kernel void test_convert_uint4_rtn_short4( __global short4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtn(src[tid]);
}

__kernel void test_convert_uint4_rtp_short4( __global short4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtp(src[tid]);
}

__kernel void test_convert_uint4_rtz_short4( __global short4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtz(src[tid]);
}

__kernel void test_convert_short4_sat_short4( __global short4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat(src[tid]);
}

__kernel void test_convert_short4_sat_rte_short4( __global short4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rte(src[tid]);
}

__kernel void test_convert_short4_sat_rtn_short4( __global short4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtn(src[tid]);
}

__kernel void test_convert_short4_sat_rtp_short4( __global short4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtp(src[tid]);
}

__kernel void test_convert_short4_sat_rtz_short4( __global short4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtz(src[tid]);
}

__kernel void test_convert_short4_short4( __global short4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4(src[tid]);
}

__kernel void test_convert_short4_rte_short4( __global short4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rte(src[tid]);
}

__kernel void test_convert_short4_rtn_short4( __global short4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtn(src[tid]);
}

__kernel void test_convert_short4_rtp_short4( __global short4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtp(src[tid]);
}

__kernel void test_convert_short4_rtz_short4( __global short4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtz(src[tid]);
}

__kernel void test_convert_ushort4_sat_short4( __global short4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat(src[tid]);
}

__kernel void test_convert_ushort4_sat_rte_short4( __global short4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rte(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtn_short4( __global short4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtp_short4( __global short4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtz_short4( __global short4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort4_short4( __global short4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4(src[tid]);
}

__kernel void test_convert_ushort4_rte_short4( __global short4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rte(src[tid]);
}

__kernel void test_convert_ushort4_rtn_short4( __global short4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtn(src[tid]);
}

__kernel void test_convert_ushort4_rtp_short4( __global short4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtp(src[tid]);
}

__kernel void test_convert_ushort4_rtz_short4( __global short4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtz(src[tid]);
}

__kernel void test_convert_long4_sat_short4( __global short4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat(src[tid]);
}

__kernel void test_convert_long4_sat_rte_short4( __global short4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rte(src[tid]);
}

__kernel void test_convert_long4_sat_rtn_short4( __global short4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtn(src[tid]);
}

__kernel void test_convert_long4_sat_rtp_short4( __global short4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtp(src[tid]);
}

__kernel void test_convert_long4_sat_rtz_short4( __global short4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtz(src[tid]);
}

__kernel void test_convert_long4_short4( __global short4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4(src[tid]);
}

__kernel void test_convert_long4_rte_short4( __global short4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rte(src[tid]);
}

__kernel void test_convert_long4_rtn_short4( __global short4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtn(src[tid]);
}

__kernel void test_convert_long4_rtp_short4( __global short4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtp(src[tid]);
}

__kernel void test_convert_long4_rtz_short4( __global short4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtz(src[tid]);
}

__kernel void test_convert_ulong4_sat_short4( __global short4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat(src[tid]);
}

__kernel void test_convert_ulong4_sat_rte_short4( __global short4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rte(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtn_short4( __global short4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtp_short4( __global short4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtz_short4( __global short4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong4_short4( __global short4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4(src[tid]);
}

__kernel void test_convert_ulong4_rte_short4( __global short4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rte(src[tid]);
}

__kernel void test_convert_ulong4_rtn_short4( __global short4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtn(src[tid]);
}

__kernel void test_convert_ulong4_rtp_short4( __global short4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtp(src[tid]);
}

__kernel void test_convert_ulong4_rtz_short4( __global short4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtz(src[tid]);
}

__kernel void test_convert_float4_short4( __global short4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4(src[tid]);
}

__kernel void test_convert_float4_rte_short4( __global short4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rte(src[tid]);
}

__kernel void test_convert_float4_rtn_short4( __global short4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtn(src[tid]);
}

__kernel void test_convert_float4_rtp_short4( __global short4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtp(src[tid]);
}

__kernel void test_convert_float4_rtz_short4( __global short4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtz(src[tid]);
}

__kernel void test_convert_double4_short4( __global short4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4(src[tid]);
}

__kernel void test_convert_double4_rte_short4( __global short4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rte(src[tid]);
}

__kernel void test_convert_double4_rtn_short4( __global short4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtn(src[tid]);
}

__kernel void test_convert_double4_rtp_short4( __global short4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtp(src[tid]);
}

__kernel void test_convert_double4_rtz_short4( __global short4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtz(src[tid]);
}

__kernel void test_convert_char4_sat_ushort4( __global ushort4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat(src[tid]);
}

__kernel void test_convert_char4_sat_rte_ushort4( __global ushort4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rte(src[tid]);
}

__kernel void test_convert_char4_sat_rtn_ushort4( __global ushort4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtn(src[tid]);
}

__kernel void test_convert_char4_sat_rtp_ushort4( __global ushort4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtp(src[tid]);
}

__kernel void test_convert_char4_sat_rtz_ushort4( __global ushort4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtz(src[tid]);
}

__kernel void test_convert_char4_ushort4( __global ushort4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4(src[tid]);
}

__kernel void test_convert_char4_rte_ushort4( __global ushort4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rte(src[tid]);
}

__kernel void test_convert_char4_rtn_ushort4( __global ushort4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtn(src[tid]);
}

__kernel void test_convert_char4_rtp_ushort4( __global ushort4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtp(src[tid]);
}

__kernel void test_convert_char4_rtz_ushort4( __global ushort4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtz(src[tid]);
}

__kernel void test_convert_uchar4_sat_ushort4( __global ushort4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat(src[tid]);
}

__kernel void test_convert_uchar4_sat_rte_ushort4( __global ushort4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rte(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtn_ushort4( __global ushort4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtp_ushort4( __global ushort4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtz_ushort4( __global ushort4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar4_ushort4( __global ushort4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4(src[tid]);
}

__kernel void test_convert_uchar4_rte_ushort4( __global ushort4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rte(src[tid]);
}

__kernel void test_convert_uchar4_rtn_ushort4( __global ushort4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtn(src[tid]);
}

__kernel void test_convert_uchar4_rtp_ushort4( __global ushort4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtp(src[tid]);
}

__kernel void test_convert_uchar4_rtz_ushort4( __global ushort4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtz(src[tid]);
}

__kernel void test_convert_int4_sat_ushort4( __global ushort4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat(src[tid]);
}

__kernel void test_convert_int4_sat_rte_ushort4( __global ushort4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rte(src[tid]);
}

__kernel void test_convert_int4_sat_rtn_ushort4( __global ushort4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtn(src[tid]);
}

__kernel void test_convert_int4_sat_rtp_ushort4( __global ushort4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtp(src[tid]);
}

__kernel void test_convert_int4_sat_rtz_ushort4( __global ushort4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtz(src[tid]);
}

__kernel void test_convert_int4_ushort4( __global ushort4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4(src[tid]);
}

__kernel void test_convert_int4_rte_ushort4( __global ushort4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rte(src[tid]);
}

__kernel void test_convert_int4_rtn_ushort4( __global ushort4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtn(src[tid]);
}

__kernel void test_convert_int4_rtp_ushort4( __global ushort4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtp(src[tid]);
}

__kernel void test_convert_int4_rtz_ushort4( __global ushort4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtz(src[tid]);
}

__kernel void test_convert_uint4_sat_ushort4( __global ushort4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat(src[tid]);
}

__kernel void test_convert_uint4_sat_rte_ushort4( __global ushort4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rte(src[tid]);
}

__kernel void test_convert_uint4_sat_rtn_ushort4( __global ushort4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtn(src[tid]);
}

__kernel void test_convert_uint4_sat_rtp_ushort4( __global ushort4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtp(src[tid]);
}

__kernel void test_convert_uint4_sat_rtz_ushort4( __global ushort4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtz(src[tid]);
}

__kernel void test_convert_uint4_ushort4( __global ushort4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4(src[tid]);
}

__kernel void test_convert_uint4_rte_ushort4( __global ushort4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rte(src[tid]);
}

__kernel void test_convert_uint4_rtn_ushort4( __global ushort4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtn(src[tid]);
}

__kernel void test_convert_uint4_rtp_ushort4( __global ushort4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtp(src[tid]);
}

__kernel void test_convert_uint4_rtz_ushort4( __global ushort4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtz(src[tid]);
}

__kernel void test_convert_short4_sat_ushort4( __global ushort4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat(src[tid]);
}

__kernel void test_convert_short4_sat_rte_ushort4( __global ushort4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rte(src[tid]);
}

__kernel void test_convert_short4_sat_rtn_ushort4( __global ushort4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtn(src[tid]);
}

__kernel void test_convert_short4_sat_rtp_ushort4( __global ushort4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtp(src[tid]);
}

__kernel void test_convert_short4_sat_rtz_ushort4( __global ushort4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtz(src[tid]);
}

__kernel void test_convert_short4_ushort4( __global ushort4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4(src[tid]);
}

__kernel void test_convert_short4_rte_ushort4( __global ushort4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rte(src[tid]);
}

__kernel void test_convert_short4_rtn_ushort4( __global ushort4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtn(src[tid]);
}

__kernel void test_convert_short4_rtp_ushort4( __global ushort4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtp(src[tid]);
}

__kernel void test_convert_short4_rtz_ushort4( __global ushort4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtz(src[tid]);
}

__kernel void test_convert_ushort4_sat_ushort4( __global ushort4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat(src[tid]);
}

__kernel void test_convert_ushort4_sat_rte_ushort4( __global ushort4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rte(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtn_ushort4( __global ushort4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtp_ushort4( __global ushort4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtz_ushort4( __global ushort4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort4_ushort4( __global ushort4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4(src[tid]);
}

__kernel void test_convert_ushort4_rte_ushort4( __global ushort4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rte(src[tid]);
}

__kernel void test_convert_ushort4_rtn_ushort4( __global ushort4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtn(src[tid]);
}

__kernel void test_convert_ushort4_rtp_ushort4( __global ushort4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtp(src[tid]);
}

__kernel void test_convert_ushort4_rtz_ushort4( __global ushort4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtz(src[tid]);
}

__kernel void test_convert_long4_sat_ushort4( __global ushort4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat(src[tid]);
}

__kernel void test_convert_long4_sat_rte_ushort4( __global ushort4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rte(src[tid]);
}

__kernel void test_convert_long4_sat_rtn_ushort4( __global ushort4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtn(src[tid]);
}

__kernel void test_convert_long4_sat_rtp_ushort4( __global ushort4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtp(src[tid]);
}

__kernel void test_convert_long4_sat_rtz_ushort4( __global ushort4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtz(src[tid]);
}

__kernel void test_convert_long4_ushort4( __global ushort4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4(src[tid]);
}

__kernel void test_convert_long4_rte_ushort4( __global ushort4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rte(src[tid]);
}

__kernel void test_convert_long4_rtn_ushort4( __global ushort4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtn(src[tid]);
}

__kernel void test_convert_long4_rtp_ushort4( __global ushort4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtp(src[tid]);
}

__kernel void test_convert_long4_rtz_ushort4( __global ushort4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtz(src[tid]);
}

__kernel void test_convert_ulong4_sat_ushort4( __global ushort4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat(src[tid]);
}

__kernel void test_convert_ulong4_sat_rte_ushort4( __global ushort4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rte(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtn_ushort4( __global ushort4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtp_ushort4( __global ushort4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtz_ushort4( __global ushort4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong4_ushort4( __global ushort4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4(src[tid]);
}

__kernel void test_convert_ulong4_rte_ushort4( __global ushort4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rte(src[tid]);
}

__kernel void test_convert_ulong4_rtn_ushort4( __global ushort4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtn(src[tid]);
}

__kernel void test_convert_ulong4_rtp_ushort4( __global ushort4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtp(src[tid]);
}

__kernel void test_convert_ulong4_rtz_ushort4( __global ushort4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtz(src[tid]);
}

__kernel void test_convert_float4_ushort4( __global ushort4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4(src[tid]);
}

__kernel void test_convert_float4_rte_ushort4( __global ushort4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rte(src[tid]);
}

__kernel void test_convert_float4_rtn_ushort4( __global ushort4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtn(src[tid]);
}

__kernel void test_convert_float4_rtp_ushort4( __global ushort4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtp(src[tid]);
}

__kernel void test_convert_float4_rtz_ushort4( __global ushort4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtz(src[tid]);
}

__kernel void test_convert_double4_ushort4( __global ushort4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4(src[tid]);
}

__kernel void test_convert_double4_rte_ushort4( __global ushort4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rte(src[tid]);
}

__kernel void test_convert_double4_rtn_ushort4( __global ushort4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtn(src[tid]);
}

__kernel void test_convert_double4_rtp_ushort4( __global ushort4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtp(src[tid]);
}

__kernel void test_convert_double4_rtz_ushort4( __global ushort4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtz(src[tid]);
}

__kernel void test_convert_char4_sat_long4( __global long4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat(src[tid]);
}

__kernel void test_convert_char4_sat_rte_long4( __global long4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rte(src[tid]);
}

__kernel void test_convert_char4_sat_rtn_long4( __global long4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtn(src[tid]);
}

__kernel void test_convert_char4_sat_rtp_long4( __global long4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtp(src[tid]);
}

__kernel void test_convert_char4_sat_rtz_long4( __global long4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtz(src[tid]);
}

__kernel void test_convert_char4_long4( __global long4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4(src[tid]);
}

__kernel void test_convert_char4_rte_long4( __global long4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rte(src[tid]);
}

__kernel void test_convert_char4_rtn_long4( __global long4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtn(src[tid]);
}

__kernel void test_convert_char4_rtp_long4( __global long4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtp(src[tid]);
}

__kernel void test_convert_char4_rtz_long4( __global long4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtz(src[tid]);
}

__kernel void test_convert_uchar4_sat_long4( __global long4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat(src[tid]);
}

__kernel void test_convert_uchar4_sat_rte_long4( __global long4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rte(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtn_long4( __global long4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtp_long4( __global long4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtz_long4( __global long4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar4_long4( __global long4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4(src[tid]);
}

__kernel void test_convert_uchar4_rte_long4( __global long4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rte(src[tid]);
}

__kernel void test_convert_uchar4_rtn_long4( __global long4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtn(src[tid]);
}

__kernel void test_convert_uchar4_rtp_long4( __global long4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtp(src[tid]);
}

__kernel void test_convert_uchar4_rtz_long4( __global long4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtz(src[tid]);
}

__kernel void test_convert_int4_sat_long4( __global long4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat(src[tid]);
}

__kernel void test_convert_int4_sat_rte_long4( __global long4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rte(src[tid]);
}

__kernel void test_convert_int4_sat_rtn_long4( __global long4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtn(src[tid]);
}

__kernel void test_convert_int4_sat_rtp_long4( __global long4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtp(src[tid]);
}

__kernel void test_convert_int4_sat_rtz_long4( __global long4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtz(src[tid]);
}

__kernel void test_convert_int4_long4( __global long4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4(src[tid]);
}

__kernel void test_convert_int4_rte_long4( __global long4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rte(src[tid]);
}

__kernel void test_convert_int4_rtn_long4( __global long4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtn(src[tid]);
}

__kernel void test_convert_int4_rtp_long4( __global long4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtp(src[tid]);
}

__kernel void test_convert_int4_rtz_long4( __global long4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtz(src[tid]);
}

__kernel void test_convert_uint4_sat_long4( __global long4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat(src[tid]);
}

__kernel void test_convert_uint4_sat_rte_long4( __global long4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rte(src[tid]);
}

__kernel void test_convert_uint4_sat_rtn_long4( __global long4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtn(src[tid]);
}

__kernel void test_convert_uint4_sat_rtp_long4( __global long4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtp(src[tid]);
}

__kernel void test_convert_uint4_sat_rtz_long4( __global long4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtz(src[tid]);
}

__kernel void test_convert_uint4_long4( __global long4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4(src[tid]);
}

__kernel void test_convert_uint4_rte_long4( __global long4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rte(src[tid]);
}

__kernel void test_convert_uint4_rtn_long4( __global long4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtn(src[tid]);
}

__kernel void test_convert_uint4_rtp_long4( __global long4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtp(src[tid]);
}

__kernel void test_convert_uint4_rtz_long4( __global long4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtz(src[tid]);
}

__kernel void test_convert_short4_sat_long4( __global long4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat(src[tid]);
}

__kernel void test_convert_short4_sat_rte_long4( __global long4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rte(src[tid]);
}

__kernel void test_convert_short4_sat_rtn_long4( __global long4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtn(src[tid]);
}

__kernel void test_convert_short4_sat_rtp_long4( __global long4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtp(src[tid]);
}

__kernel void test_convert_short4_sat_rtz_long4( __global long4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtz(src[tid]);
}

__kernel void test_convert_short4_long4( __global long4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4(src[tid]);
}

__kernel void test_convert_short4_rte_long4( __global long4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rte(src[tid]);
}

__kernel void test_convert_short4_rtn_long4( __global long4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtn(src[tid]);
}

__kernel void test_convert_short4_rtp_long4( __global long4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtp(src[tid]);
}

__kernel void test_convert_short4_rtz_long4( __global long4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtz(src[tid]);
}

__kernel void test_convert_ushort4_sat_long4( __global long4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat(src[tid]);
}

__kernel void test_convert_ushort4_sat_rte_long4( __global long4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rte(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtn_long4( __global long4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtp_long4( __global long4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtz_long4( __global long4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort4_long4( __global long4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4(src[tid]);
}

__kernel void test_convert_ushort4_rte_long4( __global long4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rte(src[tid]);
}

__kernel void test_convert_ushort4_rtn_long4( __global long4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtn(src[tid]);
}

__kernel void test_convert_ushort4_rtp_long4( __global long4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtp(src[tid]);
}

__kernel void test_convert_ushort4_rtz_long4( __global long4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtz(src[tid]);
}

__kernel void test_convert_long4_sat_long4( __global long4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat(src[tid]);
}

__kernel void test_convert_long4_sat_rte_long4( __global long4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rte(src[tid]);
}

__kernel void test_convert_long4_sat_rtn_long4( __global long4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtn(src[tid]);
}

__kernel void test_convert_long4_sat_rtp_long4( __global long4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtp(src[tid]);
}

__kernel void test_convert_long4_sat_rtz_long4( __global long4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtz(src[tid]);
}

__kernel void test_convert_long4_long4( __global long4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4(src[tid]);
}

__kernel void test_convert_long4_rte_long4( __global long4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rte(src[tid]);
}

__kernel void test_convert_long4_rtn_long4( __global long4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtn(src[tid]);
}

__kernel void test_convert_long4_rtp_long4( __global long4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtp(src[tid]);
}

__kernel void test_convert_long4_rtz_long4( __global long4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtz(src[tid]);
}

__kernel void test_convert_ulong4_sat_long4( __global long4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat(src[tid]);
}

__kernel void test_convert_ulong4_sat_rte_long4( __global long4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rte(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtn_long4( __global long4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtp_long4( __global long4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtz_long4( __global long4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong4_long4( __global long4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4(src[tid]);
}

__kernel void test_convert_ulong4_rte_long4( __global long4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rte(src[tid]);
}

__kernel void test_convert_ulong4_rtn_long4( __global long4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtn(src[tid]);
}

__kernel void test_convert_ulong4_rtp_long4( __global long4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtp(src[tid]);
}

__kernel void test_convert_ulong4_rtz_long4( __global long4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtz(src[tid]);
}

__kernel void test_convert_float4_long4( __global long4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4(src[tid]);
}

__kernel void test_convert_float4_rte_long4( __global long4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rte(src[tid]);
}

__kernel void test_convert_float4_rtn_long4( __global long4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtn(src[tid]);
}

__kernel void test_convert_float4_rtp_long4( __global long4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtp(src[tid]);
}

__kernel void test_convert_float4_rtz_long4( __global long4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtz(src[tid]);
}

__kernel void test_convert_double4_long4( __global long4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4(src[tid]);
}

__kernel void test_convert_double4_rte_long4( __global long4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rte(src[tid]);
}

__kernel void test_convert_double4_rtn_long4( __global long4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtn(src[tid]);
}

__kernel void test_convert_double4_rtp_long4( __global long4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtp(src[tid]);
}

__kernel void test_convert_double4_rtz_long4( __global long4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtz(src[tid]);
}

__kernel void test_convert_char4_sat_ulong4( __global ulong4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat(src[tid]);
}

__kernel void test_convert_char4_sat_rte_ulong4( __global ulong4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rte(src[tid]);
}

__kernel void test_convert_char4_sat_rtn_ulong4( __global ulong4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtn(src[tid]);
}

__kernel void test_convert_char4_sat_rtp_ulong4( __global ulong4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtp(src[tid]);
}

__kernel void test_convert_char4_sat_rtz_ulong4( __global ulong4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtz(src[tid]);
}

__kernel void test_convert_char4_ulong4( __global ulong4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4(src[tid]);
}

__kernel void test_convert_char4_rte_ulong4( __global ulong4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rte(src[tid]);
}

__kernel void test_convert_char4_rtn_ulong4( __global ulong4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtn(src[tid]);
}

__kernel void test_convert_char4_rtp_ulong4( __global ulong4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtp(src[tid]);
}

__kernel void test_convert_char4_rtz_ulong4( __global ulong4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtz(src[tid]);
}

__kernel void test_convert_uchar4_sat_ulong4( __global ulong4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat(src[tid]);
}

__kernel void test_convert_uchar4_sat_rte_ulong4( __global ulong4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rte(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtn_ulong4( __global ulong4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtp_ulong4( __global ulong4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtz_ulong4( __global ulong4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar4_ulong4( __global ulong4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4(src[tid]);
}

__kernel void test_convert_uchar4_rte_ulong4( __global ulong4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rte(src[tid]);
}

__kernel void test_convert_uchar4_rtn_ulong4( __global ulong4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtn(src[tid]);
}

__kernel void test_convert_uchar4_rtp_ulong4( __global ulong4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtp(src[tid]);
}

__kernel void test_convert_uchar4_rtz_ulong4( __global ulong4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtz(src[tid]);
}

__kernel void test_convert_int4_sat_ulong4( __global ulong4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat(src[tid]);
}

__kernel void test_convert_int4_sat_rte_ulong4( __global ulong4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rte(src[tid]);
}

__kernel void test_convert_int4_sat_rtn_ulong4( __global ulong4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtn(src[tid]);
}

__kernel void test_convert_int4_sat_rtp_ulong4( __global ulong4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtp(src[tid]);
}

__kernel void test_convert_int4_sat_rtz_ulong4( __global ulong4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtz(src[tid]);
}

__kernel void test_convert_int4_ulong4( __global ulong4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4(src[tid]);
}

__kernel void test_convert_int4_rte_ulong4( __global ulong4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rte(src[tid]);
}

__kernel void test_convert_int4_rtn_ulong4( __global ulong4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtn(src[tid]);
}

__kernel void test_convert_int4_rtp_ulong4( __global ulong4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtp(src[tid]);
}

__kernel void test_convert_int4_rtz_ulong4( __global ulong4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtz(src[tid]);
}

__kernel void test_convert_uint4_sat_ulong4( __global ulong4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat(src[tid]);
}

__kernel void test_convert_uint4_sat_rte_ulong4( __global ulong4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rte(src[tid]);
}

__kernel void test_convert_uint4_sat_rtn_ulong4( __global ulong4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtn(src[tid]);
}

__kernel void test_convert_uint4_sat_rtp_ulong4( __global ulong4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtp(src[tid]);
}

__kernel void test_convert_uint4_sat_rtz_ulong4( __global ulong4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtz(src[tid]);
}

__kernel void test_convert_uint4_ulong4( __global ulong4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4(src[tid]);
}

__kernel void test_convert_uint4_rte_ulong4( __global ulong4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rte(src[tid]);
}

__kernel void test_convert_uint4_rtn_ulong4( __global ulong4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtn(src[tid]);
}

__kernel void test_convert_uint4_rtp_ulong4( __global ulong4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtp(src[tid]);
}

__kernel void test_convert_uint4_rtz_ulong4( __global ulong4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtz(src[tid]);
}

__kernel void test_convert_short4_sat_ulong4( __global ulong4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat(src[tid]);
}

__kernel void test_convert_short4_sat_rte_ulong4( __global ulong4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rte(src[tid]);
}

__kernel void test_convert_short4_sat_rtn_ulong4( __global ulong4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtn(src[tid]);
}

__kernel void test_convert_short4_sat_rtp_ulong4( __global ulong4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtp(src[tid]);
}

__kernel void test_convert_short4_sat_rtz_ulong4( __global ulong4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtz(src[tid]);
}

__kernel void test_convert_short4_ulong4( __global ulong4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4(src[tid]);
}

__kernel void test_convert_short4_rte_ulong4( __global ulong4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rte(src[tid]);
}

__kernel void test_convert_short4_rtn_ulong4( __global ulong4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtn(src[tid]);
}

__kernel void test_convert_short4_rtp_ulong4( __global ulong4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtp(src[tid]);
}

__kernel void test_convert_short4_rtz_ulong4( __global ulong4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtz(src[tid]);
}

__kernel void test_convert_ushort4_sat_ulong4( __global ulong4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat(src[tid]);
}

__kernel void test_convert_ushort4_sat_rte_ulong4( __global ulong4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rte(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtn_ulong4( __global ulong4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtp_ulong4( __global ulong4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtz_ulong4( __global ulong4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort4_ulong4( __global ulong4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4(src[tid]);
}

__kernel void test_convert_ushort4_rte_ulong4( __global ulong4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rte(src[tid]);
}

__kernel void test_convert_ushort4_rtn_ulong4( __global ulong4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtn(src[tid]);
}

__kernel void test_convert_ushort4_rtp_ulong4( __global ulong4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtp(src[tid]);
}

__kernel void test_convert_ushort4_rtz_ulong4( __global ulong4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtz(src[tid]);
}

__kernel void test_convert_long4_sat_ulong4( __global ulong4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat(src[tid]);
}

__kernel void test_convert_long4_sat_rte_ulong4( __global ulong4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rte(src[tid]);
}

__kernel void test_convert_long4_sat_rtn_ulong4( __global ulong4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtn(src[tid]);
}

__kernel void test_convert_long4_sat_rtp_ulong4( __global ulong4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtp(src[tid]);
}

__kernel void test_convert_long4_sat_rtz_ulong4( __global ulong4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtz(src[tid]);
}

__kernel void test_convert_long4_ulong4( __global ulong4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4(src[tid]);
}

__kernel void test_convert_long4_rte_ulong4( __global ulong4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rte(src[tid]);
}

__kernel void test_convert_long4_rtn_ulong4( __global ulong4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtn(src[tid]);
}

__kernel void test_convert_long4_rtp_ulong4( __global ulong4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtp(src[tid]);
}

__kernel void test_convert_long4_rtz_ulong4( __global ulong4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtz(src[tid]);
}

__kernel void test_convert_ulong4_sat_ulong4( __global ulong4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat(src[tid]);
}

__kernel void test_convert_ulong4_sat_rte_ulong4( __global ulong4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rte(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtn_ulong4( __global ulong4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtp_ulong4( __global ulong4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtz_ulong4( __global ulong4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong4_ulong4( __global ulong4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4(src[tid]);
}

__kernel void test_convert_ulong4_rte_ulong4( __global ulong4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rte(src[tid]);
}

__kernel void test_convert_ulong4_rtn_ulong4( __global ulong4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtn(src[tid]);
}

__kernel void test_convert_ulong4_rtp_ulong4( __global ulong4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtp(src[tid]);
}

__kernel void test_convert_ulong4_rtz_ulong4( __global ulong4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtz(src[tid]);
}

__kernel void test_convert_float4_ulong4( __global ulong4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4(src[tid]);
}

__kernel void test_convert_float4_rte_ulong4( __global ulong4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rte(src[tid]);
}

__kernel void test_convert_float4_rtn_ulong4( __global ulong4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtn(src[tid]);
}

__kernel void test_convert_float4_rtp_ulong4( __global ulong4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtp(src[tid]);
}

__kernel void test_convert_float4_rtz_ulong4( __global ulong4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtz(src[tid]);
}

__kernel void test_convert_double4_ulong4( __global ulong4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4(src[tid]);
}

__kernel void test_convert_double4_rte_ulong4( __global ulong4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rte(src[tid]);
}

__kernel void test_convert_double4_rtn_ulong4( __global ulong4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtn(src[tid]);
}

__kernel void test_convert_double4_rtp_ulong4( __global ulong4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtp(src[tid]);
}

__kernel void test_convert_double4_rtz_ulong4( __global ulong4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtz(src[tid]);
}

__kernel void test_convert_char4_sat_float4( __global float4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat(src[tid]);
}

__kernel void test_convert_char4_sat_rte_float4( __global float4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rte(src[tid]);
}

__kernel void test_convert_char4_sat_rtn_float4( __global float4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtn(src[tid]);
}

__kernel void test_convert_char4_sat_rtp_float4( __global float4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtp(src[tid]);
}

__kernel void test_convert_char4_sat_rtz_float4( __global float4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtz(src[tid]);
}

__kernel void test_convert_char4_float4( __global float4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4(src[tid]);
}

__kernel void test_convert_char4_rte_float4( __global float4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rte(src[tid]);
}

__kernel void test_convert_char4_rtn_float4( __global float4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtn(src[tid]);
}

__kernel void test_convert_char4_rtp_float4( __global float4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtp(src[tid]);
}

__kernel void test_convert_char4_rtz_float4( __global float4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtz(src[tid]);
}

__kernel void test_convert_uchar4_sat_float4( __global float4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat(src[tid]);
}

__kernel void test_convert_uchar4_sat_rte_float4( __global float4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rte(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtn_float4( __global float4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtp_float4( __global float4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtz_float4( __global float4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar4_float4( __global float4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4(src[tid]);
}

__kernel void test_convert_uchar4_rte_float4( __global float4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rte(src[tid]);
}

__kernel void test_convert_uchar4_rtn_float4( __global float4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtn(src[tid]);
}

__kernel void test_convert_uchar4_rtp_float4( __global float4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtp(src[tid]);
}

__kernel void test_convert_uchar4_rtz_float4( __global float4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtz(src[tid]);
}

__kernel void test_convert_int4_sat_float4( __global float4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat(src[tid]);
}

__kernel void test_convert_int4_sat_rte_float4( __global float4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rte(src[tid]);
}

__kernel void test_convert_int4_sat_rtn_float4( __global float4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtn(src[tid]);
}

__kernel void test_convert_int4_sat_rtp_float4( __global float4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtp(src[tid]);
}

__kernel void test_convert_int4_sat_rtz_float4( __global float4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtz(src[tid]);
}

__kernel void test_convert_int4_float4( __global float4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4(src[tid]);
}

__kernel void test_convert_int4_rte_float4( __global float4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rte(src[tid]);
}

__kernel void test_convert_int4_rtn_float4( __global float4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtn(src[tid]);
}

__kernel void test_convert_int4_rtp_float4( __global float4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtp(src[tid]);
}

__kernel void test_convert_int4_rtz_float4( __global float4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtz(src[tid]);
}

__kernel void test_convert_uint4_sat_float4( __global float4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat(src[tid]);
}

__kernel void test_convert_uint4_sat_rte_float4( __global float4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rte(src[tid]);
}

__kernel void test_convert_uint4_sat_rtn_float4( __global float4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtn(src[tid]);
}

__kernel void test_convert_uint4_sat_rtp_float4( __global float4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtp(src[tid]);
}

__kernel void test_convert_uint4_sat_rtz_float4( __global float4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtz(src[tid]);
}

__kernel void test_convert_uint4_float4( __global float4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4(src[tid]);
}

__kernel void test_convert_uint4_rte_float4( __global float4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rte(src[tid]);
}

__kernel void test_convert_uint4_rtn_float4( __global float4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtn(src[tid]);
}

__kernel void test_convert_uint4_rtp_float4( __global float4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtp(src[tid]);
}

__kernel void test_convert_uint4_rtz_float4( __global float4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtz(src[tid]);
}

__kernel void test_convert_short4_sat_float4( __global float4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat(src[tid]);
}

__kernel void test_convert_short4_sat_rte_float4( __global float4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rte(src[tid]);
}

__kernel void test_convert_short4_sat_rtn_float4( __global float4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtn(src[tid]);
}

__kernel void test_convert_short4_sat_rtp_float4( __global float4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtp(src[tid]);
}

__kernel void test_convert_short4_sat_rtz_float4( __global float4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtz(src[tid]);
}

__kernel void test_convert_short4_float4( __global float4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4(src[tid]);
}

__kernel void test_convert_short4_rte_float4( __global float4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rte(src[tid]);
}

__kernel void test_convert_short4_rtn_float4( __global float4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtn(src[tid]);
}

__kernel void test_convert_short4_rtp_float4( __global float4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtp(src[tid]);
}

__kernel void test_convert_short4_rtz_float4( __global float4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtz(src[tid]);
}

__kernel void test_convert_ushort4_sat_float4( __global float4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat(src[tid]);
}

__kernel void test_convert_ushort4_sat_rte_float4( __global float4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rte(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtn_float4( __global float4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtp_float4( __global float4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtz_float4( __global float4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort4_float4( __global float4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4(src[tid]);
}

__kernel void test_convert_ushort4_rte_float4( __global float4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rte(src[tid]);
}

__kernel void test_convert_ushort4_rtn_float4( __global float4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtn(src[tid]);
}

__kernel void test_convert_ushort4_rtp_float4( __global float4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtp(src[tid]);
}

__kernel void test_convert_ushort4_rtz_float4( __global float4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtz(src[tid]);
}

__kernel void test_convert_long4_sat_float4( __global float4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat(src[tid]);
}

__kernel void test_convert_long4_sat_rte_float4( __global float4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rte(src[tid]);
}

__kernel void test_convert_long4_sat_rtn_float4( __global float4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtn(src[tid]);
}

__kernel void test_convert_long4_sat_rtp_float4( __global float4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtp(src[tid]);
}

__kernel void test_convert_long4_sat_rtz_float4( __global float4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtz(src[tid]);
}

__kernel void test_convert_long4_float4( __global float4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4(src[tid]);
}

__kernel void test_convert_long4_rte_float4( __global float4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rte(src[tid]);
}

__kernel void test_convert_long4_rtn_float4( __global float4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtn(src[tid]);
}

__kernel void test_convert_long4_rtp_float4( __global float4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtp(src[tid]);
}

__kernel void test_convert_long4_rtz_float4( __global float4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtz(src[tid]);
}

__kernel void test_convert_ulong4_sat_float4( __global float4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat(src[tid]);
}

__kernel void test_convert_ulong4_sat_rte_float4( __global float4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rte(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtn_float4( __global float4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtp_float4( __global float4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtz_float4( __global float4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong4_float4( __global float4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4(src[tid]);
}

__kernel void test_convert_ulong4_rte_float4( __global float4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rte(src[tid]);
}

__kernel void test_convert_ulong4_rtn_float4( __global float4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtn(src[tid]);
}

__kernel void test_convert_ulong4_rtp_float4( __global float4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtp(src[tid]);
}

__kernel void test_convert_ulong4_rtz_float4( __global float4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtz(src[tid]);
}

__kernel void test_convert_float4_float4( __global float4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4(src[tid]);
}

__kernel void test_convert_float4_rte_float4( __global float4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rte(src[tid]);
}

__kernel void test_convert_float4_rtn_float4( __global float4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtn(src[tid]);
}

__kernel void test_convert_float4_rtp_float4( __global float4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtp(src[tid]);
}

__kernel void test_convert_float4_rtz_float4( __global float4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtz(src[tid]);
}

__kernel void test_convert_double4_float4( __global float4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4(src[tid]);
}

__kernel void test_convert_double4_rte_float4( __global float4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rte(src[tid]);
}

__kernel void test_convert_double4_rtn_float4( __global float4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtn(src[tid]);
}

__kernel void test_convert_double4_rtp_float4( __global float4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtp(src[tid]);
}

__kernel void test_convert_double4_rtz_float4( __global float4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtz(src[tid]);
}

__kernel void test_convert_char4_sat_double4( __global double4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat(src[tid]);
}

__kernel void test_convert_char4_sat_rte_double4( __global double4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rte(src[tid]);
}

__kernel void test_convert_char4_sat_rtn_double4( __global double4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtn(src[tid]);
}

__kernel void test_convert_char4_sat_rtp_double4( __global double4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtp(src[tid]);
}

__kernel void test_convert_char4_sat_rtz_double4( __global double4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtz(src[tid]);
}

__kernel void test_convert_char4_double4( __global double4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4(src[tid]);
}

__kernel void test_convert_char4_rte_double4( __global double4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rte(src[tid]);
}

__kernel void test_convert_char4_rtn_double4( __global double4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtn(src[tid]);
}

__kernel void test_convert_char4_rtp_double4( __global double4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtp(src[tid]);
}

__kernel void test_convert_char4_rtz_double4( __global double4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtz(src[tid]);
}

__kernel void test_convert_uchar4_sat_double4( __global double4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat(src[tid]);
}

__kernel void test_convert_uchar4_sat_rte_double4( __global double4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rte(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtn_double4( __global double4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtp_double4( __global double4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtz_double4( __global double4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar4_double4( __global double4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4(src[tid]);
}

__kernel void test_convert_uchar4_rte_double4( __global double4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rte(src[tid]);
}

__kernel void test_convert_uchar4_rtn_double4( __global double4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtn(src[tid]);
}

__kernel void test_convert_uchar4_rtp_double4( __global double4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtp(src[tid]);
}

__kernel void test_convert_uchar4_rtz_double4( __global double4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtz(src[tid]);
}

__kernel void test_convert_int4_sat_double4( __global double4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat(src[tid]);
}

__kernel void test_convert_int4_sat_rte_double4( __global double4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rte(src[tid]);
}

__kernel void test_convert_int4_sat_rtn_double4( __global double4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtn(src[tid]);
}

__kernel void test_convert_int4_sat_rtp_double4( __global double4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtp(src[tid]);
}

__kernel void test_convert_int4_sat_rtz_double4( __global double4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtz(src[tid]);
}

__kernel void test_convert_int4_double4( __global double4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4(src[tid]);
}

__kernel void test_convert_int4_rte_double4( __global double4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rte(src[tid]);
}

__kernel void test_convert_int4_rtn_double4( __global double4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtn(src[tid]);
}

__kernel void test_convert_int4_rtp_double4( __global double4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtp(src[tid]);
}

__kernel void test_convert_int4_rtz_double4( __global double4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtz(src[tid]);
}

__kernel void test_convert_uint4_sat_double4( __global double4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat(src[tid]);
}

__kernel void test_convert_uint4_sat_rte_double4( __global double4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rte(src[tid]);
}

__kernel void test_convert_uint4_sat_rtn_double4( __global double4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtn(src[tid]);
}

__kernel void test_convert_uint4_sat_rtp_double4( __global double4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtp(src[tid]);
}

__kernel void test_convert_uint4_sat_rtz_double4( __global double4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtz(src[tid]);
}

__kernel void test_convert_uint4_double4( __global double4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4(src[tid]);
}

__kernel void test_convert_uint4_rte_double4( __global double4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rte(src[tid]);
}

__kernel void test_convert_uint4_rtn_double4( __global double4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtn(src[tid]);
}

__kernel void test_convert_uint4_rtp_double4( __global double4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtp(src[tid]);
}

__kernel void test_convert_uint4_rtz_double4( __global double4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtz(src[tid]);
}

__kernel void test_convert_short4_sat_double4( __global double4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat(src[tid]);
}

__kernel void test_convert_short4_sat_rte_double4( __global double4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rte(src[tid]);
}

__kernel void test_convert_short4_sat_rtn_double4( __global double4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtn(src[tid]);
}

__kernel void test_convert_short4_sat_rtp_double4( __global double4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtp(src[tid]);
}

__kernel void test_convert_short4_sat_rtz_double4( __global double4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtz(src[tid]);
}

__kernel void test_convert_short4_double4( __global double4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4(src[tid]);
}

__kernel void test_convert_short4_rte_double4( __global double4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rte(src[tid]);
}

__kernel void test_convert_short4_rtn_double4( __global double4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtn(src[tid]);
}

__kernel void test_convert_short4_rtp_double4( __global double4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtp(src[tid]);
}

__kernel void test_convert_short4_rtz_double4( __global double4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtz(src[tid]);
}

__kernel void test_convert_ushort4_sat_double4( __global double4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat(src[tid]);
}

__kernel void test_convert_ushort4_sat_rte_double4( __global double4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rte(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtn_double4( __global double4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtp_double4( __global double4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtz_double4( __global double4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort4_double4( __global double4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4(src[tid]);
}

__kernel void test_convert_ushort4_rte_double4( __global double4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rte(src[tid]);
}

__kernel void test_convert_ushort4_rtn_double4( __global double4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtn(src[tid]);
}

__kernel void test_convert_ushort4_rtp_double4( __global double4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtp(src[tid]);
}

__kernel void test_convert_ushort4_rtz_double4( __global double4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtz(src[tid]);
}

__kernel void test_convert_long4_sat_double4( __global double4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat(src[tid]);
}

__kernel void test_convert_long4_sat_rte_double4( __global double4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rte(src[tid]);
}

__kernel void test_convert_long4_sat_rtn_double4( __global double4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtn(src[tid]);
}

__kernel void test_convert_long4_sat_rtp_double4( __global double4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtp(src[tid]);
}

__kernel void test_convert_long4_sat_rtz_double4( __global double4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtz(src[tid]);
}

__kernel void test_convert_long4_double4( __global double4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4(src[tid]);
}

__kernel void test_convert_long4_rte_double4( __global double4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rte(src[tid]);
}

__kernel void test_convert_long4_rtn_double4( __global double4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtn(src[tid]);
}

__kernel void test_convert_long4_rtp_double4( __global double4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtp(src[tid]);
}

__kernel void test_convert_long4_rtz_double4( __global double4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtz(src[tid]);
}

__kernel void test_convert_ulong4_sat_double4( __global double4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat(src[tid]);
}

__kernel void test_convert_ulong4_sat_rte_double4( __global double4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rte(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtn_double4( __global double4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtp_double4( __global double4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtz_double4( __global double4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong4_double4( __global double4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4(src[tid]);
}

__kernel void test_convert_ulong4_rte_double4( __global double4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rte(src[tid]);
}

__kernel void test_convert_ulong4_rtn_double4( __global double4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtn(src[tid]);
}

__kernel void test_convert_ulong4_rtp_double4( __global double4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtp(src[tid]);
}

__kernel void test_convert_ulong4_rtz_double4( __global double4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtz(src[tid]);
}

__kernel void test_convert_float4_double4( __global double4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4(src[tid]);
}

__kernel void test_convert_float4_rte_double4( __global double4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rte(src[tid]);
}

__kernel void test_convert_float4_rtn_double4( __global double4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtn(src[tid]);
}

__kernel void test_convert_float4_rtp_double4( __global double4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtp(src[tid]);
}

__kernel void test_convert_float4_rtz_double4( __global double4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtz(src[tid]);
}

__kernel void test_convert_double4_double4( __global double4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4(src[tid]);
}

__kernel void test_convert_double4_rte_double4( __global double4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rte(src[tid]);
}

__kernel void test_convert_double4_rtn_double4( __global double4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtn(src[tid]);
}

__kernel void test_convert_double4_rtp_double4( __global double4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtp(src[tid]);
}

__kernel void test_convert_double4_rtz_double4( __global double4 *src, __global double4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double4_rtz(src[tid]);
}


