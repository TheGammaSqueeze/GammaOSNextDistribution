#pragma OPENCL EXTENSION cl_khr_fp64 : enable
__kernel void test_convert_double2_rte_float2( __global float2 *src, __global double2 *dest )
{
   size_t i = get_global_id(0);
   dest[i] = convert_double2_rte( src[i] );
}
