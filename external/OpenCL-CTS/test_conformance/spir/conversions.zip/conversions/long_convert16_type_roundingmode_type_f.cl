#ifdef cles_khr_int64
#pragma OPENCL EXTENSION cles_khr_int64 : enable
#endif
__kernel void test_convert_long16_sat_char16( __global char16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat(src[tid]);
}

__kernel void test_convert_long16_sat_rte_char16( __global char16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rte(src[tid]);
}

__kernel void test_convert_long16_sat_rtn_char16( __global char16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtn(src[tid]);
}

__kernel void test_convert_long16_sat_rtp_char16( __global char16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtp(src[tid]);
}

__kernel void test_convert_long16_sat_rtz_char16( __global char16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtz(src[tid]);
}

__kernel void test_convert_long16_char16( __global char16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16(src[tid]);
}

__kernel void test_convert_long16_rte_char16( __global char16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rte(src[tid]);
}

__kernel void test_convert_long16_rtn_char16( __global char16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtn(src[tid]);
}

__kernel void test_convert_long16_rtp_char16( __global char16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtp(src[tid]);
}

__kernel void test_convert_long16_rtz_char16( __global char16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtz(src[tid]);
}

__kernel void test_convert_ulong16_sat_char16( __global char16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat(src[tid]);
}

__kernel void test_convert_ulong16_sat_rte_char16( __global char16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rte(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtn_char16( __global char16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtp_char16( __global char16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtz_char16( __global char16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong16_char16( __global char16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16(src[tid]);
}

__kernel void test_convert_ulong16_rte_char16( __global char16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rte(src[tid]);
}

__kernel void test_convert_ulong16_rtn_char16( __global char16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtn(src[tid]);
}

__kernel void test_convert_ulong16_rtp_char16( __global char16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtp(src[tid]);
}

__kernel void test_convert_ulong16_rtz_char16( __global char16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtz(src[tid]);
}
