#pragma OPENCL EXTENSION cl_khr_fp64 : enable
__kernel void test_convert_double2_rte_ulong2( __global ulong2 *src, __global double2 *dest )
{
   size_t i = get_global_id(0);
   dest[i] = convert_double2_rte( src[i] );
}
