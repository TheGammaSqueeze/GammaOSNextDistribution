#ifdef cles_khr_int64
#pragma OPENCL EXTENSION cles_khr_int64 : enable
#endif
__kernel void test_convert_long2_sat_char2( __global char2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat(src[tid]);
}

__kernel void test_convert_long2_sat_rte_char2( __global char2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rte(src[tid]);
}

__kernel void test_convert_long2_sat_rtn_char2( __global char2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtn(src[tid]);
}

__kernel void test_convert_long2_sat_rtp_char2( __global char2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtp(src[tid]);
}

__kernel void test_convert_long2_sat_rtz_char2( __global char2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtz(src[tid]);
}

__kernel void test_convert_long2_char2( __global char2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2(src[tid]);
}

__kernel void test_convert_long2_rte_char2( __global char2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rte(src[tid]);
}

__kernel void test_convert_long2_rtn_char2( __global char2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtn(src[tid]);
}

__kernel void test_convert_long2_rtp_char2( __global char2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtp(src[tid]);
}

__kernel void test_convert_long2_rtz_char2( __global char2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtz(src[tid]);
}

__kernel void test_convert_ulong2_sat_char2( __global char2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat(src[tid]);
}

__kernel void test_convert_ulong2_sat_rte_char2( __global char2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rte(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtn_char2( __global char2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtp_char2( __global char2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtz_char2( __global char2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong2_char2( __global char2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2(src[tid]);
}

__kernel void test_convert_ulong2_rte_char2( __global char2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rte(src[tid]);
}

__kernel void test_convert_ulong2_rtn_char2( __global char2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtn(src[tid]);
}

__kernel void test_convert_ulong2_rtp_char2( __global char2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtp(src[tid]);
}

__kernel void test_convert_ulong2_rtz_char2( __global char2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtz(src[tid]);
}
