__kernel void test_convert_double8_char8( __global char8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8(src[tid]);
}

__kernel void test_convert_double8_rte_char8( __global char8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rte(src[tid]);
}

__kernel void test_convert_double8_rtn_char8( __global char8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtn(src[tid]);
}

__kernel void test_convert_double8_rtp_char8( __global char8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtp(src[tid]);
}

__kernel void test_convert_double8_rtz_char8( __global char8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtz(src[tid]);
}

__kernel void test_convert_char8_sat_uchar8( __global uchar8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat(src[tid]);
}

__kernel void test_convert_char8_sat_rte_uchar8( __global uchar8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rte(src[tid]);
}

__kernel void test_convert_char8_sat_rtn_uchar8( __global uchar8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtn(src[tid]);
}

__kernel void test_convert_char8_sat_rtp_uchar8( __global uchar8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtp(src[tid]);
}

__kernel void test_convert_char8_sat_rtz_uchar8( __global uchar8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtz(src[tid]);
}

__kernel void test_convert_char8_uchar8( __global uchar8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8(src[tid]);
}

__kernel void test_convert_char8_rte_uchar8( __global uchar8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rte(src[tid]);
}

__kernel void test_convert_char8_rtn_uchar8( __global uchar8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtn(src[tid]);
}

__kernel void test_convert_char8_rtp_uchar8( __global uchar8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtp(src[tid]);
}

__kernel void test_convert_char8_rtz_uchar8( __global uchar8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtz(src[tid]);
}

__kernel void test_convert_uchar8_sat_uchar8( __global uchar8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat(src[tid]);
}

__kernel void test_convert_uchar8_sat_rte_uchar8( __global uchar8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rte(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtn_uchar8( __global uchar8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtp_uchar8( __global uchar8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtz_uchar8( __global uchar8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar8_uchar8( __global uchar8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8(src[tid]);
}

__kernel void test_convert_uchar8_rte_uchar8( __global uchar8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rte(src[tid]);
}

__kernel void test_convert_uchar8_rtn_uchar8( __global uchar8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtn(src[tid]);
}

__kernel void test_convert_uchar8_rtp_uchar8( __global uchar8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtp(src[tid]);
}

__kernel void test_convert_uchar8_rtz_uchar8( __global uchar8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtz(src[tid]);
}

__kernel void test_convert_int8_sat_uchar8( __global uchar8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat(src[tid]);
}

__kernel void test_convert_int8_sat_rte_uchar8( __global uchar8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rte(src[tid]);
}

__kernel void test_convert_int8_sat_rtn_uchar8( __global uchar8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtn(src[tid]);
}

__kernel void test_convert_int8_sat_rtp_uchar8( __global uchar8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtp(src[tid]);
}

__kernel void test_convert_int8_sat_rtz_uchar8( __global uchar8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtz(src[tid]);
}

__kernel void test_convert_int8_uchar8( __global uchar8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8(src[tid]);
}

__kernel void test_convert_int8_rte_uchar8( __global uchar8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rte(src[tid]);
}

__kernel void test_convert_int8_rtn_uchar8( __global uchar8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtn(src[tid]);
}

__kernel void test_convert_int8_rtp_uchar8( __global uchar8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtp(src[tid]);
}

__kernel void test_convert_int8_rtz_uchar8( __global uchar8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtz(src[tid]);
}

__kernel void test_convert_uint8_sat_uchar8( __global uchar8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat(src[tid]);
}

__kernel void test_convert_uint8_sat_rte_uchar8( __global uchar8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rte(src[tid]);
}

__kernel void test_convert_uint8_sat_rtn_uchar8( __global uchar8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtn(src[tid]);
}

__kernel void test_convert_uint8_sat_rtp_uchar8( __global uchar8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtp(src[tid]);
}

__kernel void test_convert_uint8_sat_rtz_uchar8( __global uchar8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtz(src[tid]);
}

__kernel void test_convert_uint8_uchar8( __global uchar8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8(src[tid]);
}

__kernel void test_convert_uint8_rte_uchar8( __global uchar8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rte(src[tid]);
}

__kernel void test_convert_uint8_rtn_uchar8( __global uchar8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtn(src[tid]);
}

__kernel void test_convert_uint8_rtp_uchar8( __global uchar8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtp(src[tid]);
}

__kernel void test_convert_uint8_rtz_uchar8( __global uchar8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtz(src[tid]);
}

__kernel void test_convert_short8_sat_uchar8( __global uchar8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat(src[tid]);
}

__kernel void test_convert_short8_sat_rte_uchar8( __global uchar8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rte(src[tid]);
}

__kernel void test_convert_short8_sat_rtn_uchar8( __global uchar8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtn(src[tid]);
}

__kernel void test_convert_short8_sat_rtp_uchar8( __global uchar8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtp(src[tid]);
}

__kernel void test_convert_short8_sat_rtz_uchar8( __global uchar8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtz(src[tid]);
}

__kernel void test_convert_short8_uchar8( __global uchar8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8(src[tid]);
}

__kernel void test_convert_short8_rte_uchar8( __global uchar8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rte(src[tid]);
}

__kernel void test_convert_short8_rtn_uchar8( __global uchar8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtn(src[tid]);
}

__kernel void test_convert_short8_rtp_uchar8( __global uchar8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtp(src[tid]);
}

__kernel void test_convert_short8_rtz_uchar8( __global uchar8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtz(src[tid]);
}

__kernel void test_convert_ushort8_sat_uchar8( __global uchar8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat(src[tid]);
}

__kernel void test_convert_ushort8_sat_rte_uchar8( __global uchar8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rte(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtn_uchar8( __global uchar8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtp_uchar8( __global uchar8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtz_uchar8( __global uchar8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort8_uchar8( __global uchar8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8(src[tid]);
}

__kernel void test_convert_ushort8_rte_uchar8( __global uchar8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rte(src[tid]);
}

__kernel void test_convert_ushort8_rtn_uchar8( __global uchar8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtn(src[tid]);
}

__kernel void test_convert_ushort8_rtp_uchar8( __global uchar8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtp(src[tid]);
}

__kernel void test_convert_ushort8_rtz_uchar8( __global uchar8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtz(src[tid]);
}

__kernel void test_convert_long8_sat_uchar8( __global uchar8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat(src[tid]);
}

__kernel void test_convert_long8_sat_rte_uchar8( __global uchar8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rte(src[tid]);
}

__kernel void test_convert_long8_sat_rtn_uchar8( __global uchar8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtn(src[tid]);
}

__kernel void test_convert_long8_sat_rtp_uchar8( __global uchar8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtp(src[tid]);
}

__kernel void test_convert_long8_sat_rtz_uchar8( __global uchar8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtz(src[tid]);
}

__kernel void test_convert_long8_uchar8( __global uchar8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8(src[tid]);
}

__kernel void test_convert_long8_rte_uchar8( __global uchar8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rte(src[tid]);
}

__kernel void test_convert_long8_rtn_uchar8( __global uchar8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtn(src[tid]);
}

__kernel void test_convert_long8_rtp_uchar8( __global uchar8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtp(src[tid]);
}

__kernel void test_convert_long8_rtz_uchar8( __global uchar8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtz(src[tid]);
}

__kernel void test_convert_ulong8_sat_uchar8( __global uchar8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat(src[tid]);
}

__kernel void test_convert_ulong8_sat_rte_uchar8( __global uchar8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rte(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtn_uchar8( __global uchar8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtp_uchar8( __global uchar8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtz_uchar8( __global uchar8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong8_uchar8( __global uchar8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8(src[tid]);
}

__kernel void test_convert_ulong8_rte_uchar8( __global uchar8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rte(src[tid]);
}

__kernel void test_convert_ulong8_rtn_uchar8( __global uchar8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtn(src[tid]);
}

__kernel void test_convert_ulong8_rtp_uchar8( __global uchar8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtp(src[tid]);
}

__kernel void test_convert_ulong8_rtz_uchar8( __global uchar8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtz(src[tid]);
}

__kernel void test_convert_float8_uchar8( __global uchar8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8(src[tid]);
}

__kernel void test_convert_float8_rte_uchar8( __global uchar8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rte(src[tid]);
}

__kernel void test_convert_float8_rtn_uchar8( __global uchar8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtn(src[tid]);
}

__kernel void test_convert_float8_rtp_uchar8( __global uchar8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtp(src[tid]);
}

__kernel void test_convert_float8_rtz_uchar8( __global uchar8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtz(src[tid]);
}

__kernel void test_convert_double8_uchar8( __global uchar8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8(src[tid]);
}

__kernel void test_convert_double8_rte_uchar8( __global uchar8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rte(src[tid]);
}

__kernel void test_convert_double8_rtn_uchar8( __global uchar8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtn(src[tid]);
}

__kernel void test_convert_double8_rtp_uchar8( __global uchar8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtp(src[tid]);
}

__kernel void test_convert_double8_rtz_uchar8( __global uchar8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtz(src[tid]);
}

__kernel void test_convert_char8_sat_int8( __global int8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat(src[tid]);
}

__kernel void test_convert_char8_sat_rte_int8( __global int8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rte(src[tid]);
}

__kernel void test_convert_char8_sat_rtn_int8( __global int8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtn(src[tid]);
}

__kernel void test_convert_char8_sat_rtp_int8( __global int8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtp(src[tid]);
}

__kernel void test_convert_char8_sat_rtz_int8( __global int8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtz(src[tid]);
}

__kernel void test_convert_char8_int8( __global int8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8(src[tid]);
}

__kernel void test_convert_char8_rte_int8( __global int8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rte(src[tid]);
}

__kernel void test_convert_char8_rtn_int8( __global int8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtn(src[tid]);
}

__kernel void test_convert_char8_rtp_int8( __global int8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtp(src[tid]);
}

__kernel void test_convert_char8_rtz_int8( __global int8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtz(src[tid]);
}

__kernel void test_convert_uchar8_sat_int8( __global int8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat(src[tid]);
}

__kernel void test_convert_uchar8_sat_rte_int8( __global int8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rte(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtn_int8( __global int8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtp_int8( __global int8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtz_int8( __global int8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar8_int8( __global int8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8(src[tid]);
}

__kernel void test_convert_uchar8_rte_int8( __global int8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rte(src[tid]);
}

__kernel void test_convert_uchar8_rtn_int8( __global int8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtn(src[tid]);
}

__kernel void test_convert_uchar8_rtp_int8( __global int8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtp(src[tid]);
}

__kernel void test_convert_uchar8_rtz_int8( __global int8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtz(src[tid]);
}

__kernel void test_convert_int8_sat_int8( __global int8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat(src[tid]);
}

__kernel void test_convert_int8_sat_rte_int8( __global int8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rte(src[tid]);
}

__kernel void test_convert_int8_sat_rtn_int8( __global int8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtn(src[tid]);
}

__kernel void test_convert_int8_sat_rtp_int8( __global int8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtp(src[tid]);
}

__kernel void test_convert_int8_sat_rtz_int8( __global int8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtz(src[tid]);
}

__kernel void test_convert_int8_int8( __global int8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8(src[tid]);
}

__kernel void test_convert_int8_rte_int8( __global int8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rte(src[tid]);
}

__kernel void test_convert_int8_rtn_int8( __global int8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtn(src[tid]);
}

__kernel void test_convert_int8_rtp_int8( __global int8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtp(src[tid]);
}

__kernel void test_convert_int8_rtz_int8( __global int8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtz(src[tid]);
}

__kernel void test_convert_uint8_sat_int8( __global int8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat(src[tid]);
}

__kernel void test_convert_uint8_sat_rte_int8( __global int8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rte(src[tid]);
}

__kernel void test_convert_uint8_sat_rtn_int8( __global int8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtn(src[tid]);
}

__kernel void test_convert_uint8_sat_rtp_int8( __global int8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtp(src[tid]);
}

__kernel void test_convert_uint8_sat_rtz_int8( __global int8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtz(src[tid]);
}

__kernel void test_convert_uint8_int8( __global int8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8(src[tid]);
}

__kernel void test_convert_uint8_rte_int8( __global int8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rte(src[tid]);
}

__kernel void test_convert_uint8_rtn_int8( __global int8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtn(src[tid]);
}

__kernel void test_convert_uint8_rtp_int8( __global int8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtp(src[tid]);
}

__kernel void test_convert_uint8_rtz_int8( __global int8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtz(src[tid]);
}

__kernel void test_convert_short8_sat_int8( __global int8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat(src[tid]);
}

__kernel void test_convert_short8_sat_rte_int8( __global int8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rte(src[tid]);
}

__kernel void test_convert_short8_sat_rtn_int8( __global int8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtn(src[tid]);
}

__kernel void test_convert_short8_sat_rtp_int8( __global int8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtp(src[tid]);
}

__kernel void test_convert_short8_sat_rtz_int8( __global int8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtz(src[tid]);
}

__kernel void test_convert_short8_int8( __global int8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8(src[tid]);
}

__kernel void test_convert_short8_rte_int8( __global int8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rte(src[tid]);
}

__kernel void test_convert_short8_rtn_int8( __global int8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtn(src[tid]);
}

__kernel void test_convert_short8_rtp_int8( __global int8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtp(src[tid]);
}

__kernel void test_convert_short8_rtz_int8( __global int8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtz(src[tid]);
}

__kernel void test_convert_ushort8_sat_int8( __global int8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat(src[tid]);
}

__kernel void test_convert_ushort8_sat_rte_int8( __global int8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rte(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtn_int8( __global int8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtp_int8( __global int8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtz_int8( __global int8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort8_int8( __global int8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8(src[tid]);
}

__kernel void test_convert_ushort8_rte_int8( __global int8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rte(src[tid]);
}

__kernel void test_convert_ushort8_rtn_int8( __global int8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtn(src[tid]);
}

__kernel void test_convert_ushort8_rtp_int8( __global int8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtp(src[tid]);
}

__kernel void test_convert_ushort8_rtz_int8( __global int8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtz(src[tid]);
}

__kernel void test_convert_long8_sat_int8( __global int8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat(src[tid]);
}

__kernel void test_convert_long8_sat_rte_int8( __global int8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rte(src[tid]);
}

__kernel void test_convert_long8_sat_rtn_int8( __global int8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtn(src[tid]);
}

__kernel void test_convert_long8_sat_rtp_int8( __global int8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtp(src[tid]);
}

__kernel void test_convert_long8_sat_rtz_int8( __global int8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtz(src[tid]);
}

__kernel void test_convert_long8_int8( __global int8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8(src[tid]);
}

__kernel void test_convert_long8_rte_int8( __global int8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rte(src[tid]);
}

__kernel void test_convert_long8_rtn_int8( __global int8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtn(src[tid]);
}

__kernel void test_convert_long8_rtp_int8( __global int8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtp(src[tid]);
}

__kernel void test_convert_long8_rtz_int8( __global int8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtz(src[tid]);
}

__kernel void test_convert_ulong8_sat_int8( __global int8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat(src[tid]);
}

__kernel void test_convert_ulong8_sat_rte_int8( __global int8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rte(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtn_int8( __global int8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtp_int8( __global int8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtz_int8( __global int8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong8_int8( __global int8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8(src[tid]);
}

__kernel void test_convert_ulong8_rte_int8( __global int8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rte(src[tid]);
}

__kernel void test_convert_ulong8_rtn_int8( __global int8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtn(src[tid]);
}

__kernel void test_convert_ulong8_rtp_int8( __global int8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtp(src[tid]);
}

__kernel void test_convert_ulong8_rtz_int8( __global int8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtz(src[tid]);
}

__kernel void test_convert_float8_int8( __global int8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8(src[tid]);
}

__kernel void test_convert_float8_rte_int8( __global int8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rte(src[tid]);
}

__kernel void test_convert_float8_rtn_int8( __global int8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtn(src[tid]);
}

__kernel void test_convert_float8_rtp_int8( __global int8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtp(src[tid]);
}

__kernel void test_convert_float8_rtz_int8( __global int8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtz(src[tid]);
}

__kernel void test_convert_double8_int8( __global int8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8(src[tid]);
}

__kernel void test_convert_double8_rte_int8( __global int8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rte(src[tid]);
}

__kernel void test_convert_double8_rtn_int8( __global int8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtn(src[tid]);
}

__kernel void test_convert_double8_rtp_int8( __global int8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtp(src[tid]);
}

__kernel void test_convert_double8_rtz_int8( __global int8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtz(src[tid]);
}

__kernel void test_convert_char8_sat_uint8( __global uint8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat(src[tid]);
}

__kernel void test_convert_char8_sat_rte_uint8( __global uint8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rte(src[tid]);
}

__kernel void test_convert_char8_sat_rtn_uint8( __global uint8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtn(src[tid]);
}

__kernel void test_convert_char8_sat_rtp_uint8( __global uint8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtp(src[tid]);
}

__kernel void test_convert_char8_sat_rtz_uint8( __global uint8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtz(src[tid]);
}

__kernel void test_convert_char8_uint8( __global uint8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8(src[tid]);
}

__kernel void test_convert_char8_rte_uint8( __global uint8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rte(src[tid]);
}

__kernel void test_convert_char8_rtn_uint8( __global uint8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtn(src[tid]);
}

__kernel void test_convert_char8_rtp_uint8( __global uint8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtp(src[tid]);
}

__kernel void test_convert_char8_rtz_uint8( __global uint8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtz(src[tid]);
}

__kernel void test_convert_uchar8_sat_uint8( __global uint8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat(src[tid]);
}

__kernel void test_convert_uchar8_sat_rte_uint8( __global uint8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rte(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtn_uint8( __global uint8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtp_uint8( __global uint8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtz_uint8( __global uint8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar8_uint8( __global uint8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8(src[tid]);
}

__kernel void test_convert_uchar8_rte_uint8( __global uint8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rte(src[tid]);
}

__kernel void test_convert_uchar8_rtn_uint8( __global uint8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtn(src[tid]);
}

__kernel void test_convert_uchar8_rtp_uint8( __global uint8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtp(src[tid]);
}

__kernel void test_convert_uchar8_rtz_uint8( __global uint8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtz(src[tid]);
}

__kernel void test_convert_int8_sat_uint8( __global uint8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat(src[tid]);
}

__kernel void test_convert_int8_sat_rte_uint8( __global uint8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rte(src[tid]);
}

__kernel void test_convert_int8_sat_rtn_uint8( __global uint8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtn(src[tid]);
}

__kernel void test_convert_int8_sat_rtp_uint8( __global uint8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtp(src[tid]);
}

__kernel void test_convert_int8_sat_rtz_uint8( __global uint8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtz(src[tid]);
}

__kernel void test_convert_int8_uint8( __global uint8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8(src[tid]);
}

__kernel void test_convert_int8_rte_uint8( __global uint8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rte(src[tid]);
}

__kernel void test_convert_int8_rtn_uint8( __global uint8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtn(src[tid]);
}

__kernel void test_convert_int8_rtp_uint8( __global uint8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtp(src[tid]);
}

__kernel void test_convert_int8_rtz_uint8( __global uint8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtz(src[tid]);
}

__kernel void test_convert_uint8_sat_uint8( __global uint8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat(src[tid]);
}

__kernel void test_convert_uint8_sat_rte_uint8( __global uint8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rte(src[tid]);
}

__kernel void test_convert_uint8_sat_rtn_uint8( __global uint8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtn(src[tid]);
}

__kernel void test_convert_uint8_sat_rtp_uint8( __global uint8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtp(src[tid]);
}

__kernel void test_convert_uint8_sat_rtz_uint8( __global uint8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtz(src[tid]);
}

__kernel void test_convert_uint8_uint8( __global uint8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8(src[tid]);
}

__kernel void test_convert_uint8_rte_uint8( __global uint8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rte(src[tid]);
}

__kernel void test_convert_uint8_rtn_uint8( __global uint8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtn(src[tid]);
}

__kernel void test_convert_uint8_rtp_uint8( __global uint8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtp(src[tid]);
}

__kernel void test_convert_uint8_rtz_uint8( __global uint8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtz(src[tid]);
}

__kernel void test_convert_short8_sat_uint8( __global uint8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat(src[tid]);
}

__kernel void test_convert_short8_sat_rte_uint8( __global uint8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rte(src[tid]);
}

__kernel void test_convert_short8_sat_rtn_uint8( __global uint8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtn(src[tid]);
}

__kernel void test_convert_short8_sat_rtp_uint8( __global uint8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtp(src[tid]);
}

__kernel void test_convert_short8_sat_rtz_uint8( __global uint8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtz(src[tid]);
}

__kernel void test_convert_short8_uint8( __global uint8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8(src[tid]);
}

__kernel void test_convert_short8_rte_uint8( __global uint8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rte(src[tid]);
}

__kernel void test_convert_short8_rtn_uint8( __global uint8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtn(src[tid]);
}

__kernel void test_convert_short8_rtp_uint8( __global uint8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtp(src[tid]);
}

__kernel void test_convert_short8_rtz_uint8( __global uint8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtz(src[tid]);
}

__kernel void test_convert_ushort8_sat_uint8( __global uint8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat(src[tid]);
}

__kernel void test_convert_ushort8_sat_rte_uint8( __global uint8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rte(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtn_uint8( __global uint8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtp_uint8( __global uint8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtz_uint8( __global uint8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort8_uint8( __global uint8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8(src[tid]);
}

__kernel void test_convert_ushort8_rte_uint8( __global uint8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rte(src[tid]);
}

__kernel void test_convert_ushort8_rtn_uint8( __global uint8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtn(src[tid]);
}

__kernel void test_convert_ushort8_rtp_uint8( __global uint8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtp(src[tid]);
}

__kernel void test_convert_ushort8_rtz_uint8( __global uint8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtz(src[tid]);
}

__kernel void test_convert_long8_sat_uint8( __global uint8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat(src[tid]);
}

__kernel void test_convert_long8_sat_rte_uint8( __global uint8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rte(src[tid]);
}

__kernel void test_convert_long8_sat_rtn_uint8( __global uint8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtn(src[tid]);
}

__kernel void test_convert_long8_sat_rtp_uint8( __global uint8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtp(src[tid]);
}

__kernel void test_convert_long8_sat_rtz_uint8( __global uint8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtz(src[tid]);
}

__kernel void test_convert_long8_uint8( __global uint8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8(src[tid]);
}

__kernel void test_convert_long8_rte_uint8( __global uint8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rte(src[tid]);
}

__kernel void test_convert_long8_rtn_uint8( __global uint8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtn(src[tid]);
}

__kernel void test_convert_long8_rtp_uint8( __global uint8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtp(src[tid]);
}

__kernel void test_convert_long8_rtz_uint8( __global uint8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtz(src[tid]);
}

__kernel void test_convert_ulong8_sat_uint8( __global uint8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat(src[tid]);
}

__kernel void test_convert_ulong8_sat_rte_uint8( __global uint8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rte(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtn_uint8( __global uint8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtp_uint8( __global uint8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtz_uint8( __global uint8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong8_uint8( __global uint8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8(src[tid]);
}

__kernel void test_convert_ulong8_rte_uint8( __global uint8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rte(src[tid]);
}

__kernel void test_convert_ulong8_rtn_uint8( __global uint8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtn(src[tid]);
}

__kernel void test_convert_ulong8_rtp_uint8( __global uint8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtp(src[tid]);
}

__kernel void test_convert_ulong8_rtz_uint8( __global uint8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtz(src[tid]);
}

__kernel void test_convert_float8_uint8( __global uint8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8(src[tid]);
}

__kernel void test_convert_float8_rte_uint8( __global uint8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rte(src[tid]);
}

__kernel void test_convert_float8_rtn_uint8( __global uint8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtn(src[tid]);
}

__kernel void test_convert_float8_rtp_uint8( __global uint8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtp(src[tid]);
}

__kernel void test_convert_float8_rtz_uint8( __global uint8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtz(src[tid]);
}

__kernel void test_convert_double8_uint8( __global uint8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8(src[tid]);
}

__kernel void test_convert_double8_rte_uint8( __global uint8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rte(src[tid]);
}

__kernel void test_convert_double8_rtn_uint8( __global uint8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtn(src[tid]);
}

__kernel void test_convert_double8_rtp_uint8( __global uint8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtp(src[tid]);
}

__kernel void test_convert_double8_rtz_uint8( __global uint8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtz(src[tid]);
}

__kernel void test_convert_char8_sat_short8( __global short8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat(src[tid]);
}

__kernel void test_convert_char8_sat_rte_short8( __global short8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rte(src[tid]);
}

__kernel void test_convert_char8_sat_rtn_short8( __global short8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtn(src[tid]);
}

__kernel void test_convert_char8_sat_rtp_short8( __global short8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtp(src[tid]);
}

__kernel void test_convert_char8_sat_rtz_short8( __global short8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtz(src[tid]);
}

__kernel void test_convert_char8_short8( __global short8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8(src[tid]);
}

__kernel void test_convert_char8_rte_short8( __global short8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rte(src[tid]);
}

__kernel void test_convert_char8_rtn_short8( __global short8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtn(src[tid]);
}

__kernel void test_convert_char8_rtp_short8( __global short8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtp(src[tid]);
}

__kernel void test_convert_char8_rtz_short8( __global short8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtz(src[tid]);
}

__kernel void test_convert_uchar8_sat_short8( __global short8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat(src[tid]);
}

__kernel void test_convert_uchar8_sat_rte_short8( __global short8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rte(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtn_short8( __global short8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtp_short8( __global short8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtz_short8( __global short8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar8_short8( __global short8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8(src[tid]);
}

__kernel void test_convert_uchar8_rte_short8( __global short8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rte(src[tid]);
}

__kernel void test_convert_uchar8_rtn_short8( __global short8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtn(src[tid]);
}

__kernel void test_convert_uchar8_rtp_short8( __global short8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtp(src[tid]);
}

__kernel void test_convert_uchar8_rtz_short8( __global short8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtz(src[tid]);
}

__kernel void test_convert_int8_sat_short8( __global short8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat(src[tid]);
}

__kernel void test_convert_int8_sat_rte_short8( __global short8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rte(src[tid]);
}

__kernel void test_convert_int8_sat_rtn_short8( __global short8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtn(src[tid]);
}

__kernel void test_convert_int8_sat_rtp_short8( __global short8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtp(src[tid]);
}

__kernel void test_convert_int8_sat_rtz_short8( __global short8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtz(src[tid]);
}

__kernel void test_convert_int8_short8( __global short8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8(src[tid]);
}

__kernel void test_convert_int8_rte_short8( __global short8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rte(src[tid]);
}

__kernel void test_convert_int8_rtn_short8( __global short8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtn(src[tid]);
}

__kernel void test_convert_int8_rtp_short8( __global short8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtp(src[tid]);
}

__kernel void test_convert_int8_rtz_short8( __global short8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtz(src[tid]);
}

__kernel void test_convert_uint8_sat_short8( __global short8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat(src[tid]);
}

__kernel void test_convert_uint8_sat_rte_short8( __global short8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rte(src[tid]);
}

__kernel void test_convert_uint8_sat_rtn_short8( __global short8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtn(src[tid]);
}

__kernel void test_convert_uint8_sat_rtp_short8( __global short8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtp(src[tid]);
}

__kernel void test_convert_uint8_sat_rtz_short8( __global short8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtz(src[tid]);
}

__kernel void test_convert_uint8_short8( __global short8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8(src[tid]);
}

__kernel void test_convert_uint8_rte_short8( __global short8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rte(src[tid]);
}

__kernel void test_convert_uint8_rtn_short8( __global short8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtn(src[tid]);
}

__kernel void test_convert_uint8_rtp_short8( __global short8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtp(src[tid]);
}

__kernel void test_convert_uint8_rtz_short8( __global short8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtz(src[tid]);
}

__kernel void test_convert_short8_sat_short8( __global short8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat(src[tid]);
}

__kernel void test_convert_short8_sat_rte_short8( __global short8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rte(src[tid]);
}

__kernel void test_convert_short8_sat_rtn_short8( __global short8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtn(src[tid]);
}

__kernel void test_convert_short8_sat_rtp_short8( __global short8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtp(src[tid]);
}

__kernel void test_convert_short8_sat_rtz_short8( __global short8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtz(src[tid]);
}

__kernel void test_convert_short8_short8( __global short8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8(src[tid]);
}

__kernel void test_convert_short8_rte_short8( __global short8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rte(src[tid]);
}

__kernel void test_convert_short8_rtn_short8( __global short8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtn(src[tid]);
}

__kernel void test_convert_short8_rtp_short8( __global short8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtp(src[tid]);
}

__kernel void test_convert_short8_rtz_short8( __global short8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtz(src[tid]);
}

__kernel void test_convert_ushort8_sat_short8( __global short8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat(src[tid]);
}

__kernel void test_convert_ushort8_sat_rte_short8( __global short8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rte(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtn_short8( __global short8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtp_short8( __global short8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtz_short8( __global short8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort8_short8( __global short8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8(src[tid]);
}

__kernel void test_convert_ushort8_rte_short8( __global short8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rte(src[tid]);
}

__kernel void test_convert_ushort8_rtn_short8( __global short8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtn(src[tid]);
}

__kernel void test_convert_ushort8_rtp_short8( __global short8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtp(src[tid]);
}

__kernel void test_convert_ushort8_rtz_short8( __global short8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtz(src[tid]);
}

__kernel void test_convert_long8_sat_short8( __global short8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat(src[tid]);
}

__kernel void test_convert_long8_sat_rte_short8( __global short8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rte(src[tid]);
}

__kernel void test_convert_long8_sat_rtn_short8( __global short8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtn(src[tid]);
}

__kernel void test_convert_long8_sat_rtp_short8( __global short8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtp(src[tid]);
}

__kernel void test_convert_long8_sat_rtz_short8( __global short8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtz(src[tid]);
}

__kernel void test_convert_long8_short8( __global short8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8(src[tid]);
}

__kernel void test_convert_long8_rte_short8( __global short8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rte(src[tid]);
}

__kernel void test_convert_long8_rtn_short8( __global short8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtn(src[tid]);
}

__kernel void test_convert_long8_rtp_short8( __global short8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtp(src[tid]);
}

__kernel void test_convert_long8_rtz_short8( __global short8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtz(src[tid]);
}

__kernel void test_convert_ulong8_sat_short8( __global short8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat(src[tid]);
}

__kernel void test_convert_ulong8_sat_rte_short8( __global short8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rte(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtn_short8( __global short8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtp_short8( __global short8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtz_short8( __global short8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong8_short8( __global short8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8(src[tid]);
}

__kernel void test_convert_ulong8_rte_short8( __global short8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rte(src[tid]);
}

__kernel void test_convert_ulong8_rtn_short8( __global short8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtn(src[tid]);
}

__kernel void test_convert_ulong8_rtp_short8( __global short8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtp(src[tid]);
}

__kernel void test_convert_ulong8_rtz_short8( __global short8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtz(src[tid]);
}

__kernel void test_convert_float8_short8( __global short8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8(src[tid]);
}

__kernel void test_convert_float8_rte_short8( __global short8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rte(src[tid]);
}

__kernel void test_convert_float8_rtn_short8( __global short8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtn(src[tid]);
}

__kernel void test_convert_float8_rtp_short8( __global short8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtp(src[tid]);
}

__kernel void test_convert_float8_rtz_short8( __global short8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtz(src[tid]);
}

__kernel void test_convert_double8_short8( __global short8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8(src[tid]);
}

__kernel void test_convert_double8_rte_short8( __global short8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rte(src[tid]);
}

__kernel void test_convert_double8_rtn_short8( __global short8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtn(src[tid]);
}

__kernel void test_convert_double8_rtp_short8( __global short8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtp(src[tid]);
}

__kernel void test_convert_double8_rtz_short8( __global short8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtz(src[tid]);
}

__kernel void test_convert_char8_sat_ushort8( __global ushort8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat(src[tid]);
}

__kernel void test_convert_char8_sat_rte_ushort8( __global ushort8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rte(src[tid]);
}

__kernel void test_convert_char8_sat_rtn_ushort8( __global ushort8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtn(src[tid]);
}

__kernel void test_convert_char8_sat_rtp_ushort8( __global ushort8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtp(src[tid]);
}

__kernel void test_convert_char8_sat_rtz_ushort8( __global ushort8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtz(src[tid]);
}

__kernel void test_convert_char8_ushort8( __global ushort8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8(src[tid]);
}

__kernel void test_convert_char8_rte_ushort8( __global ushort8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rte(src[tid]);
}

__kernel void test_convert_char8_rtn_ushort8( __global ushort8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtn(src[tid]);
}

__kernel void test_convert_char8_rtp_ushort8( __global ushort8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtp(src[tid]);
}

__kernel void test_convert_char8_rtz_ushort8( __global ushort8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtz(src[tid]);
}

__kernel void test_convert_uchar8_sat_ushort8( __global ushort8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat(src[tid]);
}

__kernel void test_convert_uchar8_sat_rte_ushort8( __global ushort8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rte(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtn_ushort8( __global ushort8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtp_ushort8( __global ushort8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtz_ushort8( __global ushort8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar8_ushort8( __global ushort8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8(src[tid]);
}

__kernel void test_convert_uchar8_rte_ushort8( __global ushort8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rte(src[tid]);
}

__kernel void test_convert_uchar8_rtn_ushort8( __global ushort8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtn(src[tid]);
}

__kernel void test_convert_uchar8_rtp_ushort8( __global ushort8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtp(src[tid]);
}

__kernel void test_convert_uchar8_rtz_ushort8( __global ushort8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtz(src[tid]);
}

__kernel void test_convert_int8_sat_ushort8( __global ushort8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat(src[tid]);
}

__kernel void test_convert_int8_sat_rte_ushort8( __global ushort8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rte(src[tid]);
}

__kernel void test_convert_int8_sat_rtn_ushort8( __global ushort8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtn(src[tid]);
}

__kernel void test_convert_int8_sat_rtp_ushort8( __global ushort8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtp(src[tid]);
}

__kernel void test_convert_int8_sat_rtz_ushort8( __global ushort8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtz(src[tid]);
}

__kernel void test_convert_int8_ushort8( __global ushort8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8(src[tid]);
}

__kernel void test_convert_int8_rte_ushort8( __global ushort8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rte(src[tid]);
}

__kernel void test_convert_int8_rtn_ushort8( __global ushort8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtn(src[tid]);
}

__kernel void test_convert_int8_rtp_ushort8( __global ushort8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtp(src[tid]);
}

__kernel void test_convert_int8_rtz_ushort8( __global ushort8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtz(src[tid]);
}

__kernel void test_convert_uint8_sat_ushort8( __global ushort8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat(src[tid]);
}

__kernel void test_convert_uint8_sat_rte_ushort8( __global ushort8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rte(src[tid]);
}

__kernel void test_convert_uint8_sat_rtn_ushort8( __global ushort8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtn(src[tid]);
}

__kernel void test_convert_uint8_sat_rtp_ushort8( __global ushort8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtp(src[tid]);
}

__kernel void test_convert_uint8_sat_rtz_ushort8( __global ushort8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtz(src[tid]);
}

__kernel void test_convert_uint8_ushort8( __global ushort8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8(src[tid]);
}

__kernel void test_convert_uint8_rte_ushort8( __global ushort8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rte(src[tid]);
}

__kernel void test_convert_uint8_rtn_ushort8( __global ushort8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtn(src[tid]);
}

__kernel void test_convert_uint8_rtp_ushort8( __global ushort8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtp(src[tid]);
}

__kernel void test_convert_uint8_rtz_ushort8( __global ushort8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtz(src[tid]);
}

__kernel void test_convert_short8_sat_ushort8( __global ushort8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat(src[tid]);
}

__kernel void test_convert_short8_sat_rte_ushort8( __global ushort8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rte(src[tid]);
}

__kernel void test_convert_short8_sat_rtn_ushort8( __global ushort8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtn(src[tid]);
}

__kernel void test_convert_short8_sat_rtp_ushort8( __global ushort8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtp(src[tid]);
}

__kernel void test_convert_short8_sat_rtz_ushort8( __global ushort8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtz(src[tid]);
}

__kernel void test_convert_short8_ushort8( __global ushort8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8(src[tid]);
}

__kernel void test_convert_short8_rte_ushort8( __global ushort8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rte(src[tid]);
}

__kernel void test_convert_short8_rtn_ushort8( __global ushort8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtn(src[tid]);
}

__kernel void test_convert_short8_rtp_ushort8( __global ushort8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtp(src[tid]);
}

__kernel void test_convert_short8_rtz_ushort8( __global ushort8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtz(src[tid]);
}

__kernel void test_convert_ushort8_sat_ushort8( __global ushort8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat(src[tid]);
}

__kernel void test_convert_ushort8_sat_rte_ushort8( __global ushort8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rte(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtn_ushort8( __global ushort8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtp_ushort8( __global ushort8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtz_ushort8( __global ushort8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort8_ushort8( __global ushort8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8(src[tid]);
}

__kernel void test_convert_ushort8_rte_ushort8( __global ushort8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rte(src[tid]);
}

__kernel void test_convert_ushort8_rtn_ushort8( __global ushort8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtn(src[tid]);
}

__kernel void test_convert_ushort8_rtp_ushort8( __global ushort8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtp(src[tid]);
}

__kernel void test_convert_ushort8_rtz_ushort8( __global ushort8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtz(src[tid]);
}

__kernel void test_convert_long8_sat_ushort8( __global ushort8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat(src[tid]);
}

__kernel void test_convert_long8_sat_rte_ushort8( __global ushort8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rte(src[tid]);
}

__kernel void test_convert_long8_sat_rtn_ushort8( __global ushort8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtn(src[tid]);
}

__kernel void test_convert_long8_sat_rtp_ushort8( __global ushort8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtp(src[tid]);
}

__kernel void test_convert_long8_sat_rtz_ushort8( __global ushort8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtz(src[tid]);
}

__kernel void test_convert_long8_ushort8( __global ushort8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8(src[tid]);
}

__kernel void test_convert_long8_rte_ushort8( __global ushort8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rte(src[tid]);
}

__kernel void test_convert_long8_rtn_ushort8( __global ushort8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtn(src[tid]);
}

__kernel void test_convert_long8_rtp_ushort8( __global ushort8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtp(src[tid]);
}

__kernel void test_convert_long8_rtz_ushort8( __global ushort8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtz(src[tid]);
}

__kernel void test_convert_ulong8_sat_ushort8( __global ushort8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat(src[tid]);
}

__kernel void test_convert_ulong8_sat_rte_ushort8( __global ushort8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rte(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtn_ushort8( __global ushort8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtp_ushort8( __global ushort8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtz_ushort8( __global ushort8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong8_ushort8( __global ushort8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8(src[tid]);
}

__kernel void test_convert_ulong8_rte_ushort8( __global ushort8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rte(src[tid]);
}

__kernel void test_convert_ulong8_rtn_ushort8( __global ushort8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtn(src[tid]);
}

__kernel void test_convert_ulong8_rtp_ushort8( __global ushort8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtp(src[tid]);
}

__kernel void test_convert_ulong8_rtz_ushort8( __global ushort8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtz(src[tid]);
}

__kernel void test_convert_float8_ushort8( __global ushort8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8(src[tid]);
}

__kernel void test_convert_float8_rte_ushort8( __global ushort8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rte(src[tid]);
}

__kernel void test_convert_float8_rtn_ushort8( __global ushort8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtn(src[tid]);
}

__kernel void test_convert_float8_rtp_ushort8( __global ushort8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtp(src[tid]);
}

__kernel void test_convert_float8_rtz_ushort8( __global ushort8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtz(src[tid]);
}

__kernel void test_convert_double8_ushort8( __global ushort8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8(src[tid]);
}

__kernel void test_convert_double8_rte_ushort8( __global ushort8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rte(src[tid]);
}

__kernel void test_convert_double8_rtn_ushort8( __global ushort8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtn(src[tid]);
}

__kernel void test_convert_double8_rtp_ushort8( __global ushort8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtp(src[tid]);
}

__kernel void test_convert_double8_rtz_ushort8( __global ushort8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtz(src[tid]);
}

__kernel void test_convert_char8_sat_long8( __global long8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat(src[tid]);
}

__kernel void test_convert_char8_sat_rte_long8( __global long8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rte(src[tid]);
}

__kernel void test_convert_char8_sat_rtn_long8( __global long8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtn(src[tid]);
}

__kernel void test_convert_char8_sat_rtp_long8( __global long8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtp(src[tid]);
}

__kernel void test_convert_char8_sat_rtz_long8( __global long8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtz(src[tid]);
}

__kernel void test_convert_char8_long8( __global long8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8(src[tid]);
}

__kernel void test_convert_char8_rte_long8( __global long8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rte(src[tid]);
}

__kernel void test_convert_char8_rtn_long8( __global long8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtn(src[tid]);
}

__kernel void test_convert_char8_rtp_long8( __global long8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtp(src[tid]);
}

__kernel void test_convert_char8_rtz_long8( __global long8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtz(src[tid]);
}

__kernel void test_convert_uchar8_sat_long8( __global long8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat(src[tid]);
}

__kernel void test_convert_uchar8_sat_rte_long8( __global long8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rte(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtn_long8( __global long8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtp_long8( __global long8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtz_long8( __global long8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar8_long8( __global long8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8(src[tid]);
}

__kernel void test_convert_uchar8_rte_long8( __global long8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rte(src[tid]);
}

__kernel void test_convert_uchar8_rtn_long8( __global long8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtn(src[tid]);
}

__kernel void test_convert_uchar8_rtp_long8( __global long8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtp(src[tid]);
}

__kernel void test_convert_uchar8_rtz_long8( __global long8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtz(src[tid]);
}

__kernel void test_convert_int8_sat_long8( __global long8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat(src[tid]);
}

__kernel void test_convert_int8_sat_rte_long8( __global long8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rte(src[tid]);
}

__kernel void test_convert_int8_sat_rtn_long8( __global long8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtn(src[tid]);
}

__kernel void test_convert_int8_sat_rtp_long8( __global long8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtp(src[tid]);
}

__kernel void test_convert_int8_sat_rtz_long8( __global long8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtz(src[tid]);
}

__kernel void test_convert_int8_long8( __global long8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8(src[tid]);
}

__kernel void test_convert_int8_rte_long8( __global long8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rte(src[tid]);
}

__kernel void test_convert_int8_rtn_long8( __global long8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtn(src[tid]);
}

__kernel void test_convert_int8_rtp_long8( __global long8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtp(src[tid]);
}

__kernel void test_convert_int8_rtz_long8( __global long8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtz(src[tid]);
}

__kernel void test_convert_uint8_sat_long8( __global long8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat(src[tid]);
}

__kernel void test_convert_uint8_sat_rte_long8( __global long8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rte(src[tid]);
}

__kernel void test_convert_uint8_sat_rtn_long8( __global long8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtn(src[tid]);
}

__kernel void test_convert_uint8_sat_rtp_long8( __global long8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtp(src[tid]);
}

__kernel void test_convert_uint8_sat_rtz_long8( __global long8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtz(src[tid]);
}

__kernel void test_convert_uint8_long8( __global long8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8(src[tid]);
}

__kernel void test_convert_uint8_rte_long8( __global long8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rte(src[tid]);
}

__kernel void test_convert_uint8_rtn_long8( __global long8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtn(src[tid]);
}

__kernel void test_convert_uint8_rtp_long8( __global long8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtp(src[tid]);
}

__kernel void test_convert_uint8_rtz_long8( __global long8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtz(src[tid]);
}

__kernel void test_convert_short8_sat_long8( __global long8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat(src[tid]);
}

__kernel void test_convert_short8_sat_rte_long8( __global long8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rte(src[tid]);
}

__kernel void test_convert_short8_sat_rtn_long8( __global long8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtn(src[tid]);
}

__kernel void test_convert_short8_sat_rtp_long8( __global long8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtp(src[tid]);
}

__kernel void test_convert_short8_sat_rtz_long8( __global long8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtz(src[tid]);
}

__kernel void test_convert_short8_long8( __global long8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8(src[tid]);
}

__kernel void test_convert_short8_rte_long8( __global long8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rte(src[tid]);
}

__kernel void test_convert_short8_rtn_long8( __global long8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtn(src[tid]);
}

__kernel void test_convert_short8_rtp_long8( __global long8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtp(src[tid]);
}

__kernel void test_convert_short8_rtz_long8( __global long8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtz(src[tid]);
}

__kernel void test_convert_ushort8_sat_long8( __global long8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat(src[tid]);
}

__kernel void test_convert_ushort8_sat_rte_long8( __global long8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rte(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtn_long8( __global long8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtp_long8( __global long8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtz_long8( __global long8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort8_long8( __global long8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8(src[tid]);
}

__kernel void test_convert_ushort8_rte_long8( __global long8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rte(src[tid]);
}

__kernel void test_convert_ushort8_rtn_long8( __global long8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtn(src[tid]);
}

__kernel void test_convert_ushort8_rtp_long8( __global long8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtp(src[tid]);
}

__kernel void test_convert_ushort8_rtz_long8( __global long8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtz(src[tid]);
}

__kernel void test_convert_long8_sat_long8( __global long8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat(src[tid]);
}

__kernel void test_convert_long8_sat_rte_long8( __global long8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rte(src[tid]);
}

__kernel void test_convert_long8_sat_rtn_long8( __global long8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtn(src[tid]);
}

__kernel void test_convert_long8_sat_rtp_long8( __global long8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtp(src[tid]);
}

__kernel void test_convert_long8_sat_rtz_long8( __global long8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtz(src[tid]);
}

__kernel void test_convert_long8_long8( __global long8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8(src[tid]);
}

__kernel void test_convert_long8_rte_long8( __global long8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rte(src[tid]);
}

__kernel void test_convert_long8_rtn_long8( __global long8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtn(src[tid]);
}

__kernel void test_convert_long8_rtp_long8( __global long8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtp(src[tid]);
}

__kernel void test_convert_long8_rtz_long8( __global long8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtz(src[tid]);
}

__kernel void test_convert_ulong8_sat_long8( __global long8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat(src[tid]);
}

__kernel void test_convert_ulong8_sat_rte_long8( __global long8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rte(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtn_long8( __global long8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtp_long8( __global long8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtz_long8( __global long8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong8_long8( __global long8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8(src[tid]);
}

__kernel void test_convert_ulong8_rte_long8( __global long8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rte(src[tid]);
}

__kernel void test_convert_ulong8_rtn_long8( __global long8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtn(src[tid]);
}

__kernel void test_convert_ulong8_rtp_long8( __global long8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtp(src[tid]);
}

__kernel void test_convert_ulong8_rtz_long8( __global long8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtz(src[tid]);
}

__kernel void test_convert_float8_long8( __global long8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8(src[tid]);
}

__kernel void test_convert_float8_rte_long8( __global long8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rte(src[tid]);
}

__kernel void test_convert_float8_rtn_long8( __global long8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtn(src[tid]);
}

__kernel void test_convert_float8_rtp_long8( __global long8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtp(src[tid]);
}

__kernel void test_convert_float8_rtz_long8( __global long8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtz(src[tid]);
}

__kernel void test_convert_double8_long8( __global long8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8(src[tid]);
}

__kernel void test_convert_double8_rte_long8( __global long8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rte(src[tid]);
}

__kernel void test_convert_double8_rtn_long8( __global long8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtn(src[tid]);
}

__kernel void test_convert_double8_rtp_long8( __global long8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtp(src[tid]);
}

__kernel void test_convert_double8_rtz_long8( __global long8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtz(src[tid]);
}

__kernel void test_convert_char8_sat_ulong8( __global ulong8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat(src[tid]);
}

__kernel void test_convert_char8_sat_rte_ulong8( __global ulong8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rte(src[tid]);
}

__kernel void test_convert_char8_sat_rtn_ulong8( __global ulong8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtn(src[tid]);
}

__kernel void test_convert_char8_sat_rtp_ulong8( __global ulong8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtp(src[tid]);
}

__kernel void test_convert_char8_sat_rtz_ulong8( __global ulong8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtz(src[tid]);
}

__kernel void test_convert_char8_ulong8( __global ulong8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8(src[tid]);
}

__kernel void test_convert_char8_rte_ulong8( __global ulong8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rte(src[tid]);
}

__kernel void test_convert_char8_rtn_ulong8( __global ulong8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtn(src[tid]);
}

__kernel void test_convert_char8_rtp_ulong8( __global ulong8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtp(src[tid]);
}

__kernel void test_convert_char8_rtz_ulong8( __global ulong8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtz(src[tid]);
}

__kernel void test_convert_uchar8_sat_ulong8( __global ulong8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat(src[tid]);
}

__kernel void test_convert_uchar8_sat_rte_ulong8( __global ulong8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rte(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtn_ulong8( __global ulong8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtp_ulong8( __global ulong8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtz_ulong8( __global ulong8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar8_ulong8( __global ulong8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8(src[tid]);
}

__kernel void test_convert_uchar8_rte_ulong8( __global ulong8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rte(src[tid]);
}

__kernel void test_convert_uchar8_rtn_ulong8( __global ulong8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtn(src[tid]);
}

__kernel void test_convert_uchar8_rtp_ulong8( __global ulong8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtp(src[tid]);
}

__kernel void test_convert_uchar8_rtz_ulong8( __global ulong8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtz(src[tid]);
}

__kernel void test_convert_int8_sat_ulong8( __global ulong8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat(src[tid]);
}

__kernel void test_convert_int8_sat_rte_ulong8( __global ulong8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rte(src[tid]);
}

__kernel void test_convert_int8_sat_rtn_ulong8( __global ulong8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtn(src[tid]);
}

__kernel void test_convert_int8_sat_rtp_ulong8( __global ulong8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtp(src[tid]);
}

__kernel void test_convert_int8_sat_rtz_ulong8( __global ulong8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtz(src[tid]);
}

__kernel void test_convert_int8_ulong8( __global ulong8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8(src[tid]);
}

__kernel void test_convert_int8_rte_ulong8( __global ulong8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rte(src[tid]);
}

__kernel void test_convert_int8_rtn_ulong8( __global ulong8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtn(src[tid]);
}

__kernel void test_convert_int8_rtp_ulong8( __global ulong8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtp(src[tid]);
}

__kernel void test_convert_int8_rtz_ulong8( __global ulong8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtz(src[tid]);
}

__kernel void test_convert_uint8_sat_ulong8( __global ulong8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat(src[tid]);
}

__kernel void test_convert_uint8_sat_rte_ulong8( __global ulong8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rte(src[tid]);
}

__kernel void test_convert_uint8_sat_rtn_ulong8( __global ulong8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtn(src[tid]);
}

__kernel void test_convert_uint8_sat_rtp_ulong8( __global ulong8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtp(src[tid]);
}

__kernel void test_convert_uint8_sat_rtz_ulong8( __global ulong8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtz(src[tid]);
}

__kernel void test_convert_uint8_ulong8( __global ulong8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8(src[tid]);
}

__kernel void test_convert_uint8_rte_ulong8( __global ulong8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rte(src[tid]);
}

__kernel void test_convert_uint8_rtn_ulong8( __global ulong8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtn(src[tid]);
}

__kernel void test_convert_uint8_rtp_ulong8( __global ulong8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtp(src[tid]);
}

__kernel void test_convert_uint8_rtz_ulong8( __global ulong8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtz(src[tid]);
}

__kernel void test_convert_short8_sat_ulong8( __global ulong8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat(src[tid]);
}

__kernel void test_convert_short8_sat_rte_ulong8( __global ulong8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rte(src[tid]);
}

__kernel void test_convert_short8_sat_rtn_ulong8( __global ulong8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtn(src[tid]);
}

__kernel void test_convert_short8_sat_rtp_ulong8( __global ulong8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtp(src[tid]);
}

__kernel void test_convert_short8_sat_rtz_ulong8( __global ulong8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtz(src[tid]);
}

__kernel void test_convert_short8_ulong8( __global ulong8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8(src[tid]);
}

__kernel void test_convert_short8_rte_ulong8( __global ulong8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rte(src[tid]);
}

__kernel void test_convert_short8_rtn_ulong8( __global ulong8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtn(src[tid]);
}

__kernel void test_convert_short8_rtp_ulong8( __global ulong8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtp(src[tid]);
}

__kernel void test_convert_short8_rtz_ulong8( __global ulong8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtz(src[tid]);
}

__kernel void test_convert_ushort8_sat_ulong8( __global ulong8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat(src[tid]);
}

__kernel void test_convert_ushort8_sat_rte_ulong8( __global ulong8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rte(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtn_ulong8( __global ulong8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtp_ulong8( __global ulong8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtz_ulong8( __global ulong8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort8_ulong8( __global ulong8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8(src[tid]);
}

__kernel void test_convert_ushort8_rte_ulong8( __global ulong8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rte(src[tid]);
}

__kernel void test_convert_ushort8_rtn_ulong8( __global ulong8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtn(src[tid]);
}

__kernel void test_convert_ushort8_rtp_ulong8( __global ulong8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtp(src[tid]);
}

__kernel void test_convert_ushort8_rtz_ulong8( __global ulong8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtz(src[tid]);
}

__kernel void test_convert_long8_sat_ulong8( __global ulong8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat(src[tid]);
}

__kernel void test_convert_long8_sat_rte_ulong8( __global ulong8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rte(src[tid]);
}

__kernel void test_convert_long8_sat_rtn_ulong8( __global ulong8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtn(src[tid]);
}

__kernel void test_convert_long8_sat_rtp_ulong8( __global ulong8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtp(src[tid]);
}

__kernel void test_convert_long8_sat_rtz_ulong8( __global ulong8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtz(src[tid]);
}

__kernel void test_convert_long8_ulong8( __global ulong8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8(src[tid]);
}

__kernel void test_convert_long8_rte_ulong8( __global ulong8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rte(src[tid]);
}

__kernel void test_convert_long8_rtn_ulong8( __global ulong8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtn(src[tid]);
}

__kernel void test_convert_long8_rtp_ulong8( __global ulong8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtp(src[tid]);
}

__kernel void test_convert_long8_rtz_ulong8( __global ulong8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtz(src[tid]);
}

__kernel void test_convert_ulong8_sat_ulong8( __global ulong8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat(src[tid]);
}

__kernel void test_convert_ulong8_sat_rte_ulong8( __global ulong8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rte(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtn_ulong8( __global ulong8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtp_ulong8( __global ulong8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtz_ulong8( __global ulong8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong8_ulong8( __global ulong8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8(src[tid]);
}

__kernel void test_convert_ulong8_rte_ulong8( __global ulong8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rte(src[tid]);
}

__kernel void test_convert_ulong8_rtn_ulong8( __global ulong8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtn(src[tid]);
}

__kernel void test_convert_ulong8_rtp_ulong8( __global ulong8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtp(src[tid]);
}

__kernel void test_convert_ulong8_rtz_ulong8( __global ulong8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtz(src[tid]);
}

__kernel void test_convert_float8_ulong8( __global ulong8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8(src[tid]);
}

__kernel void test_convert_float8_rte_ulong8( __global ulong8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rte(src[tid]);
}

__kernel void test_convert_float8_rtn_ulong8( __global ulong8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtn(src[tid]);
}

__kernel void test_convert_float8_rtp_ulong8( __global ulong8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtp(src[tid]);
}

__kernel void test_convert_float8_rtz_ulong8( __global ulong8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtz(src[tid]);
}

__kernel void test_convert_double8_ulong8( __global ulong8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8(src[tid]);
}

__kernel void test_convert_double8_rte_ulong8( __global ulong8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rte(src[tid]);
}

__kernel void test_convert_double8_rtn_ulong8( __global ulong8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtn(src[tid]);
}

__kernel void test_convert_double8_rtp_ulong8( __global ulong8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtp(src[tid]);
}

__kernel void test_convert_double8_rtz_ulong8( __global ulong8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtz(src[tid]);
}

__kernel void test_convert_char8_sat_float8( __global float8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat(src[tid]);
}

__kernel void test_convert_char8_sat_rte_float8( __global float8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rte(src[tid]);
}

__kernel void test_convert_char8_sat_rtn_float8( __global float8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtn(src[tid]);
}

__kernel void test_convert_char8_sat_rtp_float8( __global float8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtp(src[tid]);
}

__kernel void test_convert_char8_sat_rtz_float8( __global float8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtz(src[tid]);
}

__kernel void test_convert_char8_float8( __global float8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8(src[tid]);
}

__kernel void test_convert_char8_rte_float8( __global float8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rte(src[tid]);
}

__kernel void test_convert_char8_rtn_float8( __global float8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtn(src[tid]);
}

__kernel void test_convert_char8_rtp_float8( __global float8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtp(src[tid]);
}

__kernel void test_convert_char8_rtz_float8( __global float8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtz(src[tid]);
}

__kernel void test_convert_uchar8_sat_float8( __global float8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat(src[tid]);
}

__kernel void test_convert_uchar8_sat_rte_float8( __global float8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rte(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtn_float8( __global float8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtp_float8( __global float8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtz_float8( __global float8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar8_float8( __global float8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8(src[tid]);
}

__kernel void test_convert_uchar8_rte_float8( __global float8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rte(src[tid]);
}

__kernel void test_convert_uchar8_rtn_float8( __global float8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtn(src[tid]);
}

__kernel void test_convert_uchar8_rtp_float8( __global float8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtp(src[tid]);
}

__kernel void test_convert_uchar8_rtz_float8( __global float8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtz(src[tid]);
}

__kernel void test_convert_int8_sat_float8( __global float8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat(src[tid]);
}

__kernel void test_convert_int8_sat_rte_float8( __global float8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rte(src[tid]);
}

__kernel void test_convert_int8_sat_rtn_float8( __global float8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtn(src[tid]);
}

__kernel void test_convert_int8_sat_rtp_float8( __global float8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtp(src[tid]);
}

__kernel void test_convert_int8_sat_rtz_float8( __global float8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtz(src[tid]);
}

__kernel void test_convert_int8_float8( __global float8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8(src[tid]);
}

__kernel void test_convert_int8_rte_float8( __global float8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rte(src[tid]);
}

__kernel void test_convert_int8_rtn_float8( __global float8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtn(src[tid]);
}

__kernel void test_convert_int8_rtp_float8( __global float8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtp(src[tid]);
}

__kernel void test_convert_int8_rtz_float8( __global float8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtz(src[tid]);
}

__kernel void test_convert_uint8_sat_float8( __global float8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat(src[tid]);
}

__kernel void test_convert_uint8_sat_rte_float8( __global float8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rte(src[tid]);
}

__kernel void test_convert_uint8_sat_rtn_float8( __global float8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtn(src[tid]);
}

__kernel void test_convert_uint8_sat_rtp_float8( __global float8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtp(src[tid]);
}

__kernel void test_convert_uint8_sat_rtz_float8( __global float8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtz(src[tid]);
}

__kernel void test_convert_uint8_float8( __global float8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8(src[tid]);
}

__kernel void test_convert_uint8_rte_float8( __global float8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rte(src[tid]);
}

__kernel void test_convert_uint8_rtn_float8( __global float8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtn(src[tid]);
}

__kernel void test_convert_uint8_rtp_float8( __global float8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtp(src[tid]);
}

__kernel void test_convert_uint8_rtz_float8( __global float8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtz(src[tid]);
}

__kernel void test_convert_short8_sat_float8( __global float8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat(src[tid]);
}

__kernel void test_convert_short8_sat_rte_float8( __global float8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rte(src[tid]);
}

__kernel void test_convert_short8_sat_rtn_float8( __global float8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtn(src[tid]);
}

__kernel void test_convert_short8_sat_rtp_float8( __global float8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtp(src[tid]);
}

__kernel void test_convert_short8_sat_rtz_float8( __global float8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtz(src[tid]);
}

__kernel void test_convert_short8_float8( __global float8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8(src[tid]);
}

__kernel void test_convert_short8_rte_float8( __global float8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rte(src[tid]);
}

__kernel void test_convert_short8_rtn_float8( __global float8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtn(src[tid]);
}

__kernel void test_convert_short8_rtp_float8( __global float8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtp(src[tid]);
}

__kernel void test_convert_short8_rtz_float8( __global float8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtz(src[tid]);
}

__kernel void test_convert_ushort8_sat_float8( __global float8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat(src[tid]);
}

__kernel void test_convert_ushort8_sat_rte_float8( __global float8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rte(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtn_float8( __global float8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtp_float8( __global float8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtz_float8( __global float8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort8_float8( __global float8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8(src[tid]);
}

__kernel void test_convert_ushort8_rte_float8( __global float8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rte(src[tid]);
}

__kernel void test_convert_ushort8_rtn_float8( __global float8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtn(src[tid]);
}

__kernel void test_convert_ushort8_rtp_float8( __global float8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtp(src[tid]);
}

__kernel void test_convert_ushort8_rtz_float8( __global float8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtz(src[tid]);
}

__kernel void test_convert_long8_sat_float8( __global float8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat(src[tid]);
}

__kernel void test_convert_long8_sat_rte_float8( __global float8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rte(src[tid]);
}

__kernel void test_convert_long8_sat_rtn_float8( __global float8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtn(src[tid]);
}

__kernel void test_convert_long8_sat_rtp_float8( __global float8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtp(src[tid]);
}

__kernel void test_convert_long8_sat_rtz_float8( __global float8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtz(src[tid]);
}

__kernel void test_convert_long8_float8( __global float8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8(src[tid]);
}

__kernel void test_convert_long8_rte_float8( __global float8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rte(src[tid]);
}

__kernel void test_convert_long8_rtn_float8( __global float8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtn(src[tid]);
}

__kernel void test_convert_long8_rtp_float8( __global float8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtp(src[tid]);
}

__kernel void test_convert_long8_rtz_float8( __global float8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtz(src[tid]);
}

__kernel void test_convert_ulong8_sat_float8( __global float8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat(src[tid]);
}

__kernel void test_convert_ulong8_sat_rte_float8( __global float8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rte(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtn_float8( __global float8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtp_float8( __global float8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtz_float8( __global float8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong8_float8( __global float8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8(src[tid]);
}

__kernel void test_convert_ulong8_rte_float8( __global float8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rte(src[tid]);
}

__kernel void test_convert_ulong8_rtn_float8( __global float8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtn(src[tid]);
}

__kernel void test_convert_ulong8_rtp_float8( __global float8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtp(src[tid]);
}

__kernel void test_convert_ulong8_rtz_float8( __global float8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtz(src[tid]);
}

__kernel void test_convert_float8_float8( __global float8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8(src[tid]);
}

__kernel void test_convert_float8_rte_float8( __global float8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rte(src[tid]);
}

__kernel void test_convert_float8_rtn_float8( __global float8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtn(src[tid]);
}

__kernel void test_convert_float8_rtp_float8( __global float8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtp(src[tid]);
}

__kernel void test_convert_float8_rtz_float8( __global float8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtz(src[tid]);
}

__kernel void test_convert_double8_float8( __global float8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8(src[tid]);
}

__kernel void test_convert_double8_rte_float8( __global float8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rte(src[tid]);
}

__kernel void test_convert_double8_rtn_float8( __global float8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtn(src[tid]);
}

__kernel void test_convert_double8_rtp_float8( __global float8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtp(src[tid]);
}

__kernel void test_convert_double8_rtz_float8( __global float8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtz(src[tid]);
}

__kernel void test_convert_char8_sat_double8( __global double8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat(src[tid]);
}

__kernel void test_convert_char8_sat_rte_double8( __global double8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rte(src[tid]);
}

__kernel void test_convert_char8_sat_rtn_double8( __global double8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtn(src[tid]);
}

__kernel void test_convert_char8_sat_rtp_double8( __global double8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtp(src[tid]);
}

__kernel void test_convert_char8_sat_rtz_double8( __global double8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtz(src[tid]);
}

__kernel void test_convert_char8_double8( __global double8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8(src[tid]);
}

__kernel void test_convert_char8_rte_double8( __global double8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rte(src[tid]);
}

__kernel void test_convert_char8_rtn_double8( __global double8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtn(src[tid]);
}

__kernel void test_convert_char8_rtp_double8( __global double8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtp(src[tid]);
}

__kernel void test_convert_char8_rtz_double8( __global double8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtz(src[tid]);
}

__kernel void test_convert_uchar8_sat_double8( __global double8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat(src[tid]);
}

__kernel void test_convert_uchar8_sat_rte_double8( __global double8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rte(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtn_double8( __global double8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtp_double8( __global double8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtz_double8( __global double8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar8_double8( __global double8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8(src[tid]);
}

__kernel void test_convert_uchar8_rte_double8( __global double8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rte(src[tid]);
}

__kernel void test_convert_uchar8_rtn_double8( __global double8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtn(src[tid]);
}

__kernel void test_convert_uchar8_rtp_double8( __global double8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtp(src[tid]);
}

__kernel void test_convert_uchar8_rtz_double8( __global double8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtz(src[tid]);
}

__kernel void test_convert_int8_sat_double8( __global double8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat(src[tid]);
}

__kernel void test_convert_int8_sat_rte_double8( __global double8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rte(src[tid]);
}

__kernel void test_convert_int8_sat_rtn_double8( __global double8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtn(src[tid]);
}

__kernel void test_convert_int8_sat_rtp_double8( __global double8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtp(src[tid]);
}

__kernel void test_convert_int8_sat_rtz_double8( __global double8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtz(src[tid]);
}

__kernel void test_convert_int8_double8( __global double8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8(src[tid]);
}

__kernel void test_convert_int8_rte_double8( __global double8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rte(src[tid]);
}

__kernel void test_convert_int8_rtn_double8( __global double8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtn(src[tid]);
}

__kernel void test_convert_int8_rtp_double8( __global double8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtp(src[tid]);
}

__kernel void test_convert_int8_rtz_double8( __global double8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtz(src[tid]);
}

__kernel void test_convert_uint8_sat_double8( __global double8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat(src[tid]);
}

__kernel void test_convert_uint8_sat_rte_double8( __global double8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rte(src[tid]);
}

__kernel void test_convert_uint8_sat_rtn_double8( __global double8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtn(src[tid]);
}

__kernel void test_convert_uint8_sat_rtp_double8( __global double8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtp(src[tid]);
}

__kernel void test_convert_uint8_sat_rtz_double8( __global double8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtz(src[tid]);
}

__kernel void test_convert_uint8_double8( __global double8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8(src[tid]);
}

__kernel void test_convert_uint8_rte_double8( __global double8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rte(src[tid]);
}

__kernel void test_convert_uint8_rtn_double8( __global double8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtn(src[tid]);
}

__kernel void test_convert_uint8_rtp_double8( __global double8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtp(src[tid]);
}

__kernel void test_convert_uint8_rtz_double8( __global double8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtz(src[tid]);
}

__kernel void test_convert_short8_sat_double8( __global double8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat(src[tid]);
}

__kernel void test_convert_short8_sat_rte_double8( __global double8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rte(src[tid]);
}

__kernel void test_convert_short8_sat_rtn_double8( __global double8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtn(src[tid]);
}

__kernel void test_convert_short8_sat_rtp_double8( __global double8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtp(src[tid]);
}

__kernel void test_convert_short8_sat_rtz_double8( __global double8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtz(src[tid]);
}

__kernel void test_convert_short8_double8( __global double8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8(src[tid]);
}

__kernel void test_convert_short8_rte_double8( __global double8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rte(src[tid]);
}

__kernel void test_convert_short8_rtn_double8( __global double8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtn(src[tid]);
}

__kernel void test_convert_short8_rtp_double8( __global double8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtp(src[tid]);
}

__kernel void test_convert_short8_rtz_double8( __global double8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtz(src[tid]);
}

__kernel void test_convert_ushort8_sat_double8( __global double8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat(src[tid]);
}

__kernel void test_convert_ushort8_sat_rte_double8( __global double8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rte(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtn_double8( __global double8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtp_double8( __global double8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtz_double8( __global double8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort8_double8( __global double8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8(src[tid]);
}

__kernel void test_convert_ushort8_rte_double8( __global double8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rte(src[tid]);
}

__kernel void test_convert_ushort8_rtn_double8( __global double8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtn(src[tid]);
}

__kernel void test_convert_ushort8_rtp_double8( __global double8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtp(src[tid]);
}

__kernel void test_convert_ushort8_rtz_double8( __global double8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtz(src[tid]);
}

__kernel void test_convert_long8_sat_double8( __global double8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat(src[tid]);
}

__kernel void test_convert_long8_sat_rte_double8( __global double8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rte(src[tid]);
}

__kernel void test_convert_long8_sat_rtn_double8( __global double8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtn(src[tid]);
}

__kernel void test_convert_long8_sat_rtp_double8( __global double8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtp(src[tid]);
}

__kernel void test_convert_long8_sat_rtz_double8( __global double8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtz(src[tid]);
}

__kernel void test_convert_long8_double8( __global double8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8(src[tid]);
}

__kernel void test_convert_long8_rte_double8( __global double8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rte(src[tid]);
}

__kernel void test_convert_long8_rtn_double8( __global double8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtn(src[tid]);
}

__kernel void test_convert_long8_rtp_double8( __global double8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtp(src[tid]);
}

__kernel void test_convert_long8_rtz_double8( __global double8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtz(src[tid]);
}

__kernel void test_convert_ulong8_sat_double8( __global double8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat(src[tid]);
}

__kernel void test_convert_ulong8_sat_rte_double8( __global double8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rte(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtn_double8( __global double8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtp_double8( __global double8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtz_double8( __global double8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong8_double8( __global double8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8(src[tid]);
}

__kernel void test_convert_ulong8_rte_double8( __global double8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rte(src[tid]);
}

__kernel void test_convert_ulong8_rtn_double8( __global double8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtn(src[tid]);
}

__kernel void test_convert_ulong8_rtp_double8( __global double8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtp(src[tid]);
}

__kernel void test_convert_ulong8_rtz_double8( __global double8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtz(src[tid]);
}

__kernel void test_convert_float8_double8( __global double8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8(src[tid]);
}

__kernel void test_convert_float8_rte_double8( __global double8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rte(src[tid]);
}

__kernel void test_convert_float8_rtn_double8( __global double8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtn(src[tid]);
}

__kernel void test_convert_float8_rtp_double8( __global double8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtp(src[tid]);
}

__kernel void test_convert_float8_rtz_double8( __global double8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtz(src[tid]);
}

__kernel void test_convert_double8_double8( __global double8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8(src[tid]);
}

__kernel void test_convert_double8_rte_double8( __global double8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rte(src[tid]);
}

__kernel void test_convert_double8_rtn_double8( __global double8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtn(src[tid]);
}

__kernel void test_convert_double8_rtp_double8( __global double8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtp(src[tid]);
}

__kernel void test_convert_double8_rtz_double8( __global double8 *src, __global double8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double8_rtz(src[tid]);
}


