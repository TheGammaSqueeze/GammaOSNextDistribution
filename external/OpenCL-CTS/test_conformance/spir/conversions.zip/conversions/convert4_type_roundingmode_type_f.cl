__kernel void test_convert_char4_sat_char4( __global char4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat(src[tid]);
}

__kernel void test_convert_char4_sat_rte_char4( __global char4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rte(src[tid]);
}

__kernel void test_convert_char4_sat_rtn_char4( __global char4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtn(src[tid]);
}

__kernel void test_convert_char4_sat_rtp_char4( __global char4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtp(src[tid]);
}

__kernel void test_convert_char4_sat_rtz_char4( __global char4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_sat_rtz(src[tid]);
}

__kernel void test_convert_char4_char4( __global char4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4(src[tid]);
}

__kernel void test_convert_char4_rte_char4( __global char4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rte(src[tid]);
}

__kernel void test_convert_char4_rtn_char4( __global char4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtn(src[tid]);
}

__kernel void test_convert_char4_rtp_char4( __global char4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtp(src[tid]);
}

__kernel void test_convert_char4_rtz_char4( __global char4 *src, __global char4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char4_rtz(src[tid]);
}

__kernel void test_convert_uchar4_sat_char4( __global char4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat(src[tid]);
}

__kernel void test_convert_uchar4_sat_rte_char4( __global char4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rte(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtn_char4( __global char4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtp_char4( __global char4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar4_sat_rtz_char4( __global char4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar4_char4( __global char4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4(src[tid]);
}

__kernel void test_convert_uchar4_rte_char4( __global char4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rte(src[tid]);
}

__kernel void test_convert_uchar4_rtn_char4( __global char4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtn(src[tid]);
}

__kernel void test_convert_uchar4_rtp_char4( __global char4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtp(src[tid]);
}

__kernel void test_convert_uchar4_rtz_char4( __global char4 *src, __global uchar4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar4_rtz(src[tid]);
}

__kernel void test_convert_int4_sat_char4( __global char4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat(src[tid]);
}

__kernel void test_convert_int4_sat_rte_char4( __global char4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rte(src[tid]);
}

__kernel void test_convert_int4_sat_rtn_char4( __global char4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtn(src[tid]);
}

__kernel void test_convert_int4_sat_rtp_char4( __global char4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtp(src[tid]);
}

__kernel void test_convert_int4_sat_rtz_char4( __global char4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_sat_rtz(src[tid]);
}

__kernel void test_convert_int4_char4( __global char4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4(src[tid]);
}

__kernel void test_convert_int4_rte_char4( __global char4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rte(src[tid]);
}

__kernel void test_convert_int4_rtn_char4( __global char4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtn(src[tid]);
}

__kernel void test_convert_int4_rtp_char4( __global char4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtp(src[tid]);
}

__kernel void test_convert_int4_rtz_char4( __global char4 *src, __global int4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int4_rtz(src[tid]);
}

__kernel void test_convert_uint4_sat_char4( __global char4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat(src[tid]);
}

__kernel void test_convert_uint4_sat_rte_char4( __global char4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rte(src[tid]);
}

__kernel void test_convert_uint4_sat_rtn_char4( __global char4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtn(src[tid]);
}

__kernel void test_convert_uint4_sat_rtp_char4( __global char4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtp(src[tid]);
}

__kernel void test_convert_uint4_sat_rtz_char4( __global char4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_sat_rtz(src[tid]);
}

__kernel void test_convert_uint4_char4( __global char4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4(src[tid]);
}

__kernel void test_convert_uint4_rte_char4( __global char4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rte(src[tid]);
}

__kernel void test_convert_uint4_rtn_char4( __global char4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtn(src[tid]);
}

__kernel void test_convert_uint4_rtp_char4( __global char4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtp(src[tid]);
}

__kernel void test_convert_uint4_rtz_char4( __global char4 *src, __global uint4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint4_rtz(src[tid]);
}

__kernel void test_convert_short4_sat_char4( __global char4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat(src[tid]);
}

__kernel void test_convert_short4_sat_rte_char4( __global char4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rte(src[tid]);
}

__kernel void test_convert_short4_sat_rtn_char4( __global char4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtn(src[tid]);
}

__kernel void test_convert_short4_sat_rtp_char4( __global char4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtp(src[tid]);
}

__kernel void test_convert_short4_sat_rtz_char4( __global char4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_sat_rtz(src[tid]);
}

__kernel void test_convert_short4_char4( __global char4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4(src[tid]);
}

__kernel void test_convert_short4_rte_char4( __global char4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rte(src[tid]);
}

__kernel void test_convert_short4_rtn_char4( __global char4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtn(src[tid]);
}

__kernel void test_convert_short4_rtp_char4( __global char4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtp(src[tid]);
}

__kernel void test_convert_short4_rtz_char4( __global char4 *src, __global short4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short4_rtz(src[tid]);
}

__kernel void test_convert_ushort4_sat_char4( __global char4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat(src[tid]);
}

__kernel void test_convert_ushort4_sat_rte_char4( __global char4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rte(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtn_char4( __global char4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtp_char4( __global char4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort4_sat_rtz_char4( __global char4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort4_char4( __global char4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4(src[tid]);
}

__kernel void test_convert_ushort4_rte_char4( __global char4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rte(src[tid]);
}

__kernel void test_convert_ushort4_rtn_char4( __global char4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtn(src[tid]);
}

__kernel void test_convert_ushort4_rtp_char4( __global char4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtp(src[tid]);
}

__kernel void test_convert_ushort4_rtz_char4( __global char4 *src, __global ushort4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort4_rtz(src[tid]);
}

__kernel void test_convert_float4_char4( __global char4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4(src[tid]);
}

__kernel void test_convert_float4_rte_char4( __global char4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rte(src[tid]);
}

__kernel void test_convert_float4_rtn_char4( __global char4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtn(src[tid]);
}

__kernel void test_convert_float4_rtp_char4( __global char4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtp(src[tid]);
}

__kernel void test_convert_float4_rtz_char4( __global char4 *src, __global float4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float4_rtz(src[tid]);
}


