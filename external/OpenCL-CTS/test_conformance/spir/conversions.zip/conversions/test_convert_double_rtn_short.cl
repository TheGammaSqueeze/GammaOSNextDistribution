#pragma OPENCL EXTENSION cl_khr_fp64 : enable
__kernel void test_convert_double_rtn_short( __global short *src, __global double *dest )
{
   size_t i = get_global_id(0);
   dest[i] = convert_double_rtn( src[i] );
}
