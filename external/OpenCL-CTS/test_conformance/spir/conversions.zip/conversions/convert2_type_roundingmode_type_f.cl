__kernel void test_convert_char2_sat_char2( __global char2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_char2_sat_rte_char2( __global char2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_char2_sat_rtn_char2( __global char2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_char2_sat_rtp_char2( __global char2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_char2_sat_rtz_char2( __global char2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_char2_char2( __global char2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_char2_rte_char2( __global char2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_char2_rtn_char2( __global char2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_char2_rtp_char2( __global char2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_char2_rtz_char2( __global char2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uchar2_sat_char2( __global char2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat(src[tid]);
}

__kernel void test_convert_uchar2_sat_rte_char2( __global char2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rte(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtn_char2( __global char2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtp_char2( __global char2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtz_char2( __global char2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar2_char2( __global char2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2(src[tid]);
}

__kernel void test_convert_uchar2_rte_char2( __global char2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rte(src[tid]);
}

__kernel void test_convert_uchar2_rtn_char2( __global char2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtn(src[tid]);
}

__kernel void test_convert_uchar2_rtp_char2( __global char2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtp(src[tid]);
}

__kernel void test_convert_uchar2_rtz_char2( __global char2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtz(src[tid]);
}

__kernel void test_convert_int2_sat_char2( __global char2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat(src[tid]);
}

__kernel void test_convert_int2_sat_rte_char2( __global char2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rte(src[tid]);
}

__kernel void test_convert_int2_sat_rtn_char2( __global char2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtn(src[tid]);
}

__kernel void test_convert_int2_sat_rtp_char2( __global char2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtp(src[tid]);
}

__kernel void test_convert_int2_sat_rtz_char2( __global char2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtz(src[tid]);
}

__kernel void test_convert_int2_char2( __global char2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2(src[tid]);
}

__kernel void test_convert_int2_rte_char2( __global char2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rte(src[tid]);
}

__kernel void test_convert_int2_rtn_char2( __global char2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtn(src[tid]);
}

__kernel void test_convert_int2_rtp_char2( __global char2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtp(src[tid]);
}

__kernel void test_convert_int2_rtz_char2( __global char2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtz(src[tid]);
}

__kernel void test_convert_uint2_sat_char2( __global char2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat(src[tid]);
}

__kernel void test_convert_uint2_sat_rte_char2( __global char2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rte(src[tid]);
}

__kernel void test_convert_uint2_sat_rtn_char2( __global char2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtn(src[tid]);
}

__kernel void test_convert_uint2_sat_rtp_char2( __global char2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtp(src[tid]);
}

__kernel void test_convert_uint2_sat_rtz_char2( __global char2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtz(src[tid]);
}

__kernel void test_convert_uint2_char2( __global char2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2(src[tid]);
}

__kernel void test_convert_uint2_rte_char2( __global char2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rte(src[tid]);
}

__kernel void test_convert_uint2_rtn_char2( __global char2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtn(src[tid]);
}

__kernel void test_convert_uint2_rtp_char2( __global char2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtp(src[tid]);
}

__kernel void test_convert_uint2_rtz_char2( __global char2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtz(src[tid]);
}

__kernel void test_convert_short2_sat_char2( __global char2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat(src[tid]);
}

__kernel void test_convert_short2_sat_rte_char2( __global char2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rte(src[tid]);
}

__kernel void test_convert_short2_sat_rtn_char2( __global char2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtn(src[tid]);
}

__kernel void test_convert_short2_sat_rtp_char2( __global char2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtp(src[tid]);
}

__kernel void test_convert_short2_sat_rtz_char2( __global char2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtz(src[tid]);
}

__kernel void test_convert_short2_char2( __global char2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2(src[tid]);
}

__kernel void test_convert_short2_rte_char2( __global char2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rte(src[tid]);
}

__kernel void test_convert_short2_rtn_char2( __global char2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtn(src[tid]);
}

__kernel void test_convert_short2_rtp_char2( __global char2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtp(src[tid]);
}

__kernel void test_convert_short2_rtz_char2( __global char2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtz(src[tid]);
}

__kernel void test_convert_ushort2_sat_char2( __global char2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat(src[tid]);
}

__kernel void test_convert_ushort2_sat_rte_char2( __global char2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rte(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtn_char2( __global char2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtp_char2( __global char2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtz_char2( __global char2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort2_char2( __global char2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2(src[tid]);
}

__kernel void test_convert_ushort2_rte_char2( __global char2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rte(src[tid]);
}

__kernel void test_convert_ushort2_rtn_char2( __global char2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtn(src[tid]);
}

__kernel void test_convert_ushort2_rtp_char2( __global char2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtp(src[tid]);
}

__kernel void test_convert_ushort2_rtz_char2( __global char2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtz(src[tid]);
}

__kernel void test_convert_float2_char2( __global char2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2(src[tid]);
}

__kernel void test_convert_float2_rte_char2( __global char2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rte(src[tid]);
}

__kernel void test_convert_float2_rtn_char2( __global char2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtn(src[tid]);
}

__kernel void test_convert_float2_rtp_char2( __global char2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtp(src[tid]);
}

__kernel void test_convert_float2_rtz_char2( __global char2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtz(src[tid]);
}


