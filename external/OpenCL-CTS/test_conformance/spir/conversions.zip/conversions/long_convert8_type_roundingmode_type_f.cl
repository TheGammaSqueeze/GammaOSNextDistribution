#ifdef cles_khr_int64
#pragma OPENCL EXTENSION cles_khr_int64 : enable
#endif
__kernel void test_convert_long8_sat_char8( __global char8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat(src[tid]);
}

__kernel void test_convert_long8_sat_rte_char8( __global char8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rte(src[tid]);
}

__kernel void test_convert_long8_sat_rtn_char8( __global char8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtn(src[tid]);
}

__kernel void test_convert_long8_sat_rtp_char8( __global char8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtp(src[tid]);
}

__kernel void test_convert_long8_sat_rtz_char8( __global char8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_sat_rtz(src[tid]);
}

__kernel void test_convert_long8_char8( __global char8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8(src[tid]);
}

__kernel void test_convert_long8_rte_char8( __global char8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rte(src[tid]);
}

__kernel void test_convert_long8_rtn_char8( __global char8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtn(src[tid]);
}

__kernel void test_convert_long8_rtp_char8( __global char8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtp(src[tid]);
}

__kernel void test_convert_long8_rtz_char8( __global char8 *src, __global long8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long8_rtz(src[tid]);
}

__kernel void test_convert_ulong8_sat_char8( __global char8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat(src[tid]);
}

__kernel void test_convert_ulong8_sat_rte_char8( __global char8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rte(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtn_char8( __global char8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtp_char8( __global char8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong8_sat_rtz_char8( __global char8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong8_char8( __global char8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8(src[tid]);
}

__kernel void test_convert_ulong8_rte_char8( __global char8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rte(src[tid]);
}

__kernel void test_convert_ulong8_rtn_char8( __global char8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtn(src[tid]);
}

__kernel void test_convert_ulong8_rtp_char8( __global char8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtp(src[tid]);
}

__kernel void test_convert_ulong8_rtz_char8( __global char8 *src, __global ulong8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong8_rtz(src[tid]);
}
