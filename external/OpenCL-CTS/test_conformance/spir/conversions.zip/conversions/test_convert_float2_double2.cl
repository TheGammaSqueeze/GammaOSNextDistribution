#pragma OPENCL EXTENSION cl_khr_fp64 : enable
__kernel void test_convert_float2_double2( __global double2 *src, __global float2 *dest )
{
   size_t i = get_global_id(0);
   dest[i] = convert_float2( src[i] );
}
