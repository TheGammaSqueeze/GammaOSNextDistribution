#pragma OPENCL EXTENSION cl_khr_fp64 : enable
__kernel void test_convert_int2_sat_rtp_double2( __global double2 *src, __global int2 *dest )
{
   size_t i = get_global_id(0);
   dest[i] = convert_int2_sat_rtp( src[i] );
}
