__kernel void test_convert_double2_char2( __global char2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2(src[tid]);
}

__kernel void test_convert_double2_rte_char2( __global char2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rte(src[tid]);
}

__kernel void test_convert_double2_rtn_char2( __global char2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtn(src[tid]);
}

__kernel void test_convert_double2_rtp_char2( __global char2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtp(src[tid]);
}

__kernel void test_convert_double2_rtz_char2( __global char2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtz(src[tid]);
}

__kernel void test_convert_char2_sat_uchar2( __global uchar2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat(src[tid]);
}

__kernel void test_convert_char2_sat_rte_uchar2( __global uchar2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rte(src[tid]);
}

__kernel void test_convert_char2_sat_rtn_uchar2( __global uchar2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtn(src[tid]);
}

__kernel void test_convert_char2_sat_rtp_uchar2( __global uchar2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtp(src[tid]);
}

__kernel void test_convert_char2_sat_rtz_uchar2( __global uchar2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtz(src[tid]);
}

__kernel void test_convert_char2_uchar2( __global uchar2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2(src[tid]);
}

__kernel void test_convert_char2_rte_uchar2( __global uchar2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rte(src[tid]);
}

__kernel void test_convert_char2_rtn_uchar2( __global uchar2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtn(src[tid]);
}

__kernel void test_convert_char2_rtp_uchar2( __global uchar2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtp(src[tid]);
}

__kernel void test_convert_char2_rtz_uchar2( __global uchar2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtz(src[tid]);
}

__kernel void test_convert_uchar2_sat_uchar2( __global uchar2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uchar2_sat_rte_uchar2( __global uchar2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uchar2_sat_rtn_uchar2( __global uchar2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uchar2_sat_rtp_uchar2( __global uchar2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uchar2_sat_rtz_uchar2( __global uchar2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uchar2_uchar2( __global uchar2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uchar2_rte_uchar2( __global uchar2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uchar2_rtn_uchar2( __global uchar2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uchar2_rtp_uchar2( __global uchar2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uchar2_rtz_uchar2( __global uchar2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_int2_sat_uchar2( __global uchar2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat(src[tid]);
}

__kernel void test_convert_int2_sat_rte_uchar2( __global uchar2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rte(src[tid]);
}

__kernel void test_convert_int2_sat_rtn_uchar2( __global uchar2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtn(src[tid]);
}

__kernel void test_convert_int2_sat_rtp_uchar2( __global uchar2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtp(src[tid]);
}

__kernel void test_convert_int2_sat_rtz_uchar2( __global uchar2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtz(src[tid]);
}

__kernel void test_convert_int2_uchar2( __global uchar2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2(src[tid]);
}

__kernel void test_convert_int2_rte_uchar2( __global uchar2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rte(src[tid]);
}

__kernel void test_convert_int2_rtn_uchar2( __global uchar2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtn(src[tid]);
}

__kernel void test_convert_int2_rtp_uchar2( __global uchar2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtp(src[tid]);
}

__kernel void test_convert_int2_rtz_uchar2( __global uchar2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtz(src[tid]);
}

__kernel void test_convert_uint2_sat_uchar2( __global uchar2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat(src[tid]);
}

__kernel void test_convert_uint2_sat_rte_uchar2( __global uchar2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rte(src[tid]);
}

__kernel void test_convert_uint2_sat_rtn_uchar2( __global uchar2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtn(src[tid]);
}

__kernel void test_convert_uint2_sat_rtp_uchar2( __global uchar2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtp(src[tid]);
}

__kernel void test_convert_uint2_sat_rtz_uchar2( __global uchar2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtz(src[tid]);
}

__kernel void test_convert_uint2_uchar2( __global uchar2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2(src[tid]);
}

__kernel void test_convert_uint2_rte_uchar2( __global uchar2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rte(src[tid]);
}

__kernel void test_convert_uint2_rtn_uchar2( __global uchar2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtn(src[tid]);
}

__kernel void test_convert_uint2_rtp_uchar2( __global uchar2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtp(src[tid]);
}

__kernel void test_convert_uint2_rtz_uchar2( __global uchar2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtz(src[tid]);
}

__kernel void test_convert_short2_sat_uchar2( __global uchar2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat(src[tid]);
}

__kernel void test_convert_short2_sat_rte_uchar2( __global uchar2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rte(src[tid]);
}

__kernel void test_convert_short2_sat_rtn_uchar2( __global uchar2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtn(src[tid]);
}

__kernel void test_convert_short2_sat_rtp_uchar2( __global uchar2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtp(src[tid]);
}

__kernel void test_convert_short2_sat_rtz_uchar2( __global uchar2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtz(src[tid]);
}

__kernel void test_convert_short2_uchar2( __global uchar2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2(src[tid]);
}

__kernel void test_convert_short2_rte_uchar2( __global uchar2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rte(src[tid]);
}

__kernel void test_convert_short2_rtn_uchar2( __global uchar2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtn(src[tid]);
}

__kernel void test_convert_short2_rtp_uchar2( __global uchar2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtp(src[tid]);
}

__kernel void test_convert_short2_rtz_uchar2( __global uchar2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtz(src[tid]);
}

__kernel void test_convert_ushort2_sat_uchar2( __global uchar2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat(src[tid]);
}

__kernel void test_convert_ushort2_sat_rte_uchar2( __global uchar2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rte(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtn_uchar2( __global uchar2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtp_uchar2( __global uchar2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtz_uchar2( __global uchar2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort2_uchar2( __global uchar2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2(src[tid]);
}

__kernel void test_convert_ushort2_rte_uchar2( __global uchar2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rte(src[tid]);
}

__kernel void test_convert_ushort2_rtn_uchar2( __global uchar2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtn(src[tid]);
}

__kernel void test_convert_ushort2_rtp_uchar2( __global uchar2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtp(src[tid]);
}

__kernel void test_convert_ushort2_rtz_uchar2( __global uchar2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtz(src[tid]);
}

__kernel void test_convert_long2_sat_uchar2( __global uchar2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat(src[tid]);
}

__kernel void test_convert_long2_sat_rte_uchar2( __global uchar2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rte(src[tid]);
}

__kernel void test_convert_long2_sat_rtn_uchar2( __global uchar2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtn(src[tid]);
}

__kernel void test_convert_long2_sat_rtp_uchar2( __global uchar2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtp(src[tid]);
}

__kernel void test_convert_long2_sat_rtz_uchar2( __global uchar2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtz(src[tid]);
}

__kernel void test_convert_long2_uchar2( __global uchar2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2(src[tid]);
}

__kernel void test_convert_long2_rte_uchar2( __global uchar2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rte(src[tid]);
}

__kernel void test_convert_long2_rtn_uchar2( __global uchar2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtn(src[tid]);
}

__kernel void test_convert_long2_rtp_uchar2( __global uchar2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtp(src[tid]);
}

__kernel void test_convert_long2_rtz_uchar2( __global uchar2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtz(src[tid]);
}

__kernel void test_convert_ulong2_sat_uchar2( __global uchar2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat(src[tid]);
}

__kernel void test_convert_ulong2_sat_rte_uchar2( __global uchar2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rte(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtn_uchar2( __global uchar2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtp_uchar2( __global uchar2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtz_uchar2( __global uchar2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong2_uchar2( __global uchar2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2(src[tid]);
}

__kernel void test_convert_ulong2_rte_uchar2( __global uchar2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rte(src[tid]);
}

__kernel void test_convert_ulong2_rtn_uchar2( __global uchar2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtn(src[tid]);
}

__kernel void test_convert_ulong2_rtp_uchar2( __global uchar2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtp(src[tid]);
}

__kernel void test_convert_ulong2_rtz_uchar2( __global uchar2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtz(src[tid]);
}

__kernel void test_convert_float2_uchar2( __global uchar2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2(src[tid]);
}

__kernel void test_convert_float2_rte_uchar2( __global uchar2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rte(src[tid]);
}

__kernel void test_convert_float2_rtn_uchar2( __global uchar2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtn(src[tid]);
}

__kernel void test_convert_float2_rtp_uchar2( __global uchar2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtp(src[tid]);
}

__kernel void test_convert_float2_rtz_uchar2( __global uchar2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtz(src[tid]);
}

__kernel void test_convert_double2_uchar2( __global uchar2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2(src[tid]);
}

__kernel void test_convert_double2_rte_uchar2( __global uchar2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rte(src[tid]);
}

__kernel void test_convert_double2_rtn_uchar2( __global uchar2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtn(src[tid]);
}

__kernel void test_convert_double2_rtp_uchar2( __global uchar2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtp(src[tid]);
}

__kernel void test_convert_double2_rtz_uchar2( __global uchar2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtz(src[tid]);
}

__kernel void test_convert_char2_sat_int2( __global int2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat(src[tid]);
}

__kernel void test_convert_char2_sat_rte_int2( __global int2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rte(src[tid]);
}

__kernel void test_convert_char2_sat_rtn_int2( __global int2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtn(src[tid]);
}

__kernel void test_convert_char2_sat_rtp_int2( __global int2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtp(src[tid]);
}

__kernel void test_convert_char2_sat_rtz_int2( __global int2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtz(src[tid]);
}

__kernel void test_convert_char2_int2( __global int2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2(src[tid]);
}

__kernel void test_convert_char2_rte_int2( __global int2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rte(src[tid]);
}

__kernel void test_convert_char2_rtn_int2( __global int2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtn(src[tid]);
}

__kernel void test_convert_char2_rtp_int2( __global int2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtp(src[tid]);
}

__kernel void test_convert_char2_rtz_int2( __global int2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtz(src[tid]);
}

__kernel void test_convert_uchar2_sat_int2( __global int2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat(src[tid]);
}

__kernel void test_convert_uchar2_sat_rte_int2( __global int2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rte(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtn_int2( __global int2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtp_int2( __global int2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtz_int2( __global int2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar2_int2( __global int2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2(src[tid]);
}

__kernel void test_convert_uchar2_rte_int2( __global int2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rte(src[tid]);
}

__kernel void test_convert_uchar2_rtn_int2( __global int2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtn(src[tid]);
}

__kernel void test_convert_uchar2_rtp_int2( __global int2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtp(src[tid]);
}

__kernel void test_convert_uchar2_rtz_int2( __global int2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtz(src[tid]);
}

__kernel void test_convert_int2_sat_int2( __global int2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_int2_sat_rte_int2( __global int2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_int2_sat_rtn_int2( __global int2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_int2_sat_rtp_int2( __global int2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_int2_sat_rtz_int2( __global int2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_int2_int2( __global int2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_int2_rte_int2( __global int2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_int2_rtn_int2( __global int2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_int2_rtp_int2( __global int2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_int2_rtz_int2( __global int2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uint2_sat_int2( __global int2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat(src[tid]);
}

__kernel void test_convert_uint2_sat_rte_int2( __global int2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rte(src[tid]);
}

__kernel void test_convert_uint2_sat_rtn_int2( __global int2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtn(src[tid]);
}

__kernel void test_convert_uint2_sat_rtp_int2( __global int2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtp(src[tid]);
}

__kernel void test_convert_uint2_sat_rtz_int2( __global int2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtz(src[tid]);
}

__kernel void test_convert_uint2_int2( __global int2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2(src[tid]);
}

__kernel void test_convert_uint2_rte_int2( __global int2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rte(src[tid]);
}

__kernel void test_convert_uint2_rtn_int2( __global int2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtn(src[tid]);
}

__kernel void test_convert_uint2_rtp_int2( __global int2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtp(src[tid]);
}

__kernel void test_convert_uint2_rtz_int2( __global int2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtz(src[tid]);
}

__kernel void test_convert_short2_sat_int2( __global int2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat(src[tid]);
}

__kernel void test_convert_short2_sat_rte_int2( __global int2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rte(src[tid]);
}

__kernel void test_convert_short2_sat_rtn_int2( __global int2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtn(src[tid]);
}

__kernel void test_convert_short2_sat_rtp_int2( __global int2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtp(src[tid]);
}

__kernel void test_convert_short2_sat_rtz_int2( __global int2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtz(src[tid]);
}

__kernel void test_convert_short2_int2( __global int2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2(src[tid]);
}

__kernel void test_convert_short2_rte_int2( __global int2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rte(src[tid]);
}

__kernel void test_convert_short2_rtn_int2( __global int2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtn(src[tid]);
}

__kernel void test_convert_short2_rtp_int2( __global int2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtp(src[tid]);
}

__kernel void test_convert_short2_rtz_int2( __global int2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtz(src[tid]);
}

__kernel void test_convert_ushort2_sat_int2( __global int2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat(src[tid]);
}

__kernel void test_convert_ushort2_sat_rte_int2( __global int2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rte(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtn_int2( __global int2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtp_int2( __global int2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtz_int2( __global int2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort2_int2( __global int2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2(src[tid]);
}

__kernel void test_convert_ushort2_rte_int2( __global int2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rte(src[tid]);
}

__kernel void test_convert_ushort2_rtn_int2( __global int2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtn(src[tid]);
}

__kernel void test_convert_ushort2_rtp_int2( __global int2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtp(src[tid]);
}

__kernel void test_convert_ushort2_rtz_int2( __global int2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtz(src[tid]);
}

__kernel void test_convert_long2_sat_int2( __global int2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat(src[tid]);
}

__kernel void test_convert_long2_sat_rte_int2( __global int2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rte(src[tid]);
}

__kernel void test_convert_long2_sat_rtn_int2( __global int2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtn(src[tid]);
}

__kernel void test_convert_long2_sat_rtp_int2( __global int2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtp(src[tid]);
}

__kernel void test_convert_long2_sat_rtz_int2( __global int2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtz(src[tid]);
}

__kernel void test_convert_long2_int2( __global int2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2(src[tid]);
}

__kernel void test_convert_long2_rte_int2( __global int2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rte(src[tid]);
}

__kernel void test_convert_long2_rtn_int2( __global int2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtn(src[tid]);
}

__kernel void test_convert_long2_rtp_int2( __global int2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtp(src[tid]);
}

__kernel void test_convert_long2_rtz_int2( __global int2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtz(src[tid]);
}

__kernel void test_convert_ulong2_sat_int2( __global int2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat(src[tid]);
}

__kernel void test_convert_ulong2_sat_rte_int2( __global int2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rte(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtn_int2( __global int2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtp_int2( __global int2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtz_int2( __global int2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong2_int2( __global int2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2(src[tid]);
}

__kernel void test_convert_ulong2_rte_int2( __global int2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rte(src[tid]);
}

__kernel void test_convert_ulong2_rtn_int2( __global int2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtn(src[tid]);
}

__kernel void test_convert_ulong2_rtp_int2( __global int2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtp(src[tid]);
}

__kernel void test_convert_ulong2_rtz_int2( __global int2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtz(src[tid]);
}

__kernel void test_convert_float2_int2( __global int2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2(src[tid]);
}

__kernel void test_convert_float2_rte_int2( __global int2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rte(src[tid]);
}

__kernel void test_convert_float2_rtn_int2( __global int2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtn(src[tid]);
}

__kernel void test_convert_float2_rtp_int2( __global int2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtp(src[tid]);
}

__kernel void test_convert_float2_rtz_int2( __global int2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtz(src[tid]);
}

__kernel void test_convert_double2_int2( __global int2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2(src[tid]);
}

__kernel void test_convert_double2_rte_int2( __global int2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rte(src[tid]);
}

__kernel void test_convert_double2_rtn_int2( __global int2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtn(src[tid]);
}

__kernel void test_convert_double2_rtp_int2( __global int2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtp(src[tid]);
}

__kernel void test_convert_double2_rtz_int2( __global int2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtz(src[tid]);
}

__kernel void test_convert_char2_sat_uint2( __global uint2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat(src[tid]);
}

__kernel void test_convert_char2_sat_rte_uint2( __global uint2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rte(src[tid]);
}

__kernel void test_convert_char2_sat_rtn_uint2( __global uint2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtn(src[tid]);
}

__kernel void test_convert_char2_sat_rtp_uint2( __global uint2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtp(src[tid]);
}

__kernel void test_convert_char2_sat_rtz_uint2( __global uint2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtz(src[tid]);
}

__kernel void test_convert_char2_uint2( __global uint2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2(src[tid]);
}

__kernel void test_convert_char2_rte_uint2( __global uint2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rte(src[tid]);
}

__kernel void test_convert_char2_rtn_uint2( __global uint2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtn(src[tid]);
}

__kernel void test_convert_char2_rtp_uint2( __global uint2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtp(src[tid]);
}

__kernel void test_convert_char2_rtz_uint2( __global uint2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtz(src[tid]);
}

__kernel void test_convert_uchar2_sat_uint2( __global uint2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat(src[tid]);
}

__kernel void test_convert_uchar2_sat_rte_uint2( __global uint2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rte(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtn_uint2( __global uint2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtp_uint2( __global uint2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtz_uint2( __global uint2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar2_uint2( __global uint2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2(src[tid]);
}

__kernel void test_convert_uchar2_rte_uint2( __global uint2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rte(src[tid]);
}

__kernel void test_convert_uchar2_rtn_uint2( __global uint2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtn(src[tid]);
}

__kernel void test_convert_uchar2_rtp_uint2( __global uint2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtp(src[tid]);
}

__kernel void test_convert_uchar2_rtz_uint2( __global uint2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtz(src[tid]);
}

__kernel void test_convert_int2_sat_uint2( __global uint2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat(src[tid]);
}

__kernel void test_convert_int2_sat_rte_uint2( __global uint2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rte(src[tid]);
}

__kernel void test_convert_int2_sat_rtn_uint2( __global uint2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtn(src[tid]);
}

__kernel void test_convert_int2_sat_rtp_uint2( __global uint2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtp(src[tid]);
}

__kernel void test_convert_int2_sat_rtz_uint2( __global uint2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtz(src[tid]);
}

__kernel void test_convert_int2_uint2( __global uint2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2(src[tid]);
}

__kernel void test_convert_int2_rte_uint2( __global uint2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rte(src[tid]);
}

__kernel void test_convert_int2_rtn_uint2( __global uint2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtn(src[tid]);
}

__kernel void test_convert_int2_rtp_uint2( __global uint2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtp(src[tid]);
}

__kernel void test_convert_int2_rtz_uint2( __global uint2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtz(src[tid]);
}

__kernel void test_convert_uint2_sat_uint2( __global uint2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uint2_sat_rte_uint2( __global uint2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uint2_sat_rtn_uint2( __global uint2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uint2_sat_rtp_uint2( __global uint2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uint2_sat_rtz_uint2( __global uint2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uint2_uint2( __global uint2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uint2_rte_uint2( __global uint2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uint2_rtn_uint2( __global uint2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uint2_rtp_uint2( __global uint2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_uint2_rtz_uint2( __global uint2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_short2_sat_uint2( __global uint2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat(src[tid]);
}

__kernel void test_convert_short2_sat_rte_uint2( __global uint2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rte(src[tid]);
}

__kernel void test_convert_short2_sat_rtn_uint2( __global uint2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtn(src[tid]);
}

__kernel void test_convert_short2_sat_rtp_uint2( __global uint2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtp(src[tid]);
}

__kernel void test_convert_short2_sat_rtz_uint2( __global uint2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtz(src[tid]);
}

__kernel void test_convert_short2_uint2( __global uint2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2(src[tid]);
}

__kernel void test_convert_short2_rte_uint2( __global uint2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rte(src[tid]);
}

__kernel void test_convert_short2_rtn_uint2( __global uint2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtn(src[tid]);
}

__kernel void test_convert_short2_rtp_uint2( __global uint2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtp(src[tid]);
}

__kernel void test_convert_short2_rtz_uint2( __global uint2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtz(src[tid]);
}

__kernel void test_convert_ushort2_sat_uint2( __global uint2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat(src[tid]);
}

__kernel void test_convert_ushort2_sat_rte_uint2( __global uint2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rte(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtn_uint2( __global uint2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtp_uint2( __global uint2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtz_uint2( __global uint2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort2_uint2( __global uint2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2(src[tid]);
}

__kernel void test_convert_ushort2_rte_uint2( __global uint2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rte(src[tid]);
}

__kernel void test_convert_ushort2_rtn_uint2( __global uint2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtn(src[tid]);
}

__kernel void test_convert_ushort2_rtp_uint2( __global uint2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtp(src[tid]);
}

__kernel void test_convert_ushort2_rtz_uint2( __global uint2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtz(src[tid]);
}

__kernel void test_convert_long2_sat_uint2( __global uint2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat(src[tid]);
}

__kernel void test_convert_long2_sat_rte_uint2( __global uint2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rte(src[tid]);
}

__kernel void test_convert_long2_sat_rtn_uint2( __global uint2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtn(src[tid]);
}

__kernel void test_convert_long2_sat_rtp_uint2( __global uint2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtp(src[tid]);
}

__kernel void test_convert_long2_sat_rtz_uint2( __global uint2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtz(src[tid]);
}

__kernel void test_convert_long2_uint2( __global uint2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2(src[tid]);
}

__kernel void test_convert_long2_rte_uint2( __global uint2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rte(src[tid]);
}

__kernel void test_convert_long2_rtn_uint2( __global uint2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtn(src[tid]);
}

__kernel void test_convert_long2_rtp_uint2( __global uint2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtp(src[tid]);
}

__kernel void test_convert_long2_rtz_uint2( __global uint2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtz(src[tid]);
}

__kernel void test_convert_ulong2_sat_uint2( __global uint2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat(src[tid]);
}

__kernel void test_convert_ulong2_sat_rte_uint2( __global uint2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rte(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtn_uint2( __global uint2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtp_uint2( __global uint2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtz_uint2( __global uint2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong2_uint2( __global uint2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2(src[tid]);
}

__kernel void test_convert_ulong2_rte_uint2( __global uint2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rte(src[tid]);
}

__kernel void test_convert_ulong2_rtn_uint2( __global uint2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtn(src[tid]);
}

__kernel void test_convert_ulong2_rtp_uint2( __global uint2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtp(src[tid]);
}

__kernel void test_convert_ulong2_rtz_uint2( __global uint2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtz(src[tid]);
}

__kernel void test_convert_float2_uint2( __global uint2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2(src[tid]);
}

__kernel void test_convert_float2_rte_uint2( __global uint2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rte(src[tid]);
}

__kernel void test_convert_float2_rtn_uint2( __global uint2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtn(src[tid]);
}

__kernel void test_convert_float2_rtp_uint2( __global uint2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtp(src[tid]);
}

__kernel void test_convert_float2_rtz_uint2( __global uint2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtz(src[tid]);
}

__kernel void test_convert_double2_uint2( __global uint2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2(src[tid]);
}

__kernel void test_convert_double2_rte_uint2( __global uint2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rte(src[tid]);
}

__kernel void test_convert_double2_rtn_uint2( __global uint2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtn(src[tid]);
}

__kernel void test_convert_double2_rtp_uint2( __global uint2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtp(src[tid]);
}

__kernel void test_convert_double2_rtz_uint2( __global uint2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtz(src[tid]);
}

__kernel void test_convert_char2_sat_short2( __global short2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat(src[tid]);
}

__kernel void test_convert_char2_sat_rte_short2( __global short2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rte(src[tid]);
}

__kernel void test_convert_char2_sat_rtn_short2( __global short2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtn(src[tid]);
}

__kernel void test_convert_char2_sat_rtp_short2( __global short2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtp(src[tid]);
}

__kernel void test_convert_char2_sat_rtz_short2( __global short2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtz(src[tid]);
}

__kernel void test_convert_char2_short2( __global short2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2(src[tid]);
}

__kernel void test_convert_char2_rte_short2( __global short2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rte(src[tid]);
}

__kernel void test_convert_char2_rtn_short2( __global short2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtn(src[tid]);
}

__kernel void test_convert_char2_rtp_short2( __global short2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtp(src[tid]);
}

__kernel void test_convert_char2_rtz_short2( __global short2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtz(src[tid]);
}

__kernel void test_convert_uchar2_sat_short2( __global short2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat(src[tid]);
}

__kernel void test_convert_uchar2_sat_rte_short2( __global short2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rte(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtn_short2( __global short2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtp_short2( __global short2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtz_short2( __global short2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar2_short2( __global short2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2(src[tid]);
}

__kernel void test_convert_uchar2_rte_short2( __global short2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rte(src[tid]);
}

__kernel void test_convert_uchar2_rtn_short2( __global short2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtn(src[tid]);
}

__kernel void test_convert_uchar2_rtp_short2( __global short2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtp(src[tid]);
}

__kernel void test_convert_uchar2_rtz_short2( __global short2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtz(src[tid]);
}

__kernel void test_convert_int2_sat_short2( __global short2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat(src[tid]);
}

__kernel void test_convert_int2_sat_rte_short2( __global short2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rte(src[tid]);
}

__kernel void test_convert_int2_sat_rtn_short2( __global short2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtn(src[tid]);
}

__kernel void test_convert_int2_sat_rtp_short2( __global short2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtp(src[tid]);
}

__kernel void test_convert_int2_sat_rtz_short2( __global short2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtz(src[tid]);
}

__kernel void test_convert_int2_short2( __global short2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2(src[tid]);
}

__kernel void test_convert_int2_rte_short2( __global short2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rte(src[tid]);
}

__kernel void test_convert_int2_rtn_short2( __global short2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtn(src[tid]);
}

__kernel void test_convert_int2_rtp_short2( __global short2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtp(src[tid]);
}

__kernel void test_convert_int2_rtz_short2( __global short2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtz(src[tid]);
}

__kernel void test_convert_uint2_sat_short2( __global short2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat(src[tid]);
}

__kernel void test_convert_uint2_sat_rte_short2( __global short2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rte(src[tid]);
}

__kernel void test_convert_uint2_sat_rtn_short2( __global short2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtn(src[tid]);
}

__kernel void test_convert_uint2_sat_rtp_short2( __global short2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtp(src[tid]);
}

__kernel void test_convert_uint2_sat_rtz_short2( __global short2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtz(src[tid]);
}

__kernel void test_convert_uint2_short2( __global short2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2(src[tid]);
}

__kernel void test_convert_uint2_rte_short2( __global short2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rte(src[tid]);
}

__kernel void test_convert_uint2_rtn_short2( __global short2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtn(src[tid]);
}

__kernel void test_convert_uint2_rtp_short2( __global short2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtp(src[tid]);
}

__kernel void test_convert_uint2_rtz_short2( __global short2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtz(src[tid]);
}

__kernel void test_convert_short2_sat_short2( __global short2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_short2_sat_rte_short2( __global short2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_short2_sat_rtn_short2( __global short2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_short2_sat_rtp_short2( __global short2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_short2_sat_rtz_short2( __global short2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_short2_short2( __global short2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_short2_rte_short2( __global short2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_short2_rtn_short2( __global short2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_short2_rtp_short2( __global short2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_short2_rtz_short2( __global short2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ushort2_sat_short2( __global short2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat(src[tid]);
}

__kernel void test_convert_ushort2_sat_rte_short2( __global short2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rte(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtn_short2( __global short2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtp_short2( __global short2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtz_short2( __global short2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort2_short2( __global short2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2(src[tid]);
}

__kernel void test_convert_ushort2_rte_short2( __global short2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rte(src[tid]);
}

__kernel void test_convert_ushort2_rtn_short2( __global short2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtn(src[tid]);
}

__kernel void test_convert_ushort2_rtp_short2( __global short2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtp(src[tid]);
}

__kernel void test_convert_ushort2_rtz_short2( __global short2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtz(src[tid]);
}

__kernel void test_convert_long2_sat_short2( __global short2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat(src[tid]);
}

__kernel void test_convert_long2_sat_rte_short2( __global short2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rte(src[tid]);
}

__kernel void test_convert_long2_sat_rtn_short2( __global short2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtn(src[tid]);
}

__kernel void test_convert_long2_sat_rtp_short2( __global short2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtp(src[tid]);
}

__kernel void test_convert_long2_sat_rtz_short2( __global short2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtz(src[tid]);
}

__kernel void test_convert_long2_short2( __global short2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2(src[tid]);
}

__kernel void test_convert_long2_rte_short2( __global short2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rte(src[tid]);
}

__kernel void test_convert_long2_rtn_short2( __global short2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtn(src[tid]);
}

__kernel void test_convert_long2_rtp_short2( __global short2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtp(src[tid]);
}

__kernel void test_convert_long2_rtz_short2( __global short2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtz(src[tid]);
}

__kernel void test_convert_ulong2_sat_short2( __global short2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat(src[tid]);
}

__kernel void test_convert_ulong2_sat_rte_short2( __global short2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rte(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtn_short2( __global short2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtp_short2( __global short2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtz_short2( __global short2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong2_short2( __global short2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2(src[tid]);
}

__kernel void test_convert_ulong2_rte_short2( __global short2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rte(src[tid]);
}

__kernel void test_convert_ulong2_rtn_short2( __global short2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtn(src[tid]);
}

__kernel void test_convert_ulong2_rtp_short2( __global short2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtp(src[tid]);
}

__kernel void test_convert_ulong2_rtz_short2( __global short2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtz(src[tid]);
}

__kernel void test_convert_float2_short2( __global short2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2(src[tid]);
}

__kernel void test_convert_float2_rte_short2( __global short2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rte(src[tid]);
}

__kernel void test_convert_float2_rtn_short2( __global short2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtn(src[tid]);
}

__kernel void test_convert_float2_rtp_short2( __global short2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtp(src[tid]);
}

__kernel void test_convert_float2_rtz_short2( __global short2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtz(src[tid]);
}

__kernel void test_convert_double2_short2( __global short2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2(src[tid]);
}

__kernel void test_convert_double2_rte_short2( __global short2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rte(src[tid]);
}

__kernel void test_convert_double2_rtn_short2( __global short2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtn(src[tid]);
}

__kernel void test_convert_double2_rtp_short2( __global short2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtp(src[tid]);
}

__kernel void test_convert_double2_rtz_short2( __global short2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtz(src[tid]);
}

__kernel void test_convert_char2_sat_ushort2( __global ushort2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat(src[tid]);
}

__kernel void test_convert_char2_sat_rte_ushort2( __global ushort2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rte(src[tid]);
}

__kernel void test_convert_char2_sat_rtn_ushort2( __global ushort2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtn(src[tid]);
}

__kernel void test_convert_char2_sat_rtp_ushort2( __global ushort2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtp(src[tid]);
}

__kernel void test_convert_char2_sat_rtz_ushort2( __global ushort2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtz(src[tid]);
}

__kernel void test_convert_char2_ushort2( __global ushort2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2(src[tid]);
}

__kernel void test_convert_char2_rte_ushort2( __global ushort2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rte(src[tid]);
}

__kernel void test_convert_char2_rtn_ushort2( __global ushort2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtn(src[tid]);
}

__kernel void test_convert_char2_rtp_ushort2( __global ushort2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtp(src[tid]);
}

__kernel void test_convert_char2_rtz_ushort2( __global ushort2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtz(src[tid]);
}

__kernel void test_convert_uchar2_sat_ushort2( __global ushort2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat(src[tid]);
}

__kernel void test_convert_uchar2_sat_rte_ushort2( __global ushort2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rte(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtn_ushort2( __global ushort2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtp_ushort2( __global ushort2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtz_ushort2( __global ushort2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar2_ushort2( __global ushort2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2(src[tid]);
}

__kernel void test_convert_uchar2_rte_ushort2( __global ushort2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rte(src[tid]);
}

__kernel void test_convert_uchar2_rtn_ushort2( __global ushort2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtn(src[tid]);
}

__kernel void test_convert_uchar2_rtp_ushort2( __global ushort2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtp(src[tid]);
}

__kernel void test_convert_uchar2_rtz_ushort2( __global ushort2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtz(src[tid]);
}

__kernel void test_convert_int2_sat_ushort2( __global ushort2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat(src[tid]);
}

__kernel void test_convert_int2_sat_rte_ushort2( __global ushort2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rte(src[tid]);
}

__kernel void test_convert_int2_sat_rtn_ushort2( __global ushort2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtn(src[tid]);
}

__kernel void test_convert_int2_sat_rtp_ushort2( __global ushort2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtp(src[tid]);
}

__kernel void test_convert_int2_sat_rtz_ushort2( __global ushort2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtz(src[tid]);
}

__kernel void test_convert_int2_ushort2( __global ushort2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2(src[tid]);
}

__kernel void test_convert_int2_rte_ushort2( __global ushort2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rte(src[tid]);
}

__kernel void test_convert_int2_rtn_ushort2( __global ushort2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtn(src[tid]);
}

__kernel void test_convert_int2_rtp_ushort2( __global ushort2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtp(src[tid]);
}

__kernel void test_convert_int2_rtz_ushort2( __global ushort2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtz(src[tid]);
}

__kernel void test_convert_uint2_sat_ushort2( __global ushort2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat(src[tid]);
}

__kernel void test_convert_uint2_sat_rte_ushort2( __global ushort2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rte(src[tid]);
}

__kernel void test_convert_uint2_sat_rtn_ushort2( __global ushort2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtn(src[tid]);
}

__kernel void test_convert_uint2_sat_rtp_ushort2( __global ushort2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtp(src[tid]);
}

__kernel void test_convert_uint2_sat_rtz_ushort2( __global ushort2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtz(src[tid]);
}

__kernel void test_convert_uint2_ushort2( __global ushort2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2(src[tid]);
}

__kernel void test_convert_uint2_rte_ushort2( __global ushort2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rte(src[tid]);
}

__kernel void test_convert_uint2_rtn_ushort2( __global ushort2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtn(src[tid]);
}

__kernel void test_convert_uint2_rtp_ushort2( __global ushort2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtp(src[tid]);
}

__kernel void test_convert_uint2_rtz_ushort2( __global ushort2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtz(src[tid]);
}

__kernel void test_convert_short2_sat_ushort2( __global ushort2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat(src[tid]);
}

__kernel void test_convert_short2_sat_rte_ushort2( __global ushort2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rte(src[tid]);
}

__kernel void test_convert_short2_sat_rtn_ushort2( __global ushort2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtn(src[tid]);
}

__kernel void test_convert_short2_sat_rtp_ushort2( __global ushort2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtp(src[tid]);
}

__kernel void test_convert_short2_sat_rtz_ushort2( __global ushort2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtz(src[tid]);
}

__kernel void test_convert_short2_ushort2( __global ushort2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2(src[tid]);
}

__kernel void test_convert_short2_rte_ushort2( __global ushort2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rte(src[tid]);
}

__kernel void test_convert_short2_rtn_ushort2( __global ushort2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtn(src[tid]);
}

__kernel void test_convert_short2_rtp_ushort2( __global ushort2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtp(src[tid]);
}

__kernel void test_convert_short2_rtz_ushort2( __global ushort2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtz(src[tid]);
}

__kernel void test_convert_ushort2_sat_ushort2( __global ushort2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ushort2_sat_rte_ushort2( __global ushort2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ushort2_sat_rtn_ushort2( __global ushort2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ushort2_sat_rtp_ushort2( __global ushort2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ushort2_sat_rtz_ushort2( __global ushort2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ushort2_ushort2( __global ushort2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ushort2_rte_ushort2( __global ushort2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ushort2_rtn_ushort2( __global ushort2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ushort2_rtp_ushort2( __global ushort2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ushort2_rtz_ushort2( __global ushort2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_long2_sat_ushort2( __global ushort2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat(src[tid]);
}

__kernel void test_convert_long2_sat_rte_ushort2( __global ushort2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rte(src[tid]);
}

__kernel void test_convert_long2_sat_rtn_ushort2( __global ushort2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtn(src[tid]);
}

__kernel void test_convert_long2_sat_rtp_ushort2( __global ushort2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtp(src[tid]);
}

__kernel void test_convert_long2_sat_rtz_ushort2( __global ushort2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtz(src[tid]);
}

__kernel void test_convert_long2_ushort2( __global ushort2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2(src[tid]);
}

__kernel void test_convert_long2_rte_ushort2( __global ushort2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rte(src[tid]);
}

__kernel void test_convert_long2_rtn_ushort2( __global ushort2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtn(src[tid]);
}

__kernel void test_convert_long2_rtp_ushort2( __global ushort2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtp(src[tid]);
}

__kernel void test_convert_long2_rtz_ushort2( __global ushort2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtz(src[tid]);
}

__kernel void test_convert_ulong2_sat_ushort2( __global ushort2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat(src[tid]);
}

__kernel void test_convert_ulong2_sat_rte_ushort2( __global ushort2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rte(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtn_ushort2( __global ushort2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtp_ushort2( __global ushort2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtz_ushort2( __global ushort2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong2_ushort2( __global ushort2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2(src[tid]);
}

__kernel void test_convert_ulong2_rte_ushort2( __global ushort2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rte(src[tid]);
}

__kernel void test_convert_ulong2_rtn_ushort2( __global ushort2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtn(src[tid]);
}

__kernel void test_convert_ulong2_rtp_ushort2( __global ushort2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtp(src[tid]);
}

__kernel void test_convert_ulong2_rtz_ushort2( __global ushort2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtz(src[tid]);
}

__kernel void test_convert_float2_ushort2( __global ushort2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2(src[tid]);
}

__kernel void test_convert_float2_rte_ushort2( __global ushort2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rte(src[tid]);
}

__kernel void test_convert_float2_rtn_ushort2( __global ushort2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtn(src[tid]);
}

__kernel void test_convert_float2_rtp_ushort2( __global ushort2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtp(src[tid]);
}

__kernel void test_convert_float2_rtz_ushort2( __global ushort2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtz(src[tid]);
}

__kernel void test_convert_double2_ushort2( __global ushort2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2(src[tid]);
}

__kernel void test_convert_double2_rte_ushort2( __global ushort2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rte(src[tid]);
}

__kernel void test_convert_double2_rtn_ushort2( __global ushort2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtn(src[tid]);
}

__kernel void test_convert_double2_rtp_ushort2( __global ushort2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtp(src[tid]);
}

__kernel void test_convert_double2_rtz_ushort2( __global ushort2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtz(src[tid]);
}

__kernel void test_convert_char2_sat_long2( __global long2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat(src[tid]);
}

__kernel void test_convert_char2_sat_rte_long2( __global long2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rte(src[tid]);
}

__kernel void test_convert_char2_sat_rtn_long2( __global long2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtn(src[tid]);
}

__kernel void test_convert_char2_sat_rtp_long2( __global long2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtp(src[tid]);
}

__kernel void test_convert_char2_sat_rtz_long2( __global long2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtz(src[tid]);
}

__kernel void test_convert_char2_long2( __global long2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2(src[tid]);
}

__kernel void test_convert_char2_rte_long2( __global long2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rte(src[tid]);
}

__kernel void test_convert_char2_rtn_long2( __global long2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtn(src[tid]);
}

__kernel void test_convert_char2_rtp_long2( __global long2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtp(src[tid]);
}

__kernel void test_convert_char2_rtz_long2( __global long2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtz(src[tid]);
}

__kernel void test_convert_uchar2_sat_long2( __global long2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat(src[tid]);
}

__kernel void test_convert_uchar2_sat_rte_long2( __global long2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rte(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtn_long2( __global long2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtp_long2( __global long2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtz_long2( __global long2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar2_long2( __global long2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2(src[tid]);
}

__kernel void test_convert_uchar2_rte_long2( __global long2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rte(src[tid]);
}

__kernel void test_convert_uchar2_rtn_long2( __global long2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtn(src[tid]);
}

__kernel void test_convert_uchar2_rtp_long2( __global long2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtp(src[tid]);
}

__kernel void test_convert_uchar2_rtz_long2( __global long2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtz(src[tid]);
}

__kernel void test_convert_int2_sat_long2( __global long2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat(src[tid]);
}

__kernel void test_convert_int2_sat_rte_long2( __global long2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rte(src[tid]);
}

__kernel void test_convert_int2_sat_rtn_long2( __global long2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtn(src[tid]);
}

__kernel void test_convert_int2_sat_rtp_long2( __global long2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtp(src[tid]);
}

__kernel void test_convert_int2_sat_rtz_long2( __global long2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtz(src[tid]);
}

__kernel void test_convert_int2_long2( __global long2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2(src[tid]);
}

__kernel void test_convert_int2_rte_long2( __global long2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rte(src[tid]);
}

__kernel void test_convert_int2_rtn_long2( __global long2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtn(src[tid]);
}

__kernel void test_convert_int2_rtp_long2( __global long2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtp(src[tid]);
}

__kernel void test_convert_int2_rtz_long2( __global long2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtz(src[tid]);
}

__kernel void test_convert_uint2_sat_long2( __global long2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat(src[tid]);
}

__kernel void test_convert_uint2_sat_rte_long2( __global long2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rte(src[tid]);
}

__kernel void test_convert_uint2_sat_rtn_long2( __global long2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtn(src[tid]);
}

__kernel void test_convert_uint2_sat_rtp_long2( __global long2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtp(src[tid]);
}

__kernel void test_convert_uint2_sat_rtz_long2( __global long2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtz(src[tid]);
}

__kernel void test_convert_uint2_long2( __global long2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2(src[tid]);
}

__kernel void test_convert_uint2_rte_long2( __global long2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rte(src[tid]);
}

__kernel void test_convert_uint2_rtn_long2( __global long2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtn(src[tid]);
}

__kernel void test_convert_uint2_rtp_long2( __global long2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtp(src[tid]);
}

__kernel void test_convert_uint2_rtz_long2( __global long2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtz(src[tid]);
}

__kernel void test_convert_short2_sat_long2( __global long2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat(src[tid]);
}

__kernel void test_convert_short2_sat_rte_long2( __global long2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rte(src[tid]);
}

__kernel void test_convert_short2_sat_rtn_long2( __global long2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtn(src[tid]);
}

__kernel void test_convert_short2_sat_rtp_long2( __global long2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtp(src[tid]);
}

__kernel void test_convert_short2_sat_rtz_long2( __global long2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtz(src[tid]);
}

__kernel void test_convert_short2_long2( __global long2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2(src[tid]);
}

__kernel void test_convert_short2_rte_long2( __global long2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rte(src[tid]);
}

__kernel void test_convert_short2_rtn_long2( __global long2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtn(src[tid]);
}

__kernel void test_convert_short2_rtp_long2( __global long2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtp(src[tid]);
}

__kernel void test_convert_short2_rtz_long2( __global long2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtz(src[tid]);
}

__kernel void test_convert_ushort2_sat_long2( __global long2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat(src[tid]);
}

__kernel void test_convert_ushort2_sat_rte_long2( __global long2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rte(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtn_long2( __global long2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtp_long2( __global long2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtz_long2( __global long2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort2_long2( __global long2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2(src[tid]);
}

__kernel void test_convert_ushort2_rte_long2( __global long2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rte(src[tid]);
}

__kernel void test_convert_ushort2_rtn_long2( __global long2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtn(src[tid]);
}

__kernel void test_convert_ushort2_rtp_long2( __global long2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtp(src[tid]);
}

__kernel void test_convert_ushort2_rtz_long2( __global long2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtz(src[tid]);
}

__kernel void test_convert_long2_sat_long2( __global long2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_long2_sat_rte_long2( __global long2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_long2_sat_rtn_long2( __global long2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_long2_sat_rtp_long2( __global long2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_long2_sat_rtz_long2( __global long2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_long2_long2( __global long2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_long2_rte_long2( __global long2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_long2_rtn_long2( __global long2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_long2_rtp_long2( __global long2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_long2_rtz_long2( __global long2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ulong2_sat_long2( __global long2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat(src[tid]);
}

__kernel void test_convert_ulong2_sat_rte_long2( __global long2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rte(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtn_long2( __global long2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtp_long2( __global long2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtz_long2( __global long2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong2_long2( __global long2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2(src[tid]);
}

__kernel void test_convert_ulong2_rte_long2( __global long2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rte(src[tid]);
}

__kernel void test_convert_ulong2_rtn_long2( __global long2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtn(src[tid]);
}

__kernel void test_convert_ulong2_rtp_long2( __global long2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtp(src[tid]);
}

__kernel void test_convert_ulong2_rtz_long2( __global long2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtz(src[tid]);
}

__kernel void test_convert_float2_long2( __global long2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2(src[tid]);
}

__kernel void test_convert_float2_rte_long2( __global long2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rte(src[tid]);
}

__kernel void test_convert_float2_rtn_long2( __global long2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtn(src[tid]);
}

__kernel void test_convert_float2_rtp_long2( __global long2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtp(src[tid]);
}

__kernel void test_convert_float2_rtz_long2( __global long2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtz(src[tid]);
}

__kernel void test_convert_double2_long2( __global long2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2(src[tid]);
}

__kernel void test_convert_double2_rte_long2( __global long2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rte(src[tid]);
}

__kernel void test_convert_double2_rtn_long2( __global long2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtn(src[tid]);
}

__kernel void test_convert_double2_rtp_long2( __global long2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtp(src[tid]);
}

__kernel void test_convert_double2_rtz_long2( __global long2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtz(src[tid]);
}

__kernel void test_convert_char2_sat_ulong2( __global ulong2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat(src[tid]);
}

__kernel void test_convert_char2_sat_rte_ulong2( __global ulong2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rte(src[tid]);
}

__kernel void test_convert_char2_sat_rtn_ulong2( __global ulong2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtn(src[tid]);
}

__kernel void test_convert_char2_sat_rtp_ulong2( __global ulong2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtp(src[tid]);
}

__kernel void test_convert_char2_sat_rtz_ulong2( __global ulong2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtz(src[tid]);
}

__kernel void test_convert_char2_ulong2( __global ulong2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2(src[tid]);
}

__kernel void test_convert_char2_rte_ulong2( __global ulong2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rte(src[tid]);
}

__kernel void test_convert_char2_rtn_ulong2( __global ulong2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtn(src[tid]);
}

__kernel void test_convert_char2_rtp_ulong2( __global ulong2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtp(src[tid]);
}

__kernel void test_convert_char2_rtz_ulong2( __global ulong2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtz(src[tid]);
}

__kernel void test_convert_uchar2_sat_ulong2( __global ulong2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat(src[tid]);
}

__kernel void test_convert_uchar2_sat_rte_ulong2( __global ulong2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rte(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtn_ulong2( __global ulong2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtp_ulong2( __global ulong2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtz_ulong2( __global ulong2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar2_ulong2( __global ulong2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2(src[tid]);
}

__kernel void test_convert_uchar2_rte_ulong2( __global ulong2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rte(src[tid]);
}

__kernel void test_convert_uchar2_rtn_ulong2( __global ulong2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtn(src[tid]);
}

__kernel void test_convert_uchar2_rtp_ulong2( __global ulong2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtp(src[tid]);
}

__kernel void test_convert_uchar2_rtz_ulong2( __global ulong2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtz(src[tid]);
}

__kernel void test_convert_int2_sat_ulong2( __global ulong2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat(src[tid]);
}

__kernel void test_convert_int2_sat_rte_ulong2( __global ulong2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rte(src[tid]);
}

__kernel void test_convert_int2_sat_rtn_ulong2( __global ulong2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtn(src[tid]);
}

__kernel void test_convert_int2_sat_rtp_ulong2( __global ulong2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtp(src[tid]);
}

__kernel void test_convert_int2_sat_rtz_ulong2( __global ulong2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtz(src[tid]);
}

__kernel void test_convert_int2_ulong2( __global ulong2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2(src[tid]);
}

__kernel void test_convert_int2_rte_ulong2( __global ulong2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rte(src[tid]);
}

__kernel void test_convert_int2_rtn_ulong2( __global ulong2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtn(src[tid]);
}

__kernel void test_convert_int2_rtp_ulong2( __global ulong2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtp(src[tid]);
}

__kernel void test_convert_int2_rtz_ulong2( __global ulong2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtz(src[tid]);
}

__kernel void test_convert_uint2_sat_ulong2( __global ulong2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat(src[tid]);
}

__kernel void test_convert_uint2_sat_rte_ulong2( __global ulong2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rte(src[tid]);
}

__kernel void test_convert_uint2_sat_rtn_ulong2( __global ulong2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtn(src[tid]);
}

__kernel void test_convert_uint2_sat_rtp_ulong2( __global ulong2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtp(src[tid]);
}

__kernel void test_convert_uint2_sat_rtz_ulong2( __global ulong2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtz(src[tid]);
}

__kernel void test_convert_uint2_ulong2( __global ulong2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2(src[tid]);
}

__kernel void test_convert_uint2_rte_ulong2( __global ulong2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rte(src[tid]);
}

__kernel void test_convert_uint2_rtn_ulong2( __global ulong2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtn(src[tid]);
}

__kernel void test_convert_uint2_rtp_ulong2( __global ulong2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtp(src[tid]);
}

__kernel void test_convert_uint2_rtz_ulong2( __global ulong2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtz(src[tid]);
}

__kernel void test_convert_short2_sat_ulong2( __global ulong2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat(src[tid]);
}

__kernel void test_convert_short2_sat_rte_ulong2( __global ulong2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rte(src[tid]);
}

__kernel void test_convert_short2_sat_rtn_ulong2( __global ulong2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtn(src[tid]);
}

__kernel void test_convert_short2_sat_rtp_ulong2( __global ulong2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtp(src[tid]);
}

__kernel void test_convert_short2_sat_rtz_ulong2( __global ulong2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtz(src[tid]);
}

__kernel void test_convert_short2_ulong2( __global ulong2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2(src[tid]);
}

__kernel void test_convert_short2_rte_ulong2( __global ulong2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rte(src[tid]);
}

__kernel void test_convert_short2_rtn_ulong2( __global ulong2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtn(src[tid]);
}

__kernel void test_convert_short2_rtp_ulong2( __global ulong2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtp(src[tid]);
}

__kernel void test_convert_short2_rtz_ulong2( __global ulong2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtz(src[tid]);
}

__kernel void test_convert_ushort2_sat_ulong2( __global ulong2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat(src[tid]);
}

__kernel void test_convert_ushort2_sat_rte_ulong2( __global ulong2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rte(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtn_ulong2( __global ulong2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtp_ulong2( __global ulong2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtz_ulong2( __global ulong2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort2_ulong2( __global ulong2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2(src[tid]);
}

__kernel void test_convert_ushort2_rte_ulong2( __global ulong2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rte(src[tid]);
}

__kernel void test_convert_ushort2_rtn_ulong2( __global ulong2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtn(src[tid]);
}

__kernel void test_convert_ushort2_rtp_ulong2( __global ulong2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtp(src[tid]);
}

__kernel void test_convert_ushort2_rtz_ulong2( __global ulong2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtz(src[tid]);
}

__kernel void test_convert_long2_sat_ulong2( __global ulong2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat(src[tid]);
}

__kernel void test_convert_long2_sat_rte_ulong2( __global ulong2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rte(src[tid]);
}

__kernel void test_convert_long2_sat_rtn_ulong2( __global ulong2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtn(src[tid]);
}

__kernel void test_convert_long2_sat_rtp_ulong2( __global ulong2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtp(src[tid]);
}

__kernel void test_convert_long2_sat_rtz_ulong2( __global ulong2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtz(src[tid]);
}

__kernel void test_convert_long2_ulong2( __global ulong2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2(src[tid]);
}

__kernel void test_convert_long2_rte_ulong2( __global ulong2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rte(src[tid]);
}

__kernel void test_convert_long2_rtn_ulong2( __global ulong2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtn(src[tid]);
}

__kernel void test_convert_long2_rtp_ulong2( __global ulong2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtp(src[tid]);
}

__kernel void test_convert_long2_rtz_ulong2( __global ulong2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtz(src[tid]);
}

__kernel void test_convert_ulong2_sat_ulong2( __global ulong2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ulong2_sat_rte_ulong2( __global ulong2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ulong2_sat_rtn_ulong2( __global ulong2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ulong2_sat_rtp_ulong2( __global ulong2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ulong2_sat_rtz_ulong2( __global ulong2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ulong2_ulong2( __global ulong2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ulong2_rte_ulong2( __global ulong2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ulong2_rtn_ulong2( __global ulong2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ulong2_rtp_ulong2( __global ulong2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_ulong2_rtz_ulong2( __global ulong2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_float2_ulong2( __global ulong2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2(src[tid]);
}

__kernel void test_convert_float2_rte_ulong2( __global ulong2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rte(src[tid]);
}

__kernel void test_convert_float2_rtn_ulong2( __global ulong2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtn(src[tid]);
}

__kernel void test_convert_float2_rtp_ulong2( __global ulong2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtp(src[tid]);
}

__kernel void test_convert_float2_rtz_ulong2( __global ulong2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtz(src[tid]);
}

__kernel void test_convert_double2_ulong2( __global ulong2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2(src[tid]);
}

__kernel void test_convert_double2_rte_ulong2( __global ulong2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rte(src[tid]);
}

__kernel void test_convert_double2_rtn_ulong2( __global ulong2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtn(src[tid]);
}

__kernel void test_convert_double2_rtp_ulong2( __global ulong2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtp(src[tid]);
}

__kernel void test_convert_double2_rtz_ulong2( __global ulong2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtz(src[tid]);
}

__kernel void test_convert_char2_sat_float2( __global float2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat(src[tid]);
}

__kernel void test_convert_char2_sat_rte_float2( __global float2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rte(src[tid]);
}

__kernel void test_convert_char2_sat_rtn_float2( __global float2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtn(src[tid]);
}

__kernel void test_convert_char2_sat_rtp_float2( __global float2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtp(src[tid]);
}

__kernel void test_convert_char2_sat_rtz_float2( __global float2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtz(src[tid]);
}

__kernel void test_convert_char2_float2( __global float2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2(src[tid]);
}

__kernel void test_convert_char2_rte_float2( __global float2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rte(src[tid]);
}

__kernel void test_convert_char2_rtn_float2( __global float2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtn(src[tid]);
}

__kernel void test_convert_char2_rtp_float2( __global float2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtp(src[tid]);
}

__kernel void test_convert_char2_rtz_float2( __global float2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtz(src[tid]);
}

__kernel void test_convert_uchar2_sat_float2( __global float2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat(src[tid]);
}

__kernel void test_convert_uchar2_sat_rte_float2( __global float2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rte(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtn_float2( __global float2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtp_float2( __global float2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtz_float2( __global float2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar2_float2( __global float2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2(src[tid]);
}

__kernel void test_convert_uchar2_rte_float2( __global float2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rte(src[tid]);
}

__kernel void test_convert_uchar2_rtn_float2( __global float2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtn(src[tid]);
}

__kernel void test_convert_uchar2_rtp_float2( __global float2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtp(src[tid]);
}

__kernel void test_convert_uchar2_rtz_float2( __global float2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtz(src[tid]);
}

__kernel void test_convert_int2_sat_float2( __global float2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat(src[tid]);
}

__kernel void test_convert_int2_sat_rte_float2( __global float2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rte(src[tid]);
}

__kernel void test_convert_int2_sat_rtn_float2( __global float2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtn(src[tid]);
}

__kernel void test_convert_int2_sat_rtp_float2( __global float2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtp(src[tid]);
}

__kernel void test_convert_int2_sat_rtz_float2( __global float2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtz(src[tid]);
}

__kernel void test_convert_int2_float2( __global float2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2(src[tid]);
}

__kernel void test_convert_int2_rte_float2( __global float2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rte(src[tid]);
}

__kernel void test_convert_int2_rtn_float2( __global float2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtn(src[tid]);
}

__kernel void test_convert_int2_rtp_float2( __global float2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtp(src[tid]);
}

__kernel void test_convert_int2_rtz_float2( __global float2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtz(src[tid]);
}

__kernel void test_convert_uint2_sat_float2( __global float2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat(src[tid]);
}

__kernel void test_convert_uint2_sat_rte_float2( __global float2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rte(src[tid]);
}

__kernel void test_convert_uint2_sat_rtn_float2( __global float2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtn(src[tid]);
}

__kernel void test_convert_uint2_sat_rtp_float2( __global float2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtp(src[tid]);
}

__kernel void test_convert_uint2_sat_rtz_float2( __global float2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtz(src[tid]);
}

__kernel void test_convert_uint2_float2( __global float2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2(src[tid]);
}

__kernel void test_convert_uint2_rte_float2( __global float2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rte(src[tid]);
}

__kernel void test_convert_uint2_rtn_float2( __global float2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtn(src[tid]);
}

__kernel void test_convert_uint2_rtp_float2( __global float2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtp(src[tid]);
}

__kernel void test_convert_uint2_rtz_float2( __global float2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtz(src[tid]);
}

__kernel void test_convert_short2_sat_float2( __global float2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat(src[tid]);
}

__kernel void test_convert_short2_sat_rte_float2( __global float2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rte(src[tid]);
}

__kernel void test_convert_short2_sat_rtn_float2( __global float2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtn(src[tid]);
}

__kernel void test_convert_short2_sat_rtp_float2( __global float2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtp(src[tid]);
}

__kernel void test_convert_short2_sat_rtz_float2( __global float2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtz(src[tid]);
}

__kernel void test_convert_short2_float2( __global float2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2(src[tid]);
}

__kernel void test_convert_short2_rte_float2( __global float2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rte(src[tid]);
}

__kernel void test_convert_short2_rtn_float2( __global float2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtn(src[tid]);
}

__kernel void test_convert_short2_rtp_float2( __global float2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtp(src[tid]);
}

__kernel void test_convert_short2_rtz_float2( __global float2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtz(src[tid]);
}

__kernel void test_convert_ushort2_sat_float2( __global float2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat(src[tid]);
}

__kernel void test_convert_ushort2_sat_rte_float2( __global float2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rte(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtn_float2( __global float2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtp_float2( __global float2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtz_float2( __global float2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort2_float2( __global float2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2(src[tid]);
}

__kernel void test_convert_ushort2_rte_float2( __global float2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rte(src[tid]);
}

__kernel void test_convert_ushort2_rtn_float2( __global float2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtn(src[tid]);
}

__kernel void test_convert_ushort2_rtp_float2( __global float2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtp(src[tid]);
}

__kernel void test_convert_ushort2_rtz_float2( __global float2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtz(src[tid]);
}

__kernel void test_convert_long2_sat_float2( __global float2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat(src[tid]);
}

__kernel void test_convert_long2_sat_rte_float2( __global float2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rte(src[tid]);
}

__kernel void test_convert_long2_sat_rtn_float2( __global float2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtn(src[tid]);
}

__kernel void test_convert_long2_sat_rtp_float2( __global float2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtp(src[tid]);
}

__kernel void test_convert_long2_sat_rtz_float2( __global float2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtz(src[tid]);
}

__kernel void test_convert_long2_float2( __global float2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2(src[tid]);
}

__kernel void test_convert_long2_rte_float2( __global float2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rte(src[tid]);
}

__kernel void test_convert_long2_rtn_float2( __global float2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtn(src[tid]);
}

__kernel void test_convert_long2_rtp_float2( __global float2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtp(src[tid]);
}

__kernel void test_convert_long2_rtz_float2( __global float2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtz(src[tid]);
}

__kernel void test_convert_ulong2_sat_float2( __global float2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat(src[tid]);
}

__kernel void test_convert_ulong2_sat_rte_float2( __global float2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rte(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtn_float2( __global float2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtp_float2( __global float2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtz_float2( __global float2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong2_float2( __global float2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2(src[tid]);
}

__kernel void test_convert_ulong2_rte_float2( __global float2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rte(src[tid]);
}

__kernel void test_convert_ulong2_rtn_float2( __global float2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtn(src[tid]);
}

__kernel void test_convert_ulong2_rtp_float2( __global float2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtp(src[tid]);
}

__kernel void test_convert_ulong2_rtz_float2( __global float2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtz(src[tid]);
}

__kernel void test_convert_float2_float2( __global float2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_float2_rte_float2( __global float2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_float2_rtn_float2( __global float2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_float2_rtp_float2( __global float2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_float2_rtz_float2( __global float2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_double2_float2( __global float2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2(src[tid]);
}

__kernel void test_convert_double2_rte_float2( __global float2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rte(src[tid]);
}

__kernel void test_convert_double2_rtn_float2( __global float2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtn(src[tid]);
}

__kernel void test_convert_double2_rtp_float2( __global float2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtp(src[tid]);
}

__kernel void test_convert_double2_rtz_float2( __global float2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double2_rtz(src[tid]);
}

__kernel void test_convert_char2_sat_double2( __global double2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat(src[tid]);
}

__kernel void test_convert_char2_sat_rte_double2( __global double2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rte(src[tid]);
}

__kernel void test_convert_char2_sat_rtn_double2( __global double2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtn(src[tid]);
}

__kernel void test_convert_char2_sat_rtp_double2( __global double2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtp(src[tid]);
}

__kernel void test_convert_char2_sat_rtz_double2( __global double2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_sat_rtz(src[tid]);
}

__kernel void test_convert_char2_double2( __global double2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2(src[tid]);
}

__kernel void test_convert_char2_rte_double2( __global double2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rte(src[tid]);
}

__kernel void test_convert_char2_rtn_double2( __global double2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtn(src[tid]);
}

__kernel void test_convert_char2_rtp_double2( __global double2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtp(src[tid]);
}

__kernel void test_convert_char2_rtz_double2( __global double2 *src, __global char2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char2_rtz(src[tid]);
}

__kernel void test_convert_uchar2_sat_double2( __global double2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat(src[tid]);
}

__kernel void test_convert_uchar2_sat_rte_double2( __global double2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rte(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtn_double2( __global double2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtp_double2( __global double2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar2_sat_rtz_double2( __global double2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar2_double2( __global double2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2(src[tid]);
}

__kernel void test_convert_uchar2_rte_double2( __global double2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rte(src[tid]);
}

__kernel void test_convert_uchar2_rtn_double2( __global double2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtn(src[tid]);
}

__kernel void test_convert_uchar2_rtp_double2( __global double2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtp(src[tid]);
}

__kernel void test_convert_uchar2_rtz_double2( __global double2 *src, __global uchar2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar2_rtz(src[tid]);
}

__kernel void test_convert_int2_sat_double2( __global double2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat(src[tid]);
}

__kernel void test_convert_int2_sat_rte_double2( __global double2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rte(src[tid]);
}

__kernel void test_convert_int2_sat_rtn_double2( __global double2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtn(src[tid]);
}

__kernel void test_convert_int2_sat_rtp_double2( __global double2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtp(src[tid]);
}

__kernel void test_convert_int2_sat_rtz_double2( __global double2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_sat_rtz(src[tid]);
}

__kernel void test_convert_int2_double2( __global double2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2(src[tid]);
}

__kernel void test_convert_int2_rte_double2( __global double2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rte(src[tid]);
}

__kernel void test_convert_int2_rtn_double2( __global double2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtn(src[tid]);
}

__kernel void test_convert_int2_rtp_double2( __global double2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtp(src[tid]);
}

__kernel void test_convert_int2_rtz_double2( __global double2 *src, __global int2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int2_rtz(src[tid]);
}

__kernel void test_convert_uint2_sat_double2( __global double2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat(src[tid]);
}

__kernel void test_convert_uint2_sat_rte_double2( __global double2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rte(src[tid]);
}

__kernel void test_convert_uint2_sat_rtn_double2( __global double2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtn(src[tid]);
}

__kernel void test_convert_uint2_sat_rtp_double2( __global double2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtp(src[tid]);
}

__kernel void test_convert_uint2_sat_rtz_double2( __global double2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_sat_rtz(src[tid]);
}

__kernel void test_convert_uint2_double2( __global double2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2(src[tid]);
}

__kernel void test_convert_uint2_rte_double2( __global double2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rte(src[tid]);
}

__kernel void test_convert_uint2_rtn_double2( __global double2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtn(src[tid]);
}

__kernel void test_convert_uint2_rtp_double2( __global double2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtp(src[tid]);
}

__kernel void test_convert_uint2_rtz_double2( __global double2 *src, __global uint2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint2_rtz(src[tid]);
}

__kernel void test_convert_short2_sat_double2( __global double2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat(src[tid]);
}

__kernel void test_convert_short2_sat_rte_double2( __global double2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rte(src[tid]);
}

__kernel void test_convert_short2_sat_rtn_double2( __global double2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtn(src[tid]);
}

__kernel void test_convert_short2_sat_rtp_double2( __global double2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtp(src[tid]);
}

__kernel void test_convert_short2_sat_rtz_double2( __global double2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_sat_rtz(src[tid]);
}

__kernel void test_convert_short2_double2( __global double2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2(src[tid]);
}

__kernel void test_convert_short2_rte_double2( __global double2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rte(src[tid]);
}

__kernel void test_convert_short2_rtn_double2( __global double2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtn(src[tid]);
}

__kernel void test_convert_short2_rtp_double2( __global double2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtp(src[tid]);
}

__kernel void test_convert_short2_rtz_double2( __global double2 *src, __global short2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short2_rtz(src[tid]);
}

__kernel void test_convert_ushort2_sat_double2( __global double2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat(src[tid]);
}

__kernel void test_convert_ushort2_sat_rte_double2( __global double2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rte(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtn_double2( __global double2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtp_double2( __global double2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort2_sat_rtz_double2( __global double2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort2_double2( __global double2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2(src[tid]);
}

__kernel void test_convert_ushort2_rte_double2( __global double2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rte(src[tid]);
}

__kernel void test_convert_ushort2_rtn_double2( __global double2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtn(src[tid]);
}

__kernel void test_convert_ushort2_rtp_double2( __global double2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtp(src[tid]);
}

__kernel void test_convert_ushort2_rtz_double2( __global double2 *src, __global ushort2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort2_rtz(src[tid]);
}

__kernel void test_convert_long2_sat_double2( __global double2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat(src[tid]);
}

__kernel void test_convert_long2_sat_rte_double2( __global double2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rte(src[tid]);
}

__kernel void test_convert_long2_sat_rtn_double2( __global double2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtn(src[tid]);
}

__kernel void test_convert_long2_sat_rtp_double2( __global double2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtp(src[tid]);
}

__kernel void test_convert_long2_sat_rtz_double2( __global double2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_sat_rtz(src[tid]);
}

__kernel void test_convert_long2_double2( __global double2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2(src[tid]);
}

__kernel void test_convert_long2_rte_double2( __global double2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rte(src[tid]);
}

__kernel void test_convert_long2_rtn_double2( __global double2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtn(src[tid]);
}

__kernel void test_convert_long2_rtp_double2( __global double2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtp(src[tid]);
}

__kernel void test_convert_long2_rtz_double2( __global double2 *src, __global long2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long2_rtz(src[tid]);
}

__kernel void test_convert_ulong2_sat_double2( __global double2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat(src[tid]);
}

__kernel void test_convert_ulong2_sat_rte_double2( __global double2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rte(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtn_double2( __global double2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtp_double2( __global double2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong2_sat_rtz_double2( __global double2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong2_double2( __global double2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2(src[tid]);
}

__kernel void test_convert_ulong2_rte_double2( __global double2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rte(src[tid]);
}

__kernel void test_convert_ulong2_rtn_double2( __global double2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtn(src[tid]);
}

__kernel void test_convert_ulong2_rtp_double2( __global double2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtp(src[tid]);
}

__kernel void test_convert_ulong2_rtz_double2( __global double2 *src, __global ulong2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong2_rtz(src[tid]);
}

__kernel void test_convert_float2_double2( __global double2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2(src[tid]);
}

__kernel void test_convert_float2_rte_double2( __global double2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rte(src[tid]);
}

__kernel void test_convert_float2_rtn_double2( __global double2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtn(src[tid]);
}

__kernel void test_convert_float2_rtp_double2( __global double2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtp(src[tid]);
}

__kernel void test_convert_float2_rtz_double2( __global double2 *src, __global float2 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float2_rtz(src[tid]);
}

__kernel void test_convert_double2_double2( __global double2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_double2_rte_double2( __global double2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_double2_rtn_double2( __global double2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_double2_rtp_double2( __global double2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
}

__kernel void test_convert_double2_rtz_double2( __global double2 *src, __global double2 *dst ){
  size_t tid = get_global_id(0);
}


