__kernel void test_convert_char16_sat_char16( __global char16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat(src[tid]);
}

__kernel void test_convert_char16_sat_rte_char16( __global char16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rte(src[tid]);
}

__kernel void test_convert_char16_sat_rtn_char16( __global char16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtn(src[tid]);
}

__kernel void test_convert_char16_sat_rtp_char16( __global char16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtp(src[tid]);
}

__kernel void test_convert_char16_sat_rtz_char16( __global char16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtz(src[tid]);
}

__kernel void test_convert_char16_char16( __global char16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16(src[tid]);
}

__kernel void test_convert_char16_rte_char16( __global char16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rte(src[tid]);
}

__kernel void test_convert_char16_rtn_char16( __global char16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtn(src[tid]);
}

__kernel void test_convert_char16_rtp_char16( __global char16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtp(src[tid]);
}

__kernel void test_convert_char16_rtz_char16( __global char16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtz(src[tid]);
}

__kernel void test_convert_uchar16_sat_char16( __global char16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat(src[tid]);
}

__kernel void test_convert_uchar16_sat_rte_char16( __global char16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rte(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtn_char16( __global char16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtp_char16( __global char16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtz_char16( __global char16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar16_char16( __global char16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16(src[tid]);
}

__kernel void test_convert_uchar16_rte_char16( __global char16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rte(src[tid]);
}

__kernel void test_convert_uchar16_rtn_char16( __global char16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtn(src[tid]);
}

__kernel void test_convert_uchar16_rtp_char16( __global char16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtp(src[tid]);
}

__kernel void test_convert_uchar16_rtz_char16( __global char16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtz(src[tid]);
}

__kernel void test_convert_int16_sat_char16( __global char16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat(src[tid]);
}

__kernel void test_convert_int16_sat_rte_char16( __global char16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rte(src[tid]);
}

__kernel void test_convert_int16_sat_rtn_char16( __global char16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtn(src[tid]);
}

__kernel void test_convert_int16_sat_rtp_char16( __global char16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtp(src[tid]);
}

__kernel void test_convert_int16_sat_rtz_char16( __global char16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtz(src[tid]);
}

__kernel void test_convert_int16_char16( __global char16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16(src[tid]);
}

__kernel void test_convert_int16_rte_char16( __global char16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rte(src[tid]);
}

__kernel void test_convert_int16_rtn_char16( __global char16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtn(src[tid]);
}

__kernel void test_convert_int16_rtp_char16( __global char16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtp(src[tid]);
}

__kernel void test_convert_int16_rtz_char16( __global char16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtz(src[tid]);
}

__kernel void test_convert_uint16_sat_char16( __global char16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat(src[tid]);
}

__kernel void test_convert_uint16_sat_rte_char16( __global char16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rte(src[tid]);
}

__kernel void test_convert_uint16_sat_rtn_char16( __global char16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtn(src[tid]);
}

__kernel void test_convert_uint16_sat_rtp_char16( __global char16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtp(src[tid]);
}

__kernel void test_convert_uint16_sat_rtz_char16( __global char16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtz(src[tid]);
}

__kernel void test_convert_uint16_char16( __global char16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16(src[tid]);
}

__kernel void test_convert_uint16_rte_char16( __global char16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rte(src[tid]);
}

__kernel void test_convert_uint16_rtn_char16( __global char16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtn(src[tid]);
}

__kernel void test_convert_uint16_rtp_char16( __global char16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtp(src[tid]);
}

__kernel void test_convert_uint16_rtz_char16( __global char16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtz(src[tid]);
}

__kernel void test_convert_short16_sat_char16( __global char16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat(src[tid]);
}

__kernel void test_convert_short16_sat_rte_char16( __global char16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rte(src[tid]);
}

__kernel void test_convert_short16_sat_rtn_char16( __global char16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtn(src[tid]);
}

__kernel void test_convert_short16_sat_rtp_char16( __global char16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtp(src[tid]);
}

__kernel void test_convert_short16_sat_rtz_char16( __global char16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtz(src[tid]);
}

__kernel void test_convert_short16_char16( __global char16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16(src[tid]);
}

__kernel void test_convert_short16_rte_char16( __global char16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rte(src[tid]);
}

__kernel void test_convert_short16_rtn_char16( __global char16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtn(src[tid]);
}

__kernel void test_convert_short16_rtp_char16( __global char16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtp(src[tid]);
}

__kernel void test_convert_short16_rtz_char16( __global char16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtz(src[tid]);
}

__kernel void test_convert_ushort16_sat_char16( __global char16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat(src[tid]);
}

__kernel void test_convert_ushort16_sat_rte_char16( __global char16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rte(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtn_char16( __global char16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtp_char16( __global char16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtz_char16( __global char16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort16_char16( __global char16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16(src[tid]);
}

__kernel void test_convert_ushort16_rte_char16( __global char16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rte(src[tid]);
}

__kernel void test_convert_ushort16_rtn_char16( __global char16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtn(src[tid]);
}

__kernel void test_convert_ushort16_rtp_char16( __global char16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtp(src[tid]);
}

__kernel void test_convert_ushort16_rtz_char16( __global char16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtz(src[tid]);
}

__kernel void test_convert_float16_char16( __global char16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16(src[tid]);
}

__kernel void test_convert_float16_rte_char16( __global char16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rte(src[tid]);
}

__kernel void test_convert_float16_rtn_char16( __global char16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtn(src[tid]);
}

__kernel void test_convert_float16_rtp_char16( __global char16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtp(src[tid]);
}

__kernel void test_convert_float16_rtz_char16( __global char16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtz(src[tid]);
}


