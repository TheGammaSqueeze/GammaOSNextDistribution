__kernel void test_convert_double16_char16( __global char16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16(src[tid]);
}

__kernel void test_convert_double16_rte_char16( __global char16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rte(src[tid]);
}

__kernel void test_convert_double16_rtn_char16( __global char16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtn(src[tid]);
}

__kernel void test_convert_double16_rtp_char16( __global char16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtp(src[tid]);
}

__kernel void test_convert_double16_rtz_char16( __global char16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtz(src[tid]);
}

__kernel void test_convert_char16_sat_uchar16( __global uchar16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat(src[tid]);
}

__kernel void test_convert_char16_sat_rte_uchar16( __global uchar16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rte(src[tid]);
}

__kernel void test_convert_char16_sat_rtn_uchar16( __global uchar16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtn(src[tid]);
}

__kernel void test_convert_char16_sat_rtp_uchar16( __global uchar16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtp(src[tid]);
}

__kernel void test_convert_char16_sat_rtz_uchar16( __global uchar16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtz(src[tid]);
}

__kernel void test_convert_char16_uchar16( __global uchar16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16(src[tid]);
}

__kernel void test_convert_char16_rte_uchar16( __global uchar16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rte(src[tid]);
}

__kernel void test_convert_char16_rtn_uchar16( __global uchar16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtn(src[tid]);
}

__kernel void test_convert_char16_rtp_uchar16( __global uchar16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtp(src[tid]);
}

__kernel void test_convert_char16_rtz_uchar16( __global uchar16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtz(src[tid]);
}

__kernel void test_convert_uchar16_sat_uchar16( __global uchar16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat(src[tid]);
}

__kernel void test_convert_uchar16_sat_rte_uchar16( __global uchar16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rte(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtn_uchar16( __global uchar16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtp_uchar16( __global uchar16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtz_uchar16( __global uchar16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar16_uchar16( __global uchar16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16(src[tid]);
}

__kernel void test_convert_uchar16_rte_uchar16( __global uchar16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rte(src[tid]);
}

__kernel void test_convert_uchar16_rtn_uchar16( __global uchar16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtn(src[tid]);
}

__kernel void test_convert_uchar16_rtp_uchar16( __global uchar16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtp(src[tid]);
}

__kernel void test_convert_uchar16_rtz_uchar16( __global uchar16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtz(src[tid]);
}

__kernel void test_convert_int16_sat_uchar16( __global uchar16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat(src[tid]);
}

__kernel void test_convert_int16_sat_rte_uchar16( __global uchar16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rte(src[tid]);
}

__kernel void test_convert_int16_sat_rtn_uchar16( __global uchar16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtn(src[tid]);
}

__kernel void test_convert_int16_sat_rtp_uchar16( __global uchar16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtp(src[tid]);
}

__kernel void test_convert_int16_sat_rtz_uchar16( __global uchar16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtz(src[tid]);
}

__kernel void test_convert_int16_uchar16( __global uchar16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16(src[tid]);
}

__kernel void test_convert_int16_rte_uchar16( __global uchar16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rte(src[tid]);
}

__kernel void test_convert_int16_rtn_uchar16( __global uchar16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtn(src[tid]);
}

__kernel void test_convert_int16_rtp_uchar16( __global uchar16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtp(src[tid]);
}

__kernel void test_convert_int16_rtz_uchar16( __global uchar16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtz(src[tid]);
}

__kernel void test_convert_uint16_sat_uchar16( __global uchar16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat(src[tid]);
}

__kernel void test_convert_uint16_sat_rte_uchar16( __global uchar16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rte(src[tid]);
}

__kernel void test_convert_uint16_sat_rtn_uchar16( __global uchar16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtn(src[tid]);
}

__kernel void test_convert_uint16_sat_rtp_uchar16( __global uchar16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtp(src[tid]);
}

__kernel void test_convert_uint16_sat_rtz_uchar16( __global uchar16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtz(src[tid]);
}

__kernel void test_convert_uint16_uchar16( __global uchar16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16(src[tid]);
}

__kernel void test_convert_uint16_rte_uchar16( __global uchar16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rte(src[tid]);
}

__kernel void test_convert_uint16_rtn_uchar16( __global uchar16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtn(src[tid]);
}

__kernel void test_convert_uint16_rtp_uchar16( __global uchar16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtp(src[tid]);
}

__kernel void test_convert_uint16_rtz_uchar16( __global uchar16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtz(src[tid]);
}

__kernel void test_convert_short16_sat_uchar16( __global uchar16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat(src[tid]);
}

__kernel void test_convert_short16_sat_rte_uchar16( __global uchar16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rte(src[tid]);
}

__kernel void test_convert_short16_sat_rtn_uchar16( __global uchar16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtn(src[tid]);
}

__kernel void test_convert_short16_sat_rtp_uchar16( __global uchar16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtp(src[tid]);
}

__kernel void test_convert_short16_sat_rtz_uchar16( __global uchar16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtz(src[tid]);
}

__kernel void test_convert_short16_uchar16( __global uchar16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16(src[tid]);
}

__kernel void test_convert_short16_rte_uchar16( __global uchar16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rte(src[tid]);
}

__kernel void test_convert_short16_rtn_uchar16( __global uchar16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtn(src[tid]);
}

__kernel void test_convert_short16_rtp_uchar16( __global uchar16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtp(src[tid]);
}

__kernel void test_convert_short16_rtz_uchar16( __global uchar16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtz(src[tid]);
}

__kernel void test_convert_ushort16_sat_uchar16( __global uchar16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat(src[tid]);
}

__kernel void test_convert_ushort16_sat_rte_uchar16( __global uchar16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rte(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtn_uchar16( __global uchar16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtp_uchar16( __global uchar16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtz_uchar16( __global uchar16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort16_uchar16( __global uchar16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16(src[tid]);
}

__kernel void test_convert_ushort16_rte_uchar16( __global uchar16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rte(src[tid]);
}

__kernel void test_convert_ushort16_rtn_uchar16( __global uchar16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtn(src[tid]);
}

__kernel void test_convert_ushort16_rtp_uchar16( __global uchar16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtp(src[tid]);
}

__kernel void test_convert_ushort16_rtz_uchar16( __global uchar16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtz(src[tid]);
}

__kernel void test_convert_long16_sat_uchar16( __global uchar16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat(src[tid]);
}

__kernel void test_convert_long16_sat_rte_uchar16( __global uchar16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rte(src[tid]);
}

__kernel void test_convert_long16_sat_rtn_uchar16( __global uchar16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtn(src[tid]);
}

__kernel void test_convert_long16_sat_rtp_uchar16( __global uchar16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtp(src[tid]);
}

__kernel void test_convert_long16_sat_rtz_uchar16( __global uchar16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtz(src[tid]);
}

__kernel void test_convert_long16_uchar16( __global uchar16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16(src[tid]);
}

__kernel void test_convert_long16_rte_uchar16( __global uchar16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rte(src[tid]);
}

__kernel void test_convert_long16_rtn_uchar16( __global uchar16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtn(src[tid]);
}

__kernel void test_convert_long16_rtp_uchar16( __global uchar16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtp(src[tid]);
}

__kernel void test_convert_long16_rtz_uchar16( __global uchar16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtz(src[tid]);
}

__kernel void test_convert_ulong16_sat_uchar16( __global uchar16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat(src[tid]);
}

__kernel void test_convert_ulong16_sat_rte_uchar16( __global uchar16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rte(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtn_uchar16( __global uchar16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtp_uchar16( __global uchar16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtz_uchar16( __global uchar16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong16_uchar16( __global uchar16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16(src[tid]);
}

__kernel void test_convert_ulong16_rte_uchar16( __global uchar16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rte(src[tid]);
}

__kernel void test_convert_ulong16_rtn_uchar16( __global uchar16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtn(src[tid]);
}

__kernel void test_convert_ulong16_rtp_uchar16( __global uchar16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtp(src[tid]);
}

__kernel void test_convert_ulong16_rtz_uchar16( __global uchar16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtz(src[tid]);
}

__kernel void test_convert_float16_uchar16( __global uchar16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16(src[tid]);
}

__kernel void test_convert_float16_rte_uchar16( __global uchar16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rte(src[tid]);
}

__kernel void test_convert_float16_rtn_uchar16( __global uchar16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtn(src[tid]);
}

__kernel void test_convert_float16_rtp_uchar16( __global uchar16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtp(src[tid]);
}

__kernel void test_convert_float16_rtz_uchar16( __global uchar16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtz(src[tid]);
}

__kernel void test_convert_double16_uchar16( __global uchar16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16(src[tid]);
}

__kernel void test_convert_double16_rte_uchar16( __global uchar16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rte(src[tid]);
}

__kernel void test_convert_double16_rtn_uchar16( __global uchar16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtn(src[tid]);
}

__kernel void test_convert_double16_rtp_uchar16( __global uchar16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtp(src[tid]);
}

__kernel void test_convert_double16_rtz_uchar16( __global uchar16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtz(src[tid]);
}

__kernel void test_convert_char16_sat_int16( __global int16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat(src[tid]);
}

__kernel void test_convert_char16_sat_rte_int16( __global int16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rte(src[tid]);
}

__kernel void test_convert_char16_sat_rtn_int16( __global int16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtn(src[tid]);
}

__kernel void test_convert_char16_sat_rtp_int16( __global int16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtp(src[tid]);
}

__kernel void test_convert_char16_sat_rtz_int16( __global int16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtz(src[tid]);
}

__kernel void test_convert_char16_int16( __global int16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16(src[tid]);
}

__kernel void test_convert_char16_rte_int16( __global int16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rte(src[tid]);
}

__kernel void test_convert_char16_rtn_int16( __global int16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtn(src[tid]);
}

__kernel void test_convert_char16_rtp_int16( __global int16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtp(src[tid]);
}

__kernel void test_convert_char16_rtz_int16( __global int16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtz(src[tid]);
}

__kernel void test_convert_uchar16_sat_int16( __global int16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat(src[tid]);
}

__kernel void test_convert_uchar16_sat_rte_int16( __global int16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rte(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtn_int16( __global int16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtp_int16( __global int16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtz_int16( __global int16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar16_int16( __global int16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16(src[tid]);
}

__kernel void test_convert_uchar16_rte_int16( __global int16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rte(src[tid]);
}

__kernel void test_convert_uchar16_rtn_int16( __global int16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtn(src[tid]);
}

__kernel void test_convert_uchar16_rtp_int16( __global int16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtp(src[tid]);
}

__kernel void test_convert_uchar16_rtz_int16( __global int16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtz(src[tid]);
}

__kernel void test_convert_int16_sat_int16( __global int16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat(src[tid]);
}

__kernel void test_convert_int16_sat_rte_int16( __global int16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rte(src[tid]);
}

__kernel void test_convert_int16_sat_rtn_int16( __global int16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtn(src[tid]);
}

__kernel void test_convert_int16_sat_rtp_int16( __global int16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtp(src[tid]);
}

__kernel void test_convert_int16_sat_rtz_int16( __global int16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtz(src[tid]);
}

__kernel void test_convert_int16_int16( __global int16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16(src[tid]);
}

__kernel void test_convert_int16_rte_int16( __global int16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rte(src[tid]);
}

__kernel void test_convert_int16_rtn_int16( __global int16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtn(src[tid]);
}

__kernel void test_convert_int16_rtp_int16( __global int16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtp(src[tid]);
}

__kernel void test_convert_int16_rtz_int16( __global int16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtz(src[tid]);
}

__kernel void test_convert_uint16_sat_int16( __global int16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat(src[tid]);
}

__kernel void test_convert_uint16_sat_rte_int16( __global int16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rte(src[tid]);
}

__kernel void test_convert_uint16_sat_rtn_int16( __global int16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtn(src[tid]);
}

__kernel void test_convert_uint16_sat_rtp_int16( __global int16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtp(src[tid]);
}

__kernel void test_convert_uint16_sat_rtz_int16( __global int16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtz(src[tid]);
}

__kernel void test_convert_uint16_int16( __global int16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16(src[tid]);
}

__kernel void test_convert_uint16_rte_int16( __global int16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rte(src[tid]);
}

__kernel void test_convert_uint16_rtn_int16( __global int16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtn(src[tid]);
}

__kernel void test_convert_uint16_rtp_int16( __global int16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtp(src[tid]);
}

__kernel void test_convert_uint16_rtz_int16( __global int16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtz(src[tid]);
}

__kernel void test_convert_short16_sat_int16( __global int16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat(src[tid]);
}

__kernel void test_convert_short16_sat_rte_int16( __global int16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rte(src[tid]);
}

__kernel void test_convert_short16_sat_rtn_int16( __global int16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtn(src[tid]);
}

__kernel void test_convert_short16_sat_rtp_int16( __global int16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtp(src[tid]);
}

__kernel void test_convert_short16_sat_rtz_int16( __global int16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtz(src[tid]);
}

__kernel void test_convert_short16_int16( __global int16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16(src[tid]);
}

__kernel void test_convert_short16_rte_int16( __global int16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rte(src[tid]);
}

__kernel void test_convert_short16_rtn_int16( __global int16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtn(src[tid]);
}

__kernel void test_convert_short16_rtp_int16( __global int16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtp(src[tid]);
}

__kernel void test_convert_short16_rtz_int16( __global int16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtz(src[tid]);
}

__kernel void test_convert_ushort16_sat_int16( __global int16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat(src[tid]);
}

__kernel void test_convert_ushort16_sat_rte_int16( __global int16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rte(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtn_int16( __global int16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtp_int16( __global int16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtz_int16( __global int16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort16_int16( __global int16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16(src[tid]);
}

__kernel void test_convert_ushort16_rte_int16( __global int16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rte(src[tid]);
}

__kernel void test_convert_ushort16_rtn_int16( __global int16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtn(src[tid]);
}

__kernel void test_convert_ushort16_rtp_int16( __global int16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtp(src[tid]);
}

__kernel void test_convert_ushort16_rtz_int16( __global int16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtz(src[tid]);
}

__kernel void test_convert_long16_sat_int16( __global int16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat(src[tid]);
}

__kernel void test_convert_long16_sat_rte_int16( __global int16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rte(src[tid]);
}

__kernel void test_convert_long16_sat_rtn_int16( __global int16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtn(src[tid]);
}

__kernel void test_convert_long16_sat_rtp_int16( __global int16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtp(src[tid]);
}

__kernel void test_convert_long16_sat_rtz_int16( __global int16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtz(src[tid]);
}

__kernel void test_convert_long16_int16( __global int16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16(src[tid]);
}

__kernel void test_convert_long16_rte_int16( __global int16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rte(src[tid]);
}

__kernel void test_convert_long16_rtn_int16( __global int16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtn(src[tid]);
}

__kernel void test_convert_long16_rtp_int16( __global int16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtp(src[tid]);
}

__kernel void test_convert_long16_rtz_int16( __global int16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtz(src[tid]);
}

__kernel void test_convert_ulong16_sat_int16( __global int16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat(src[tid]);
}

__kernel void test_convert_ulong16_sat_rte_int16( __global int16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rte(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtn_int16( __global int16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtp_int16( __global int16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtz_int16( __global int16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong16_int16( __global int16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16(src[tid]);
}

__kernel void test_convert_ulong16_rte_int16( __global int16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rte(src[tid]);
}

__kernel void test_convert_ulong16_rtn_int16( __global int16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtn(src[tid]);
}

__kernel void test_convert_ulong16_rtp_int16( __global int16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtp(src[tid]);
}

__kernel void test_convert_ulong16_rtz_int16( __global int16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtz(src[tid]);
}

__kernel void test_convert_float16_int16( __global int16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16(src[tid]);
}

__kernel void test_convert_float16_rte_int16( __global int16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rte(src[tid]);
}

__kernel void test_convert_float16_rtn_int16( __global int16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtn(src[tid]);
}

__kernel void test_convert_float16_rtp_int16( __global int16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtp(src[tid]);
}

__kernel void test_convert_float16_rtz_int16( __global int16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtz(src[tid]);
}

__kernel void test_convert_double16_int16( __global int16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16(src[tid]);
}

__kernel void test_convert_double16_rte_int16( __global int16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rte(src[tid]);
}

__kernel void test_convert_double16_rtn_int16( __global int16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtn(src[tid]);
}

__kernel void test_convert_double16_rtp_int16( __global int16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtp(src[tid]);
}

__kernel void test_convert_double16_rtz_int16( __global int16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtz(src[tid]);
}

__kernel void test_convert_char16_sat_uint16( __global uint16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat(src[tid]);
}

__kernel void test_convert_char16_sat_rte_uint16( __global uint16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rte(src[tid]);
}

__kernel void test_convert_char16_sat_rtn_uint16( __global uint16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtn(src[tid]);
}

__kernel void test_convert_char16_sat_rtp_uint16( __global uint16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtp(src[tid]);
}

__kernel void test_convert_char16_sat_rtz_uint16( __global uint16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtz(src[tid]);
}

__kernel void test_convert_char16_uint16( __global uint16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16(src[tid]);
}

__kernel void test_convert_char16_rte_uint16( __global uint16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rte(src[tid]);
}

__kernel void test_convert_char16_rtn_uint16( __global uint16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtn(src[tid]);
}

__kernel void test_convert_char16_rtp_uint16( __global uint16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtp(src[tid]);
}

__kernel void test_convert_char16_rtz_uint16( __global uint16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtz(src[tid]);
}

__kernel void test_convert_uchar16_sat_uint16( __global uint16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat(src[tid]);
}

__kernel void test_convert_uchar16_sat_rte_uint16( __global uint16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rte(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtn_uint16( __global uint16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtp_uint16( __global uint16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtz_uint16( __global uint16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar16_uint16( __global uint16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16(src[tid]);
}

__kernel void test_convert_uchar16_rte_uint16( __global uint16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rte(src[tid]);
}

__kernel void test_convert_uchar16_rtn_uint16( __global uint16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtn(src[tid]);
}

__kernel void test_convert_uchar16_rtp_uint16( __global uint16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtp(src[tid]);
}

__kernel void test_convert_uchar16_rtz_uint16( __global uint16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtz(src[tid]);
}

__kernel void test_convert_int16_sat_uint16( __global uint16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat(src[tid]);
}

__kernel void test_convert_int16_sat_rte_uint16( __global uint16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rte(src[tid]);
}

__kernel void test_convert_int16_sat_rtn_uint16( __global uint16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtn(src[tid]);
}

__kernel void test_convert_int16_sat_rtp_uint16( __global uint16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtp(src[tid]);
}

__kernel void test_convert_int16_sat_rtz_uint16( __global uint16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtz(src[tid]);
}

__kernel void test_convert_int16_uint16( __global uint16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16(src[tid]);
}

__kernel void test_convert_int16_rte_uint16( __global uint16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rte(src[tid]);
}

__kernel void test_convert_int16_rtn_uint16( __global uint16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtn(src[tid]);
}

__kernel void test_convert_int16_rtp_uint16( __global uint16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtp(src[tid]);
}

__kernel void test_convert_int16_rtz_uint16( __global uint16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtz(src[tid]);
}

__kernel void test_convert_uint16_sat_uint16( __global uint16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat(src[tid]);
}

__kernel void test_convert_uint16_sat_rte_uint16( __global uint16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rte(src[tid]);
}

__kernel void test_convert_uint16_sat_rtn_uint16( __global uint16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtn(src[tid]);
}

__kernel void test_convert_uint16_sat_rtp_uint16( __global uint16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtp(src[tid]);
}

__kernel void test_convert_uint16_sat_rtz_uint16( __global uint16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtz(src[tid]);
}

__kernel void test_convert_uint16_uint16( __global uint16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16(src[tid]);
}

__kernel void test_convert_uint16_rte_uint16( __global uint16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rte(src[tid]);
}

__kernel void test_convert_uint16_rtn_uint16( __global uint16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtn(src[tid]);
}

__kernel void test_convert_uint16_rtp_uint16( __global uint16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtp(src[tid]);
}

__kernel void test_convert_uint16_rtz_uint16( __global uint16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtz(src[tid]);
}

__kernel void test_convert_short16_sat_uint16( __global uint16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat(src[tid]);
}

__kernel void test_convert_short16_sat_rte_uint16( __global uint16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rte(src[tid]);
}

__kernel void test_convert_short16_sat_rtn_uint16( __global uint16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtn(src[tid]);
}

__kernel void test_convert_short16_sat_rtp_uint16( __global uint16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtp(src[tid]);
}

__kernel void test_convert_short16_sat_rtz_uint16( __global uint16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtz(src[tid]);
}

__kernel void test_convert_short16_uint16( __global uint16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16(src[tid]);
}

__kernel void test_convert_short16_rte_uint16( __global uint16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rte(src[tid]);
}

__kernel void test_convert_short16_rtn_uint16( __global uint16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtn(src[tid]);
}

__kernel void test_convert_short16_rtp_uint16( __global uint16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtp(src[tid]);
}

__kernel void test_convert_short16_rtz_uint16( __global uint16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtz(src[tid]);
}

__kernel void test_convert_ushort16_sat_uint16( __global uint16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat(src[tid]);
}

__kernel void test_convert_ushort16_sat_rte_uint16( __global uint16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rte(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtn_uint16( __global uint16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtp_uint16( __global uint16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtz_uint16( __global uint16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort16_uint16( __global uint16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16(src[tid]);
}

__kernel void test_convert_ushort16_rte_uint16( __global uint16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rte(src[tid]);
}

__kernel void test_convert_ushort16_rtn_uint16( __global uint16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtn(src[tid]);
}

__kernel void test_convert_ushort16_rtp_uint16( __global uint16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtp(src[tid]);
}

__kernel void test_convert_ushort16_rtz_uint16( __global uint16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtz(src[tid]);
}

__kernel void test_convert_long16_sat_uint16( __global uint16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat(src[tid]);
}

__kernel void test_convert_long16_sat_rte_uint16( __global uint16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rte(src[tid]);
}

__kernel void test_convert_long16_sat_rtn_uint16( __global uint16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtn(src[tid]);
}

__kernel void test_convert_long16_sat_rtp_uint16( __global uint16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtp(src[tid]);
}

__kernel void test_convert_long16_sat_rtz_uint16( __global uint16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtz(src[tid]);
}

__kernel void test_convert_long16_uint16( __global uint16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16(src[tid]);
}

__kernel void test_convert_long16_rte_uint16( __global uint16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rte(src[tid]);
}

__kernel void test_convert_long16_rtn_uint16( __global uint16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtn(src[tid]);
}

__kernel void test_convert_long16_rtp_uint16( __global uint16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtp(src[tid]);
}

__kernel void test_convert_long16_rtz_uint16( __global uint16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtz(src[tid]);
}

__kernel void test_convert_ulong16_sat_uint16( __global uint16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat(src[tid]);
}

__kernel void test_convert_ulong16_sat_rte_uint16( __global uint16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rte(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtn_uint16( __global uint16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtp_uint16( __global uint16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtz_uint16( __global uint16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong16_uint16( __global uint16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16(src[tid]);
}

__kernel void test_convert_ulong16_rte_uint16( __global uint16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rte(src[tid]);
}

__kernel void test_convert_ulong16_rtn_uint16( __global uint16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtn(src[tid]);
}

__kernel void test_convert_ulong16_rtp_uint16( __global uint16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtp(src[tid]);
}

__kernel void test_convert_ulong16_rtz_uint16( __global uint16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtz(src[tid]);
}

__kernel void test_convert_float16_uint16( __global uint16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16(src[tid]);
}

__kernel void test_convert_float16_rte_uint16( __global uint16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rte(src[tid]);
}

__kernel void test_convert_float16_rtn_uint16( __global uint16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtn(src[tid]);
}

__kernel void test_convert_float16_rtp_uint16( __global uint16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtp(src[tid]);
}

__kernel void test_convert_float16_rtz_uint16( __global uint16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtz(src[tid]);
}

__kernel void test_convert_double16_uint16( __global uint16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16(src[tid]);
}

__kernel void test_convert_double16_rte_uint16( __global uint16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rte(src[tid]);
}

__kernel void test_convert_double16_rtn_uint16( __global uint16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtn(src[tid]);
}

__kernel void test_convert_double16_rtp_uint16( __global uint16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtp(src[tid]);
}

__kernel void test_convert_double16_rtz_uint16( __global uint16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtz(src[tid]);
}

__kernel void test_convert_char16_sat_short16( __global short16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat(src[tid]);
}

__kernel void test_convert_char16_sat_rte_short16( __global short16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rte(src[tid]);
}

__kernel void test_convert_char16_sat_rtn_short16( __global short16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtn(src[tid]);
}

__kernel void test_convert_char16_sat_rtp_short16( __global short16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtp(src[tid]);
}

__kernel void test_convert_char16_sat_rtz_short16( __global short16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtz(src[tid]);
}

__kernel void test_convert_char16_short16( __global short16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16(src[tid]);
}

__kernel void test_convert_char16_rte_short16( __global short16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rte(src[tid]);
}

__kernel void test_convert_char16_rtn_short16( __global short16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtn(src[tid]);
}

__kernel void test_convert_char16_rtp_short16( __global short16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtp(src[tid]);
}

__kernel void test_convert_char16_rtz_short16( __global short16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtz(src[tid]);
}

__kernel void test_convert_uchar16_sat_short16( __global short16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat(src[tid]);
}

__kernel void test_convert_uchar16_sat_rte_short16( __global short16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rte(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtn_short16( __global short16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtp_short16( __global short16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtz_short16( __global short16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar16_short16( __global short16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16(src[tid]);
}

__kernel void test_convert_uchar16_rte_short16( __global short16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rte(src[tid]);
}

__kernel void test_convert_uchar16_rtn_short16( __global short16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtn(src[tid]);
}

__kernel void test_convert_uchar16_rtp_short16( __global short16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtp(src[tid]);
}

__kernel void test_convert_uchar16_rtz_short16( __global short16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtz(src[tid]);
}

__kernel void test_convert_int16_sat_short16( __global short16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat(src[tid]);
}

__kernel void test_convert_int16_sat_rte_short16( __global short16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rte(src[tid]);
}

__kernel void test_convert_int16_sat_rtn_short16( __global short16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtn(src[tid]);
}

__kernel void test_convert_int16_sat_rtp_short16( __global short16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtp(src[tid]);
}

__kernel void test_convert_int16_sat_rtz_short16( __global short16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtz(src[tid]);
}

__kernel void test_convert_int16_short16( __global short16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16(src[tid]);
}

__kernel void test_convert_int16_rte_short16( __global short16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rte(src[tid]);
}

__kernel void test_convert_int16_rtn_short16( __global short16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtn(src[tid]);
}

__kernel void test_convert_int16_rtp_short16( __global short16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtp(src[tid]);
}

__kernel void test_convert_int16_rtz_short16( __global short16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtz(src[tid]);
}

__kernel void test_convert_uint16_sat_short16( __global short16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat(src[tid]);
}

__kernel void test_convert_uint16_sat_rte_short16( __global short16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rte(src[tid]);
}

__kernel void test_convert_uint16_sat_rtn_short16( __global short16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtn(src[tid]);
}

__kernel void test_convert_uint16_sat_rtp_short16( __global short16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtp(src[tid]);
}

__kernel void test_convert_uint16_sat_rtz_short16( __global short16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtz(src[tid]);
}

__kernel void test_convert_uint16_short16( __global short16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16(src[tid]);
}

__kernel void test_convert_uint16_rte_short16( __global short16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rte(src[tid]);
}

__kernel void test_convert_uint16_rtn_short16( __global short16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtn(src[tid]);
}

__kernel void test_convert_uint16_rtp_short16( __global short16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtp(src[tid]);
}

__kernel void test_convert_uint16_rtz_short16( __global short16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtz(src[tid]);
}

__kernel void test_convert_short16_sat_short16( __global short16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat(src[tid]);
}

__kernel void test_convert_short16_sat_rte_short16( __global short16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rte(src[tid]);
}

__kernel void test_convert_short16_sat_rtn_short16( __global short16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtn(src[tid]);
}

__kernel void test_convert_short16_sat_rtp_short16( __global short16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtp(src[tid]);
}

__kernel void test_convert_short16_sat_rtz_short16( __global short16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtz(src[tid]);
}

__kernel void test_convert_short16_short16( __global short16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16(src[tid]);
}

__kernel void test_convert_short16_rte_short16( __global short16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rte(src[tid]);
}

__kernel void test_convert_short16_rtn_short16( __global short16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtn(src[tid]);
}

__kernel void test_convert_short16_rtp_short16( __global short16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtp(src[tid]);
}

__kernel void test_convert_short16_rtz_short16( __global short16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtz(src[tid]);
}

__kernel void test_convert_ushort16_sat_short16( __global short16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat(src[tid]);
}

__kernel void test_convert_ushort16_sat_rte_short16( __global short16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rte(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtn_short16( __global short16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtp_short16( __global short16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtz_short16( __global short16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort16_short16( __global short16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16(src[tid]);
}

__kernel void test_convert_ushort16_rte_short16( __global short16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rte(src[tid]);
}

__kernel void test_convert_ushort16_rtn_short16( __global short16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtn(src[tid]);
}

__kernel void test_convert_ushort16_rtp_short16( __global short16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtp(src[tid]);
}

__kernel void test_convert_ushort16_rtz_short16( __global short16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtz(src[tid]);
}

__kernel void test_convert_long16_sat_short16( __global short16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat(src[tid]);
}

__kernel void test_convert_long16_sat_rte_short16( __global short16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rte(src[tid]);
}

__kernel void test_convert_long16_sat_rtn_short16( __global short16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtn(src[tid]);
}

__kernel void test_convert_long16_sat_rtp_short16( __global short16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtp(src[tid]);
}

__kernel void test_convert_long16_sat_rtz_short16( __global short16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtz(src[tid]);
}

__kernel void test_convert_long16_short16( __global short16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16(src[tid]);
}

__kernel void test_convert_long16_rte_short16( __global short16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rte(src[tid]);
}

__kernel void test_convert_long16_rtn_short16( __global short16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtn(src[tid]);
}

__kernel void test_convert_long16_rtp_short16( __global short16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtp(src[tid]);
}

__kernel void test_convert_long16_rtz_short16( __global short16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtz(src[tid]);
}

__kernel void test_convert_ulong16_sat_short16( __global short16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat(src[tid]);
}

__kernel void test_convert_ulong16_sat_rte_short16( __global short16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rte(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtn_short16( __global short16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtp_short16( __global short16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtz_short16( __global short16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong16_short16( __global short16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16(src[tid]);
}

__kernel void test_convert_ulong16_rte_short16( __global short16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rte(src[tid]);
}

__kernel void test_convert_ulong16_rtn_short16( __global short16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtn(src[tid]);
}

__kernel void test_convert_ulong16_rtp_short16( __global short16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtp(src[tid]);
}

__kernel void test_convert_ulong16_rtz_short16( __global short16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtz(src[tid]);
}

__kernel void test_convert_float16_short16( __global short16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16(src[tid]);
}

__kernel void test_convert_float16_rte_short16( __global short16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rte(src[tid]);
}

__kernel void test_convert_float16_rtn_short16( __global short16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtn(src[tid]);
}

__kernel void test_convert_float16_rtp_short16( __global short16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtp(src[tid]);
}

__kernel void test_convert_float16_rtz_short16( __global short16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtz(src[tid]);
}

__kernel void test_convert_double16_short16( __global short16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16(src[tid]);
}

__kernel void test_convert_double16_rte_short16( __global short16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rte(src[tid]);
}

__kernel void test_convert_double16_rtn_short16( __global short16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtn(src[tid]);
}

__kernel void test_convert_double16_rtp_short16( __global short16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtp(src[tid]);
}

__kernel void test_convert_double16_rtz_short16( __global short16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtz(src[tid]);
}

__kernel void test_convert_char16_sat_ushort16( __global ushort16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat(src[tid]);
}

__kernel void test_convert_char16_sat_rte_ushort16( __global ushort16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rte(src[tid]);
}

__kernel void test_convert_char16_sat_rtn_ushort16( __global ushort16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtn(src[tid]);
}

__kernel void test_convert_char16_sat_rtp_ushort16( __global ushort16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtp(src[tid]);
}

__kernel void test_convert_char16_sat_rtz_ushort16( __global ushort16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtz(src[tid]);
}

__kernel void test_convert_char16_ushort16( __global ushort16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16(src[tid]);
}

__kernel void test_convert_char16_rte_ushort16( __global ushort16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rte(src[tid]);
}

__kernel void test_convert_char16_rtn_ushort16( __global ushort16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtn(src[tid]);
}

__kernel void test_convert_char16_rtp_ushort16( __global ushort16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtp(src[tid]);
}

__kernel void test_convert_char16_rtz_ushort16( __global ushort16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtz(src[tid]);
}

__kernel void test_convert_uchar16_sat_ushort16( __global ushort16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat(src[tid]);
}

__kernel void test_convert_uchar16_sat_rte_ushort16( __global ushort16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rte(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtn_ushort16( __global ushort16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtp_ushort16( __global ushort16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtz_ushort16( __global ushort16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar16_ushort16( __global ushort16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16(src[tid]);
}

__kernel void test_convert_uchar16_rte_ushort16( __global ushort16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rte(src[tid]);
}

__kernel void test_convert_uchar16_rtn_ushort16( __global ushort16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtn(src[tid]);
}

__kernel void test_convert_uchar16_rtp_ushort16( __global ushort16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtp(src[tid]);
}

__kernel void test_convert_uchar16_rtz_ushort16( __global ushort16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtz(src[tid]);
}

__kernel void test_convert_int16_sat_ushort16( __global ushort16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat(src[tid]);
}

__kernel void test_convert_int16_sat_rte_ushort16( __global ushort16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rte(src[tid]);
}

__kernel void test_convert_int16_sat_rtn_ushort16( __global ushort16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtn(src[tid]);
}

__kernel void test_convert_int16_sat_rtp_ushort16( __global ushort16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtp(src[tid]);
}

__kernel void test_convert_int16_sat_rtz_ushort16( __global ushort16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtz(src[tid]);
}

__kernel void test_convert_int16_ushort16( __global ushort16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16(src[tid]);
}

__kernel void test_convert_int16_rte_ushort16( __global ushort16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rte(src[tid]);
}

__kernel void test_convert_int16_rtn_ushort16( __global ushort16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtn(src[tid]);
}

__kernel void test_convert_int16_rtp_ushort16( __global ushort16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtp(src[tid]);
}

__kernel void test_convert_int16_rtz_ushort16( __global ushort16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtz(src[tid]);
}

__kernel void test_convert_uint16_sat_ushort16( __global ushort16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat(src[tid]);
}

__kernel void test_convert_uint16_sat_rte_ushort16( __global ushort16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rte(src[tid]);
}

__kernel void test_convert_uint16_sat_rtn_ushort16( __global ushort16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtn(src[tid]);
}

__kernel void test_convert_uint16_sat_rtp_ushort16( __global ushort16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtp(src[tid]);
}

__kernel void test_convert_uint16_sat_rtz_ushort16( __global ushort16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtz(src[tid]);
}

__kernel void test_convert_uint16_ushort16( __global ushort16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16(src[tid]);
}

__kernel void test_convert_uint16_rte_ushort16( __global ushort16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rte(src[tid]);
}

__kernel void test_convert_uint16_rtn_ushort16( __global ushort16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtn(src[tid]);
}

__kernel void test_convert_uint16_rtp_ushort16( __global ushort16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtp(src[tid]);
}

__kernel void test_convert_uint16_rtz_ushort16( __global ushort16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtz(src[tid]);
}

__kernel void test_convert_short16_sat_ushort16( __global ushort16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat(src[tid]);
}

__kernel void test_convert_short16_sat_rte_ushort16( __global ushort16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rte(src[tid]);
}

__kernel void test_convert_short16_sat_rtn_ushort16( __global ushort16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtn(src[tid]);
}

__kernel void test_convert_short16_sat_rtp_ushort16( __global ushort16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtp(src[tid]);
}

__kernel void test_convert_short16_sat_rtz_ushort16( __global ushort16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtz(src[tid]);
}

__kernel void test_convert_short16_ushort16( __global ushort16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16(src[tid]);
}

__kernel void test_convert_short16_rte_ushort16( __global ushort16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rte(src[tid]);
}

__kernel void test_convert_short16_rtn_ushort16( __global ushort16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtn(src[tid]);
}

__kernel void test_convert_short16_rtp_ushort16( __global ushort16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtp(src[tid]);
}

__kernel void test_convert_short16_rtz_ushort16( __global ushort16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtz(src[tid]);
}

__kernel void test_convert_ushort16_sat_ushort16( __global ushort16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat(src[tid]);
}

__kernel void test_convert_ushort16_sat_rte_ushort16( __global ushort16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rte(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtn_ushort16( __global ushort16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtp_ushort16( __global ushort16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtz_ushort16( __global ushort16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort16_ushort16( __global ushort16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16(src[tid]);
}

__kernel void test_convert_ushort16_rte_ushort16( __global ushort16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rte(src[tid]);
}

__kernel void test_convert_ushort16_rtn_ushort16( __global ushort16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtn(src[tid]);
}

__kernel void test_convert_ushort16_rtp_ushort16( __global ushort16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtp(src[tid]);
}

__kernel void test_convert_ushort16_rtz_ushort16( __global ushort16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtz(src[tid]);
}

__kernel void test_convert_long16_sat_ushort16( __global ushort16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat(src[tid]);
}

__kernel void test_convert_long16_sat_rte_ushort16( __global ushort16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rte(src[tid]);
}

__kernel void test_convert_long16_sat_rtn_ushort16( __global ushort16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtn(src[tid]);
}

__kernel void test_convert_long16_sat_rtp_ushort16( __global ushort16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtp(src[tid]);
}

__kernel void test_convert_long16_sat_rtz_ushort16( __global ushort16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtz(src[tid]);
}

__kernel void test_convert_long16_ushort16( __global ushort16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16(src[tid]);
}

__kernel void test_convert_long16_rte_ushort16( __global ushort16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rte(src[tid]);
}

__kernel void test_convert_long16_rtn_ushort16( __global ushort16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtn(src[tid]);
}

__kernel void test_convert_long16_rtp_ushort16( __global ushort16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtp(src[tid]);
}

__kernel void test_convert_long16_rtz_ushort16( __global ushort16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtz(src[tid]);
}

__kernel void test_convert_ulong16_sat_ushort16( __global ushort16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat(src[tid]);
}

__kernel void test_convert_ulong16_sat_rte_ushort16( __global ushort16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rte(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtn_ushort16( __global ushort16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtp_ushort16( __global ushort16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtz_ushort16( __global ushort16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong16_ushort16( __global ushort16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16(src[tid]);
}

__kernel void test_convert_ulong16_rte_ushort16( __global ushort16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rte(src[tid]);
}

__kernel void test_convert_ulong16_rtn_ushort16( __global ushort16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtn(src[tid]);
}

__kernel void test_convert_ulong16_rtp_ushort16( __global ushort16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtp(src[tid]);
}

__kernel void test_convert_ulong16_rtz_ushort16( __global ushort16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtz(src[tid]);
}

__kernel void test_convert_float16_ushort16( __global ushort16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16(src[tid]);
}

__kernel void test_convert_float16_rte_ushort16( __global ushort16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rte(src[tid]);
}

__kernel void test_convert_float16_rtn_ushort16( __global ushort16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtn(src[tid]);
}

__kernel void test_convert_float16_rtp_ushort16( __global ushort16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtp(src[tid]);
}

__kernel void test_convert_float16_rtz_ushort16( __global ushort16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtz(src[tid]);
}

__kernel void test_convert_double16_ushort16( __global ushort16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16(src[tid]);
}

__kernel void test_convert_double16_rte_ushort16( __global ushort16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rte(src[tid]);
}

__kernel void test_convert_double16_rtn_ushort16( __global ushort16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtn(src[tid]);
}

__kernel void test_convert_double16_rtp_ushort16( __global ushort16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtp(src[tid]);
}

__kernel void test_convert_double16_rtz_ushort16( __global ushort16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtz(src[tid]);
}

__kernel void test_convert_char16_sat_long16( __global long16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat(src[tid]);
}

__kernel void test_convert_char16_sat_rte_long16( __global long16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rte(src[tid]);
}

__kernel void test_convert_char16_sat_rtn_long16( __global long16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtn(src[tid]);
}

__kernel void test_convert_char16_sat_rtp_long16( __global long16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtp(src[tid]);
}

__kernel void test_convert_char16_sat_rtz_long16( __global long16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtz(src[tid]);
}

__kernel void test_convert_char16_long16( __global long16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16(src[tid]);
}

__kernel void test_convert_char16_rte_long16( __global long16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rte(src[tid]);
}

__kernel void test_convert_char16_rtn_long16( __global long16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtn(src[tid]);
}

__kernel void test_convert_char16_rtp_long16( __global long16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtp(src[tid]);
}

__kernel void test_convert_char16_rtz_long16( __global long16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtz(src[tid]);
}

__kernel void test_convert_uchar16_sat_long16( __global long16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat(src[tid]);
}

__kernel void test_convert_uchar16_sat_rte_long16( __global long16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rte(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtn_long16( __global long16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtp_long16( __global long16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtz_long16( __global long16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar16_long16( __global long16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16(src[tid]);
}

__kernel void test_convert_uchar16_rte_long16( __global long16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rte(src[tid]);
}

__kernel void test_convert_uchar16_rtn_long16( __global long16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtn(src[tid]);
}

__kernel void test_convert_uchar16_rtp_long16( __global long16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtp(src[tid]);
}

__kernel void test_convert_uchar16_rtz_long16( __global long16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtz(src[tid]);
}

__kernel void test_convert_int16_sat_long16( __global long16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat(src[tid]);
}

__kernel void test_convert_int16_sat_rte_long16( __global long16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rte(src[tid]);
}

__kernel void test_convert_int16_sat_rtn_long16( __global long16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtn(src[tid]);
}

__kernel void test_convert_int16_sat_rtp_long16( __global long16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtp(src[tid]);
}

__kernel void test_convert_int16_sat_rtz_long16( __global long16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtz(src[tid]);
}

__kernel void test_convert_int16_long16( __global long16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16(src[tid]);
}

__kernel void test_convert_int16_rte_long16( __global long16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rte(src[tid]);
}

__kernel void test_convert_int16_rtn_long16( __global long16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtn(src[tid]);
}

__kernel void test_convert_int16_rtp_long16( __global long16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtp(src[tid]);
}

__kernel void test_convert_int16_rtz_long16( __global long16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtz(src[tid]);
}

__kernel void test_convert_uint16_sat_long16( __global long16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat(src[tid]);
}

__kernel void test_convert_uint16_sat_rte_long16( __global long16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rte(src[tid]);
}

__kernel void test_convert_uint16_sat_rtn_long16( __global long16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtn(src[tid]);
}

__kernel void test_convert_uint16_sat_rtp_long16( __global long16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtp(src[tid]);
}

__kernel void test_convert_uint16_sat_rtz_long16( __global long16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtz(src[tid]);
}

__kernel void test_convert_uint16_long16( __global long16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16(src[tid]);
}

__kernel void test_convert_uint16_rte_long16( __global long16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rte(src[tid]);
}

__kernel void test_convert_uint16_rtn_long16( __global long16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtn(src[tid]);
}

__kernel void test_convert_uint16_rtp_long16( __global long16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtp(src[tid]);
}

__kernel void test_convert_uint16_rtz_long16( __global long16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtz(src[tid]);
}

__kernel void test_convert_short16_sat_long16( __global long16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat(src[tid]);
}

__kernel void test_convert_short16_sat_rte_long16( __global long16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rte(src[tid]);
}

__kernel void test_convert_short16_sat_rtn_long16( __global long16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtn(src[tid]);
}

__kernel void test_convert_short16_sat_rtp_long16( __global long16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtp(src[tid]);
}

__kernel void test_convert_short16_sat_rtz_long16( __global long16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtz(src[tid]);
}

__kernel void test_convert_short16_long16( __global long16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16(src[tid]);
}

__kernel void test_convert_short16_rte_long16( __global long16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rte(src[tid]);
}

__kernel void test_convert_short16_rtn_long16( __global long16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtn(src[tid]);
}

__kernel void test_convert_short16_rtp_long16( __global long16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtp(src[tid]);
}

__kernel void test_convert_short16_rtz_long16( __global long16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtz(src[tid]);
}

__kernel void test_convert_ushort16_sat_long16( __global long16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat(src[tid]);
}

__kernel void test_convert_ushort16_sat_rte_long16( __global long16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rte(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtn_long16( __global long16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtp_long16( __global long16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtz_long16( __global long16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort16_long16( __global long16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16(src[tid]);
}

__kernel void test_convert_ushort16_rte_long16( __global long16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rte(src[tid]);
}

__kernel void test_convert_ushort16_rtn_long16( __global long16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtn(src[tid]);
}

__kernel void test_convert_ushort16_rtp_long16( __global long16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtp(src[tid]);
}

__kernel void test_convert_ushort16_rtz_long16( __global long16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtz(src[tid]);
}

__kernel void test_convert_long16_sat_long16( __global long16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat(src[tid]);
}

__kernel void test_convert_long16_sat_rte_long16( __global long16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rte(src[tid]);
}

__kernel void test_convert_long16_sat_rtn_long16( __global long16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtn(src[tid]);
}

__kernel void test_convert_long16_sat_rtp_long16( __global long16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtp(src[tid]);
}

__kernel void test_convert_long16_sat_rtz_long16( __global long16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtz(src[tid]);
}

__kernel void test_convert_long16_long16( __global long16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16(src[tid]);
}

__kernel void test_convert_long16_rte_long16( __global long16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rte(src[tid]);
}

__kernel void test_convert_long16_rtn_long16( __global long16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtn(src[tid]);
}

__kernel void test_convert_long16_rtp_long16( __global long16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtp(src[tid]);
}

__kernel void test_convert_long16_rtz_long16( __global long16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtz(src[tid]);
}

__kernel void test_convert_ulong16_sat_long16( __global long16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat(src[tid]);
}

__kernel void test_convert_ulong16_sat_rte_long16( __global long16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rte(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtn_long16( __global long16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtp_long16( __global long16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtz_long16( __global long16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong16_long16( __global long16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16(src[tid]);
}

__kernel void test_convert_ulong16_rte_long16( __global long16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rte(src[tid]);
}

__kernel void test_convert_ulong16_rtn_long16( __global long16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtn(src[tid]);
}

__kernel void test_convert_ulong16_rtp_long16( __global long16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtp(src[tid]);
}

__kernel void test_convert_ulong16_rtz_long16( __global long16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtz(src[tid]);
}

__kernel void test_convert_float16_long16( __global long16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16(src[tid]);
}

__kernel void test_convert_float16_rte_long16( __global long16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rte(src[tid]);
}

__kernel void test_convert_float16_rtn_long16( __global long16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtn(src[tid]);
}

__kernel void test_convert_float16_rtp_long16( __global long16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtp(src[tid]);
}

__kernel void test_convert_float16_rtz_long16( __global long16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtz(src[tid]);
}

__kernel void test_convert_double16_long16( __global long16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16(src[tid]);
}

__kernel void test_convert_double16_rte_long16( __global long16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rte(src[tid]);
}

__kernel void test_convert_double16_rtn_long16( __global long16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtn(src[tid]);
}

__kernel void test_convert_double16_rtp_long16( __global long16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtp(src[tid]);
}

__kernel void test_convert_double16_rtz_long16( __global long16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtz(src[tid]);
}

__kernel void test_convert_char16_sat_ulong16( __global ulong16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat(src[tid]);
}

__kernel void test_convert_char16_sat_rte_ulong16( __global ulong16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rte(src[tid]);
}

__kernel void test_convert_char16_sat_rtn_ulong16( __global ulong16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtn(src[tid]);
}

__kernel void test_convert_char16_sat_rtp_ulong16( __global ulong16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtp(src[tid]);
}

__kernel void test_convert_char16_sat_rtz_ulong16( __global ulong16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtz(src[tid]);
}

__kernel void test_convert_char16_ulong16( __global ulong16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16(src[tid]);
}

__kernel void test_convert_char16_rte_ulong16( __global ulong16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rte(src[tid]);
}

__kernel void test_convert_char16_rtn_ulong16( __global ulong16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtn(src[tid]);
}

__kernel void test_convert_char16_rtp_ulong16( __global ulong16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtp(src[tid]);
}

__kernel void test_convert_char16_rtz_ulong16( __global ulong16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtz(src[tid]);
}

__kernel void test_convert_uchar16_sat_ulong16( __global ulong16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat(src[tid]);
}

__kernel void test_convert_uchar16_sat_rte_ulong16( __global ulong16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rte(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtn_ulong16( __global ulong16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtp_ulong16( __global ulong16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtz_ulong16( __global ulong16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar16_ulong16( __global ulong16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16(src[tid]);
}

__kernel void test_convert_uchar16_rte_ulong16( __global ulong16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rte(src[tid]);
}

__kernel void test_convert_uchar16_rtn_ulong16( __global ulong16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtn(src[tid]);
}

__kernel void test_convert_uchar16_rtp_ulong16( __global ulong16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtp(src[tid]);
}

__kernel void test_convert_uchar16_rtz_ulong16( __global ulong16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtz(src[tid]);
}

__kernel void test_convert_int16_sat_ulong16( __global ulong16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat(src[tid]);
}

__kernel void test_convert_int16_sat_rte_ulong16( __global ulong16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rte(src[tid]);
}

__kernel void test_convert_int16_sat_rtn_ulong16( __global ulong16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtn(src[tid]);
}

__kernel void test_convert_int16_sat_rtp_ulong16( __global ulong16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtp(src[tid]);
}

__kernel void test_convert_int16_sat_rtz_ulong16( __global ulong16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtz(src[tid]);
}

__kernel void test_convert_int16_ulong16( __global ulong16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16(src[tid]);
}

__kernel void test_convert_int16_rte_ulong16( __global ulong16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rte(src[tid]);
}

__kernel void test_convert_int16_rtn_ulong16( __global ulong16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtn(src[tid]);
}

__kernel void test_convert_int16_rtp_ulong16( __global ulong16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtp(src[tid]);
}

__kernel void test_convert_int16_rtz_ulong16( __global ulong16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtz(src[tid]);
}

__kernel void test_convert_uint16_sat_ulong16( __global ulong16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat(src[tid]);
}

__kernel void test_convert_uint16_sat_rte_ulong16( __global ulong16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rte(src[tid]);
}

__kernel void test_convert_uint16_sat_rtn_ulong16( __global ulong16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtn(src[tid]);
}

__kernel void test_convert_uint16_sat_rtp_ulong16( __global ulong16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtp(src[tid]);
}

__kernel void test_convert_uint16_sat_rtz_ulong16( __global ulong16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtz(src[tid]);
}

__kernel void test_convert_uint16_ulong16( __global ulong16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16(src[tid]);
}

__kernel void test_convert_uint16_rte_ulong16( __global ulong16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rte(src[tid]);
}

__kernel void test_convert_uint16_rtn_ulong16( __global ulong16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtn(src[tid]);
}

__kernel void test_convert_uint16_rtp_ulong16( __global ulong16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtp(src[tid]);
}

__kernel void test_convert_uint16_rtz_ulong16( __global ulong16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtz(src[tid]);
}

__kernel void test_convert_short16_sat_ulong16( __global ulong16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat(src[tid]);
}

__kernel void test_convert_short16_sat_rte_ulong16( __global ulong16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rte(src[tid]);
}

__kernel void test_convert_short16_sat_rtn_ulong16( __global ulong16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtn(src[tid]);
}

__kernel void test_convert_short16_sat_rtp_ulong16( __global ulong16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtp(src[tid]);
}

__kernel void test_convert_short16_sat_rtz_ulong16( __global ulong16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtz(src[tid]);
}

__kernel void test_convert_short16_ulong16( __global ulong16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16(src[tid]);
}

__kernel void test_convert_short16_rte_ulong16( __global ulong16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rte(src[tid]);
}

__kernel void test_convert_short16_rtn_ulong16( __global ulong16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtn(src[tid]);
}

__kernel void test_convert_short16_rtp_ulong16( __global ulong16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtp(src[tid]);
}

__kernel void test_convert_short16_rtz_ulong16( __global ulong16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtz(src[tid]);
}

__kernel void test_convert_ushort16_sat_ulong16( __global ulong16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat(src[tid]);
}

__kernel void test_convert_ushort16_sat_rte_ulong16( __global ulong16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rte(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtn_ulong16( __global ulong16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtp_ulong16( __global ulong16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtz_ulong16( __global ulong16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort16_ulong16( __global ulong16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16(src[tid]);
}

__kernel void test_convert_ushort16_rte_ulong16( __global ulong16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rte(src[tid]);
}

__kernel void test_convert_ushort16_rtn_ulong16( __global ulong16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtn(src[tid]);
}

__kernel void test_convert_ushort16_rtp_ulong16( __global ulong16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtp(src[tid]);
}

__kernel void test_convert_ushort16_rtz_ulong16( __global ulong16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtz(src[tid]);
}

__kernel void test_convert_long16_sat_ulong16( __global ulong16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat(src[tid]);
}

__kernel void test_convert_long16_sat_rte_ulong16( __global ulong16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rte(src[tid]);
}

__kernel void test_convert_long16_sat_rtn_ulong16( __global ulong16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtn(src[tid]);
}

__kernel void test_convert_long16_sat_rtp_ulong16( __global ulong16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtp(src[tid]);
}

__kernel void test_convert_long16_sat_rtz_ulong16( __global ulong16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtz(src[tid]);
}

__kernel void test_convert_long16_ulong16( __global ulong16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16(src[tid]);
}

__kernel void test_convert_long16_rte_ulong16( __global ulong16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rte(src[tid]);
}

__kernel void test_convert_long16_rtn_ulong16( __global ulong16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtn(src[tid]);
}

__kernel void test_convert_long16_rtp_ulong16( __global ulong16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtp(src[tid]);
}

__kernel void test_convert_long16_rtz_ulong16( __global ulong16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtz(src[tid]);
}

__kernel void test_convert_ulong16_sat_ulong16( __global ulong16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat(src[tid]);
}

__kernel void test_convert_ulong16_sat_rte_ulong16( __global ulong16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rte(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtn_ulong16( __global ulong16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtp_ulong16( __global ulong16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtz_ulong16( __global ulong16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong16_ulong16( __global ulong16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16(src[tid]);
}

__kernel void test_convert_ulong16_rte_ulong16( __global ulong16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rte(src[tid]);
}

__kernel void test_convert_ulong16_rtn_ulong16( __global ulong16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtn(src[tid]);
}

__kernel void test_convert_ulong16_rtp_ulong16( __global ulong16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtp(src[tid]);
}

__kernel void test_convert_ulong16_rtz_ulong16( __global ulong16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtz(src[tid]);
}

__kernel void test_convert_float16_ulong16( __global ulong16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16(src[tid]);
}

__kernel void test_convert_float16_rte_ulong16( __global ulong16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rte(src[tid]);
}

__kernel void test_convert_float16_rtn_ulong16( __global ulong16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtn(src[tid]);
}

__kernel void test_convert_float16_rtp_ulong16( __global ulong16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtp(src[tid]);
}

__kernel void test_convert_float16_rtz_ulong16( __global ulong16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtz(src[tid]);
}

__kernel void test_convert_double16_ulong16( __global ulong16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16(src[tid]);
}

__kernel void test_convert_double16_rte_ulong16( __global ulong16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rte(src[tid]);
}

__kernel void test_convert_double16_rtn_ulong16( __global ulong16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtn(src[tid]);
}

__kernel void test_convert_double16_rtp_ulong16( __global ulong16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtp(src[tid]);
}

__kernel void test_convert_double16_rtz_ulong16( __global ulong16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtz(src[tid]);
}

__kernel void test_convert_char16_sat_float16( __global float16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat(src[tid]);
}

__kernel void test_convert_char16_sat_rte_float16( __global float16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rte(src[tid]);
}

__kernel void test_convert_char16_sat_rtn_float16( __global float16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtn(src[tid]);
}

__kernel void test_convert_char16_sat_rtp_float16( __global float16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtp(src[tid]);
}

__kernel void test_convert_char16_sat_rtz_float16( __global float16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtz(src[tid]);
}

__kernel void test_convert_char16_float16( __global float16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16(src[tid]);
}

__kernel void test_convert_char16_rte_float16( __global float16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rte(src[tid]);
}

__kernel void test_convert_char16_rtn_float16( __global float16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtn(src[tid]);
}

__kernel void test_convert_char16_rtp_float16( __global float16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtp(src[tid]);
}

__kernel void test_convert_char16_rtz_float16( __global float16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtz(src[tid]);
}

__kernel void test_convert_uchar16_sat_float16( __global float16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat(src[tid]);
}

__kernel void test_convert_uchar16_sat_rte_float16( __global float16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rte(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtn_float16( __global float16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtp_float16( __global float16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtz_float16( __global float16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar16_float16( __global float16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16(src[tid]);
}

__kernel void test_convert_uchar16_rte_float16( __global float16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rte(src[tid]);
}

__kernel void test_convert_uchar16_rtn_float16( __global float16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtn(src[tid]);
}

__kernel void test_convert_uchar16_rtp_float16( __global float16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtp(src[tid]);
}

__kernel void test_convert_uchar16_rtz_float16( __global float16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtz(src[tid]);
}

__kernel void test_convert_int16_sat_float16( __global float16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat(src[tid]);
}

__kernel void test_convert_int16_sat_rte_float16( __global float16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rte(src[tid]);
}

__kernel void test_convert_int16_sat_rtn_float16( __global float16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtn(src[tid]);
}

__kernel void test_convert_int16_sat_rtp_float16( __global float16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtp(src[tid]);
}

__kernel void test_convert_int16_sat_rtz_float16( __global float16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtz(src[tid]);
}

__kernel void test_convert_int16_float16( __global float16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16(src[tid]);
}

__kernel void test_convert_int16_rte_float16( __global float16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rte(src[tid]);
}

__kernel void test_convert_int16_rtn_float16( __global float16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtn(src[tid]);
}

__kernel void test_convert_int16_rtp_float16( __global float16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtp(src[tid]);
}

__kernel void test_convert_int16_rtz_float16( __global float16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtz(src[tid]);
}

__kernel void test_convert_uint16_sat_float16( __global float16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat(src[tid]);
}

__kernel void test_convert_uint16_sat_rte_float16( __global float16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rte(src[tid]);
}

__kernel void test_convert_uint16_sat_rtn_float16( __global float16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtn(src[tid]);
}

__kernel void test_convert_uint16_sat_rtp_float16( __global float16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtp(src[tid]);
}

__kernel void test_convert_uint16_sat_rtz_float16( __global float16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtz(src[tid]);
}

__kernel void test_convert_uint16_float16( __global float16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16(src[tid]);
}

__kernel void test_convert_uint16_rte_float16( __global float16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rte(src[tid]);
}

__kernel void test_convert_uint16_rtn_float16( __global float16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtn(src[tid]);
}

__kernel void test_convert_uint16_rtp_float16( __global float16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtp(src[tid]);
}

__kernel void test_convert_uint16_rtz_float16( __global float16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtz(src[tid]);
}

__kernel void test_convert_short16_sat_float16( __global float16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat(src[tid]);
}

__kernel void test_convert_short16_sat_rte_float16( __global float16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rte(src[tid]);
}

__kernel void test_convert_short16_sat_rtn_float16( __global float16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtn(src[tid]);
}

__kernel void test_convert_short16_sat_rtp_float16( __global float16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtp(src[tid]);
}

__kernel void test_convert_short16_sat_rtz_float16( __global float16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtz(src[tid]);
}

__kernel void test_convert_short16_float16( __global float16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16(src[tid]);
}

__kernel void test_convert_short16_rte_float16( __global float16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rte(src[tid]);
}

__kernel void test_convert_short16_rtn_float16( __global float16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtn(src[tid]);
}

__kernel void test_convert_short16_rtp_float16( __global float16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtp(src[tid]);
}

__kernel void test_convert_short16_rtz_float16( __global float16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtz(src[tid]);
}

__kernel void test_convert_ushort16_sat_float16( __global float16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat(src[tid]);
}

__kernel void test_convert_ushort16_sat_rte_float16( __global float16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rte(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtn_float16( __global float16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtp_float16( __global float16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtz_float16( __global float16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort16_float16( __global float16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16(src[tid]);
}

__kernel void test_convert_ushort16_rte_float16( __global float16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rte(src[tid]);
}

__kernel void test_convert_ushort16_rtn_float16( __global float16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtn(src[tid]);
}

__kernel void test_convert_ushort16_rtp_float16( __global float16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtp(src[tid]);
}

__kernel void test_convert_ushort16_rtz_float16( __global float16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtz(src[tid]);
}

__kernel void test_convert_long16_sat_float16( __global float16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat(src[tid]);
}

__kernel void test_convert_long16_sat_rte_float16( __global float16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rte(src[tid]);
}

__kernel void test_convert_long16_sat_rtn_float16( __global float16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtn(src[tid]);
}

__kernel void test_convert_long16_sat_rtp_float16( __global float16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtp(src[tid]);
}

__kernel void test_convert_long16_sat_rtz_float16( __global float16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtz(src[tid]);
}

__kernel void test_convert_long16_float16( __global float16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16(src[tid]);
}

__kernel void test_convert_long16_rte_float16( __global float16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rte(src[tid]);
}

__kernel void test_convert_long16_rtn_float16( __global float16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtn(src[tid]);
}

__kernel void test_convert_long16_rtp_float16( __global float16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtp(src[tid]);
}

__kernel void test_convert_long16_rtz_float16( __global float16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtz(src[tid]);
}

__kernel void test_convert_ulong16_sat_float16( __global float16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat(src[tid]);
}

__kernel void test_convert_ulong16_sat_rte_float16( __global float16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rte(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtn_float16( __global float16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtp_float16( __global float16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtz_float16( __global float16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong16_float16( __global float16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16(src[tid]);
}

__kernel void test_convert_ulong16_rte_float16( __global float16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rte(src[tid]);
}

__kernel void test_convert_ulong16_rtn_float16( __global float16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtn(src[tid]);
}

__kernel void test_convert_ulong16_rtp_float16( __global float16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtp(src[tid]);
}

__kernel void test_convert_ulong16_rtz_float16( __global float16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtz(src[tid]);
}

__kernel void test_convert_float16_float16( __global float16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16(src[tid]);
}

__kernel void test_convert_float16_rte_float16( __global float16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rte(src[tid]);
}

__kernel void test_convert_float16_rtn_float16( __global float16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtn(src[tid]);
}

__kernel void test_convert_float16_rtp_float16( __global float16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtp(src[tid]);
}

__kernel void test_convert_float16_rtz_float16( __global float16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtz(src[tid]);
}

__kernel void test_convert_double16_float16( __global float16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16(src[tid]);
}

__kernel void test_convert_double16_rte_float16( __global float16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rte(src[tid]);
}

__kernel void test_convert_double16_rtn_float16( __global float16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtn(src[tid]);
}

__kernel void test_convert_double16_rtp_float16( __global float16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtp(src[tid]);
}

__kernel void test_convert_double16_rtz_float16( __global float16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtz(src[tid]);
}

__kernel void test_convert_char16_sat_double16( __global double16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat(src[tid]);
}

__kernel void test_convert_char16_sat_rte_double16( __global double16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rte(src[tid]);
}

__kernel void test_convert_char16_sat_rtn_double16( __global double16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtn(src[tid]);
}

__kernel void test_convert_char16_sat_rtp_double16( __global double16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtp(src[tid]);
}

__kernel void test_convert_char16_sat_rtz_double16( __global double16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_sat_rtz(src[tid]);
}

__kernel void test_convert_char16_double16( __global double16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16(src[tid]);
}

__kernel void test_convert_char16_rte_double16( __global double16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rte(src[tid]);
}

__kernel void test_convert_char16_rtn_double16( __global double16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtn(src[tid]);
}

__kernel void test_convert_char16_rtp_double16( __global double16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtp(src[tid]);
}

__kernel void test_convert_char16_rtz_double16( __global double16 *src, __global char16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char16_rtz(src[tid]);
}

__kernel void test_convert_uchar16_sat_double16( __global double16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat(src[tid]);
}

__kernel void test_convert_uchar16_sat_rte_double16( __global double16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rte(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtn_double16( __global double16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtp_double16( __global double16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar16_sat_rtz_double16( __global double16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar16_double16( __global double16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16(src[tid]);
}

__kernel void test_convert_uchar16_rte_double16( __global double16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rte(src[tid]);
}

__kernel void test_convert_uchar16_rtn_double16( __global double16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtn(src[tid]);
}

__kernel void test_convert_uchar16_rtp_double16( __global double16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtp(src[tid]);
}

__kernel void test_convert_uchar16_rtz_double16( __global double16 *src, __global uchar16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar16_rtz(src[tid]);
}

__kernel void test_convert_int16_sat_double16( __global double16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat(src[tid]);
}

__kernel void test_convert_int16_sat_rte_double16( __global double16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rte(src[tid]);
}

__kernel void test_convert_int16_sat_rtn_double16( __global double16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtn(src[tid]);
}

__kernel void test_convert_int16_sat_rtp_double16( __global double16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtp(src[tid]);
}

__kernel void test_convert_int16_sat_rtz_double16( __global double16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_sat_rtz(src[tid]);
}

__kernel void test_convert_int16_double16( __global double16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16(src[tid]);
}

__kernel void test_convert_int16_rte_double16( __global double16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rte(src[tid]);
}

__kernel void test_convert_int16_rtn_double16( __global double16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtn(src[tid]);
}

__kernel void test_convert_int16_rtp_double16( __global double16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtp(src[tid]);
}

__kernel void test_convert_int16_rtz_double16( __global double16 *src, __global int16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int16_rtz(src[tid]);
}

__kernel void test_convert_uint16_sat_double16( __global double16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat(src[tid]);
}

__kernel void test_convert_uint16_sat_rte_double16( __global double16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rte(src[tid]);
}

__kernel void test_convert_uint16_sat_rtn_double16( __global double16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtn(src[tid]);
}

__kernel void test_convert_uint16_sat_rtp_double16( __global double16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtp(src[tid]);
}

__kernel void test_convert_uint16_sat_rtz_double16( __global double16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_sat_rtz(src[tid]);
}

__kernel void test_convert_uint16_double16( __global double16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16(src[tid]);
}

__kernel void test_convert_uint16_rte_double16( __global double16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rte(src[tid]);
}

__kernel void test_convert_uint16_rtn_double16( __global double16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtn(src[tid]);
}

__kernel void test_convert_uint16_rtp_double16( __global double16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtp(src[tid]);
}

__kernel void test_convert_uint16_rtz_double16( __global double16 *src, __global uint16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint16_rtz(src[tid]);
}

__kernel void test_convert_short16_sat_double16( __global double16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat(src[tid]);
}

__kernel void test_convert_short16_sat_rte_double16( __global double16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rte(src[tid]);
}

__kernel void test_convert_short16_sat_rtn_double16( __global double16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtn(src[tid]);
}

__kernel void test_convert_short16_sat_rtp_double16( __global double16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtp(src[tid]);
}

__kernel void test_convert_short16_sat_rtz_double16( __global double16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_sat_rtz(src[tid]);
}

__kernel void test_convert_short16_double16( __global double16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16(src[tid]);
}

__kernel void test_convert_short16_rte_double16( __global double16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rte(src[tid]);
}

__kernel void test_convert_short16_rtn_double16( __global double16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtn(src[tid]);
}

__kernel void test_convert_short16_rtp_double16( __global double16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtp(src[tid]);
}

__kernel void test_convert_short16_rtz_double16( __global double16 *src, __global short16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short16_rtz(src[tid]);
}

__kernel void test_convert_ushort16_sat_double16( __global double16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat(src[tid]);
}

__kernel void test_convert_ushort16_sat_rte_double16( __global double16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rte(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtn_double16( __global double16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtp_double16( __global double16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort16_sat_rtz_double16( __global double16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort16_double16( __global double16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16(src[tid]);
}

__kernel void test_convert_ushort16_rte_double16( __global double16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rte(src[tid]);
}

__kernel void test_convert_ushort16_rtn_double16( __global double16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtn(src[tid]);
}

__kernel void test_convert_ushort16_rtp_double16( __global double16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtp(src[tid]);
}

__kernel void test_convert_ushort16_rtz_double16( __global double16 *src, __global ushort16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort16_rtz(src[tid]);
}

__kernel void test_convert_long16_sat_double16( __global double16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat(src[tid]);
}

__kernel void test_convert_long16_sat_rte_double16( __global double16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rte(src[tid]);
}

__kernel void test_convert_long16_sat_rtn_double16( __global double16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtn(src[tid]);
}

__kernel void test_convert_long16_sat_rtp_double16( __global double16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtp(src[tid]);
}

__kernel void test_convert_long16_sat_rtz_double16( __global double16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_sat_rtz(src[tid]);
}

__kernel void test_convert_long16_double16( __global double16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16(src[tid]);
}

__kernel void test_convert_long16_rte_double16( __global double16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rte(src[tid]);
}

__kernel void test_convert_long16_rtn_double16( __global double16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtn(src[tid]);
}

__kernel void test_convert_long16_rtp_double16( __global double16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtp(src[tid]);
}

__kernel void test_convert_long16_rtz_double16( __global double16 *src, __global long16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long16_rtz(src[tid]);
}

__kernel void test_convert_ulong16_sat_double16( __global double16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat(src[tid]);
}

__kernel void test_convert_ulong16_sat_rte_double16( __global double16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rte(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtn_double16( __global double16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtp_double16( __global double16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong16_sat_rtz_double16( __global double16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong16_double16( __global double16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16(src[tid]);
}

__kernel void test_convert_ulong16_rte_double16( __global double16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rte(src[tid]);
}

__kernel void test_convert_ulong16_rtn_double16( __global double16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtn(src[tid]);
}

__kernel void test_convert_ulong16_rtp_double16( __global double16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtp(src[tid]);
}

__kernel void test_convert_ulong16_rtz_double16( __global double16 *src, __global ulong16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong16_rtz(src[tid]);
}

__kernel void test_convert_float16_double16( __global double16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16(src[tid]);
}

__kernel void test_convert_float16_rte_double16( __global double16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rte(src[tid]);
}

__kernel void test_convert_float16_rtn_double16( __global double16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtn(src[tid]);
}

__kernel void test_convert_float16_rtp_double16( __global double16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtp(src[tid]);
}

__kernel void test_convert_float16_rtz_double16( __global double16 *src, __global float16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float16_rtz(src[tid]);
}

__kernel void test_convert_double16_double16( __global double16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16(src[tid]);
}

__kernel void test_convert_double16_rte_double16( __global double16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rte(src[tid]);
}

__kernel void test_convert_double16_rtn_double16( __global double16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtn(src[tid]);
}

__kernel void test_convert_double16_rtp_double16( __global double16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtp(src[tid]);
}

__kernel void test_convert_double16_rtz_double16( __global double16 *src, __global double16 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_double16_rtz(src[tid]);
}


