__kernel void test_convert_char8_sat_char8( __global char8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat(src[tid]);
}

__kernel void test_convert_char8_sat_rte_char8( __global char8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rte(src[tid]);
}

__kernel void test_convert_char8_sat_rtn_char8( __global char8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtn(src[tid]);
}

__kernel void test_convert_char8_sat_rtp_char8( __global char8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtp(src[tid]);
}

__kernel void test_convert_char8_sat_rtz_char8( __global char8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_sat_rtz(src[tid]);
}

__kernel void test_convert_char8_char8( __global char8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8(src[tid]);
}

__kernel void test_convert_char8_rte_char8( __global char8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rte(src[tid]);
}

__kernel void test_convert_char8_rtn_char8( __global char8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtn(src[tid]);
}

__kernel void test_convert_char8_rtp_char8( __global char8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtp(src[tid]);
}

__kernel void test_convert_char8_rtz_char8( __global char8 *src, __global char8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_char8_rtz(src[tid]);
}

__kernel void test_convert_uchar8_sat_char8( __global char8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat(src[tid]);
}

__kernel void test_convert_uchar8_sat_rte_char8( __global char8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rte(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtn_char8( __global char8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtn(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtp_char8( __global char8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtp(src[tid]);
}

__kernel void test_convert_uchar8_sat_rtz_char8( __global char8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_sat_rtz(src[tid]);
}

__kernel void test_convert_uchar8_char8( __global char8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8(src[tid]);
}

__kernel void test_convert_uchar8_rte_char8( __global char8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rte(src[tid]);
}

__kernel void test_convert_uchar8_rtn_char8( __global char8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtn(src[tid]);
}

__kernel void test_convert_uchar8_rtp_char8( __global char8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtp(src[tid]);
}

__kernel void test_convert_uchar8_rtz_char8( __global char8 *src, __global uchar8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uchar8_rtz(src[tid]);
}

__kernel void test_convert_int8_sat_char8( __global char8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat(src[tid]);
}

__kernel void test_convert_int8_sat_rte_char8( __global char8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rte(src[tid]);
}

__kernel void test_convert_int8_sat_rtn_char8( __global char8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtn(src[tid]);
}

__kernel void test_convert_int8_sat_rtp_char8( __global char8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtp(src[tid]);
}

__kernel void test_convert_int8_sat_rtz_char8( __global char8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_sat_rtz(src[tid]);
}

__kernel void test_convert_int8_char8( __global char8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8(src[tid]);
}

__kernel void test_convert_int8_rte_char8( __global char8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rte(src[tid]);
}

__kernel void test_convert_int8_rtn_char8( __global char8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtn(src[tid]);
}

__kernel void test_convert_int8_rtp_char8( __global char8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtp(src[tid]);
}

__kernel void test_convert_int8_rtz_char8( __global char8 *src, __global int8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_int8_rtz(src[tid]);
}

__kernel void test_convert_uint8_sat_char8( __global char8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat(src[tid]);
}

__kernel void test_convert_uint8_sat_rte_char8( __global char8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rte(src[tid]);
}

__kernel void test_convert_uint8_sat_rtn_char8( __global char8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtn(src[tid]);
}

__kernel void test_convert_uint8_sat_rtp_char8( __global char8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtp(src[tid]);
}

__kernel void test_convert_uint8_sat_rtz_char8( __global char8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_sat_rtz(src[tid]);
}

__kernel void test_convert_uint8_char8( __global char8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8(src[tid]);
}

__kernel void test_convert_uint8_rte_char8( __global char8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rte(src[tid]);
}

__kernel void test_convert_uint8_rtn_char8( __global char8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtn(src[tid]);
}

__kernel void test_convert_uint8_rtp_char8( __global char8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtp(src[tid]);
}

__kernel void test_convert_uint8_rtz_char8( __global char8 *src, __global uint8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_uint8_rtz(src[tid]);
}

__kernel void test_convert_short8_sat_char8( __global char8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat(src[tid]);
}

__kernel void test_convert_short8_sat_rte_char8( __global char8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rte(src[tid]);
}

__kernel void test_convert_short8_sat_rtn_char8( __global char8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtn(src[tid]);
}

__kernel void test_convert_short8_sat_rtp_char8( __global char8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtp(src[tid]);
}

__kernel void test_convert_short8_sat_rtz_char8( __global char8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_sat_rtz(src[tid]);
}

__kernel void test_convert_short8_char8( __global char8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8(src[tid]);
}

__kernel void test_convert_short8_rte_char8( __global char8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rte(src[tid]);
}

__kernel void test_convert_short8_rtn_char8( __global char8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtn(src[tid]);
}

__kernel void test_convert_short8_rtp_char8( __global char8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtp(src[tid]);
}

__kernel void test_convert_short8_rtz_char8( __global char8 *src, __global short8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_short8_rtz(src[tid]);
}

__kernel void test_convert_ushort8_sat_char8( __global char8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat(src[tid]);
}

__kernel void test_convert_ushort8_sat_rte_char8( __global char8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rte(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtn_char8( __global char8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtn(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtp_char8( __global char8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtp(src[tid]);
}

__kernel void test_convert_ushort8_sat_rtz_char8( __global char8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_sat_rtz(src[tid]);
}

__kernel void test_convert_ushort8_char8( __global char8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8(src[tid]);
}

__kernel void test_convert_ushort8_rte_char8( __global char8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rte(src[tid]);
}

__kernel void test_convert_ushort8_rtn_char8( __global char8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtn(src[tid]);
}

__kernel void test_convert_ushort8_rtp_char8( __global char8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtp(src[tid]);
}

__kernel void test_convert_ushort8_rtz_char8( __global char8 *src, __global ushort8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ushort8_rtz(src[tid]);
}

__kernel void test_convert_float8_char8( __global char8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8(src[tid]);
}

__kernel void test_convert_float8_rte_char8( __global char8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rte(src[tid]);
}

__kernel void test_convert_float8_rtn_char8( __global char8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtn(src[tid]);
}

__kernel void test_convert_float8_rtp_char8( __global char8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtp(src[tid]);
}

__kernel void test_convert_float8_rtz_char8( __global char8 *src, __global float8 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_float8_rtz(src[tid]);
}


