#pragma OPENCL EXTENSION cl_khr_fp64 : enable
__kernel void test_convert_float_double( __global double *src, __global float *dest )
{
   size_t i = get_global_id(0);
   dest[i] = convert_float( src[i] );
}
