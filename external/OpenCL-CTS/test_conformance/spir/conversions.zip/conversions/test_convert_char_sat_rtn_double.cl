#pragma OPENCL EXTENSION cl_khr_fp64 : enable
__kernel void test_convert_char_sat_rtn_double( __global double *src, __global char *dest )
{
   size_t i = get_global_id(0);
   dest[i] = convert_char_sat_rtn( src[i] );
}
