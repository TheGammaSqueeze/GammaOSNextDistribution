#ifdef cles_khr_int64
#pragma OPENCL EXTENSION cles_khr_int64 : enable
#endif
__kernel void test_convert_long4_sat_char4( __global char4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat(src[tid]);
}

__kernel void test_convert_long4_sat_rte_char4( __global char4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rte(src[tid]);
}

__kernel void test_convert_long4_sat_rtn_char4( __global char4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtn(src[tid]);
}

__kernel void test_convert_long4_sat_rtp_char4( __global char4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtp(src[tid]);
}

__kernel void test_convert_long4_sat_rtz_char4( __global char4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_sat_rtz(src[tid]);
}

__kernel void test_convert_long4_char4( __global char4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4(src[tid]);
}

__kernel void test_convert_long4_rte_char4( __global char4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rte(src[tid]);
}

__kernel void test_convert_long4_rtn_char4( __global char4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtn(src[tid]);
}

__kernel void test_convert_long4_rtp_char4( __global char4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtp(src[tid]);
}

__kernel void test_convert_long4_rtz_char4( __global char4 *src, __global long4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_long4_rtz(src[tid]);
}

__kernel void test_convert_ulong4_sat_char4( __global char4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat(src[tid]);
}

__kernel void test_convert_ulong4_sat_rte_char4( __global char4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rte(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtn_char4( __global char4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtn(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtp_char4( __global char4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtp(src[tid]);
}

__kernel void test_convert_ulong4_sat_rtz_char4( __global char4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_sat_rtz(src[tid]);
}

__kernel void test_convert_ulong4_char4( __global char4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4(src[tid]);
}

__kernel void test_convert_ulong4_rte_char4( __global char4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rte(src[tid]);
}

__kernel void test_convert_ulong4_rtn_char4( __global char4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtn(src[tid]);
}

__kernel void test_convert_ulong4_rtp_char4( __global char4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtp(src[tid]);
}

__kernel void test_convert_ulong4_rtz_char4( __global char4 *src, __global ulong4 *dst ){
  size_t tid = get_global_id(0);
  dst[tid] = convert_ulong4_rtz(src[tid]);
}
